import{H as re,I as _,J as qe,K as ye,F as z,M as ve,c as se,i as oe,N as ge,B as we,O as je,e as P,b,j as Ce,q as S,R as $e,Q as De,T as Ee}from"./q-Bot-3uzW.js";const te={manifestHash:"mr63di",core:"q-BWEi-VkW.js",preloader:"q-XYi0b4s7.js",qwikLoader:"q-CuPr1DR2.js",bundleGraphAsset:"assets/CawX2NCP-bundle-graph.json",injections:[{tag:"link",location:"head",attributes:{rel:"stylesheet",href:"/assets/6YmA5bh4-style.css"}}],mapping:{s_W7z7DpskUFM:"q-BamD8OrO.js",s_WYpzmq1XX0s:"q-BFPQ7udb.js",s_oiJJPw4N5ec:"q-PtGxlCVi.js",s_s721gb1oPNg:"q-BFPQ7udb.js",s_uriPj4dOhLY:"q-CoQ8E_Ld.js",s_wqmFiuqc0n0:"q-BamD8OrO.js",s_ehhyUk2f1TI:"q-B6ls7NvQ.js",s_9CWk06j70CE:"q-CF-DzL4g.js",s_DSzPrlQthIQ:"q-C_FzZXZw.js",s_Ysfvd0zsHZc:"q-CKWOB9Lo.js",s_aHq5phOi7kM:"q-C_FzZXZw.js",s_eJD7O1W6Dks:"q-C_FzZXZw.js",s_g9KAbSZKhGM:"q-CF-DzL4g.js",s_gi28gSpEk3Y:"q-CF-DzL4g.js",s_uR5X0KRPC5A:"q-CF-DzL4g.js",s_26Zk9LevwR4:"q-DiWmxTXi.js",s_35YlVmV10xA:"q-c577VfBs.js",s_Fw08BHofx3E:"q-wLBq80c-.js",s_Mn4wVM9cJVk:"q-DQFVr1-L.js",s_RbgA8jLQung:"q-CK2T9Dia.js",s_U0XfefWO7EM:"q-BGKKR_Zr.js",s_ZqIsJSAU9MM:"q-BamD8OrO.js",s_bPVdCU20Qes:"q-CF-DzL4g.js",s_bQyFv5z8xyw:"q-CEF5UNSb.js",s_hs55Cc65pvA:"q-Ie1TmZDn.js",s_0409WLJe4ZA:"q-BCd1zT9Z.js",s_0aOiYLLcTuA:"q-CF-DzL4g.js",s_0vphQYqOdZI:"q-CIWYBxEG.js",s_1aSnYa4cZNY:"q-OhnMhSbf.js",s_1raneLGffO8:"q-c577VfBs.js",s_3Wcj1rjxuVI:"q-B6ls7NvQ.js",s_7oeZyJeSJLc:"q-BURs4eF3.js",s_8EHhsuLG6wc:"q-wLBq80c-.js",s_B0lqk5IDDy4:"q-Ie1TmZDn.js",s_BUrbVyeVOeI:"q-C8fHP23v.js",s_BVEnU88JlmQ:"q-BGKKR_Zr.js",s_HS2QQnuizIg:"q-CEF5UNSb.js",s_IPk10GunI7g:"q-C_FzZXZw.js",s_J7gsaTABbu0:"q-B6lvKQIJ.js",s_MiPVFWJLcMo:"q-D4-fDNlm.js",s_OAwbeyfgs0c:"q-xN0FLWRr.js",s_PlMhMWQHW9g:"q-Bd2pzuGF.js",s_ScE8eseirUA:"q-D8ghaIHm.js",s_VKFlAWJuVm8:"q-BOwaPIGj.js",s_Vm4GdHPtpg4:"q-C2rlsJ_M.js",s_VxsQCZFcAyQ:"q-CK2T9Dia.js",s_WqP80aZTB6s:"q-BamD8OrO.js",s_XugbeigHGlc:"q-D2LD8Cl6.js",s_YcwI1nCjycY:"q-PtGxlCVi.js",s_bmV0oH7tsks:"q-BWEi-VkW.js",s_czjMKqmqjMo:"q-Bezc9TVT.js",s_mPQ6C7ycb5Q:"q-CoQ8E_Ld.js",s_p1yCGpFL1xE:"q-CKWOB9Lo.js",s_pWsmcogutG8:"q-CpXsYXGO.js",s_tV00JQB9Z00:"q-DQFVr1-L.js",s_tntnak2DhJ8:"q-BlehoOV3.js",s_uE2rykD0NII:"q-DVGvd5dB.js",s_yG9BTd3fEjw:"q-BFPQ7udb.js",s_zgSncxM7sfI:"q-Dv4ZuhlI.js",s_K4gvalEGCME:"q-CKWOB9Lo.js",s_skL3E556KHA:"q-xN0FLWRr.js",s_9KRx0IOCHt8:"q-BK3N2c0s.js",s_A5SCimyrjAE:"q-DsiIYu_P.js",s_N26RLdG0oBg:"q-BnB3DTdc.js",s_WfTOxT4IrdA:"q-DX5uRNbt.js",s_0Qp5b6nbTLU:"q-CF-DzL4g.js",s_0ufq6hXd0xE:"q-Ie1TmZDn.js",s_4tsR9rwTp24:"q-C_FzZXZw.js",s_7vrZdIvRuqk:"q-B6ls7NvQ.js",s_8BfOSddddMg:"q-BamD8OrO.js",s_BJyWQfhuby0:"q-B6ls7NvQ.js",s_C1sSbhNvf08:"q-BiD6grx0.js",s_FdQ8zERN4uM:"q-c577VfBs.js",s_Ffb2InG0GWM:"q-Ie1TmZDn.js",s_GeWwv3oL9qU:"q-Ie1TmZDn.js",s_GukVrWhE1m8:"q-CF-DzL4g.js",s_I6YONFTIFiM:"q-C_FzZXZw.js",s_IvAmdwXNTM4:"q-BamD8OrO.js",s_JM6a9kNYMAE:"q-Ie1TmZDn.js",s_K74wC07VK3w:"q-BamD8OrO.js",s_L1mdPr9ezqs:"q-B6ls7NvQ.js",s_LzwHuJDGmnA:"q-CK2T9Dia.js",s_N8XT5kw5nFI:"q-CF-DzL4g.js",s_OIGgvvYWlgA:"q-CF-DzL4g.js",s_OTYsbHoCgnA:"q-Ie1TmZDn.js",s_PmWjL2RrvZM:"q-D4-fDNlm.js",s_RRMobuad0OM:"q-C_FzZXZw.js",s_TZVlEVQ5zFw:"q-CF-DzL4g.js",s_UC0oFS4Erjk:"q-Ie1TmZDn.js",s_US0pTyQnOdc:"q-BWEi-VkW.js",s_WQLz0FTWy8A:"q-CK2T9Dia.js",s_WXSDGs99ICg:"q-Ie1TmZDn.js",s_WysUX9ZGuY4:"q-CF-DzL4g.js",s_XKo0unq9QyI:"q-CF-DzL4g.js",s_ZCIhQLvlQ0k:"q-C_FzZXZw.js",s_Ze98mGqnscA:"q-C_FzZXZw.js",s_Zl0usuuOGCQ:"q-Ie1TmZDn.js",s_aRGEq0pPEGI:"q-C_FzZXZw.js",s_aww2BzpANGM:"q-CKWOB9Lo.js",s_b0RHwa83Q6I:"q-C_FzZXZw.js",s_dgZrr3sXauw:"q-B6ls7NvQ.js",s_dj8ExO27MUw:"q-B6ls7NvQ.js",s_dxQo6jvuA6w:"q-C_FzZXZw.js",s_e3oiEnnfZVU:"q-Ie1TmZDn.js",s_gPTd50s8Qk0:"q-Dv4ZuhlI.js",s_hiFJasaL4yY:"q-C_FzZXZw.js",s_i5kXixhtrRM:"q-CF-DzL4g.js",s_iXGbNUleynA:"q-CF-DzL4g.js",s_jJA842Zg3Rw:"q-Ie1TmZDn.js",s_jdF7ckWvmLI:"q-B6ls7NvQ.js",s_k6kpAK0WJmM:"q-CF-DzL4g.js",s_kKUsA2BuTZ4:"q-C_FzZXZw.js",s_lLHP6ncra00:"q-BamD8OrO.js",s_lqGVUGtYf2c:"q-Ie1TmZDn.js",s_naMQsUFBW6Q:"q-Ie1TmZDn.js",s_nuj8ZMDx6JU:"q-Ie1TmZDn.js",s_oFUauznEUQY:"q-CF-DzL4g.js",s_oPDUtqqA9NM:"q-C_FzZXZw.js",s_pOePtepJrko:"q-B6ls7NvQ.js",s_q6U0B105hNo:"q-Ie1TmZDn.js",s_qGVD1Sz413o:"q-CKWOB9Lo.js",s_qqN0d9btNrI:"q-CF-DzL4g.js",s_rRcDtxY6IHc:"q-CF-DzL4g.js",s_s7eZ7boERXM:"q-B6ls7NvQ.js",s_t1F0dnXItaM:"q-Ie1TmZDn.js",s_t8NnV05Urd8:"q-CF-DzL4g.js",s_trf0apS3WW0:"q-Ie1TmZDn.js",s_u6El8y8wd84:"q-BGKKR_Zr.js",s_xe8duyQ5aaU:"q-CpXsYXGO.js",s_z60vAP09fiw:"q-C_FzZXZw.js",s_zJz001DfrqE:"q-Ie1TmZDn.js",s_zPJUEsxZLIA:"q-c577VfBs.js",s_zpHcJzYZ88E:"q-CpXsYXGO.js"}};/**
 * @license
 * @builder.io/qwik/server 1.15.0
 * Copyright Builder.io, Inc. All Rights Reserved.
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/QwikDev/qwik/blob/main/LICENSE
 */var Pe=(t=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(t,{get:(e,n)=>(typeof require<"u"?require:e)[n]}):t)(function(t){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+t+'" is not supported')}),ke="<sync>";function ie(t,e){const n=e==null?void 0:e.mapper,r=t.symbolMapper?t.symbolMapper:(s,a,i)=>{var c;if(n){const d=I(s),u=n[d];if(!u){if(d===ke)return[d,""];if((c=globalThis.__qwik_reg_symbols)==null?void 0:c.has(d))return[s,"_"];if(i)return[s,`${i}?qrl=${s}`];console.error("Cannot resolve symbol",s,"in",n,i)}return u}};return{isServer:!0,async importSymbol(s,a,i){var h;const c=I(i),d=(h=globalThis.__qwik_reg_symbols)==null?void 0:h.get(c);if(d)return d;let u=String(a);u.endsWith(".js")||(u+=".js");const f=Pe(u);if(!(i in f))throw new Error(`Q-ERROR: missing symbol '${i}' in module '${u}'.`);return f[i]},raf:()=>(console.error("server can not rerender"),Promise.resolve()),nextTick:s=>new Promise(a=>{setTimeout(()=>{a(s())})}),chunkForSymbol(s,a,i){return r(s,n,i)}}}async function Se(t,e){const n=ie(t,e);re(n)}var I=t=>{const e=t.lastIndexOf("_");return e>-1?t.slice(e+1):t},Ie="q:instance",L={$DEBUG$:!1,$invPreloadProbability$:.65},Le=Date.now(),Be=/\.[mc]?js$/,ae=0,Te=1,Ne=2,Fe=3,O,A,Oe=(t,e)=>({$name$:t,$state$:Be.test(t)?ae:Fe,$deps$:ce?e==null?void 0:e.map(n=>({...n,$factor$:1})):e,$inverseProbability$:1,$createdTs$:Date.now(),$waitedMs$:0,$loadedMs$:0}),Ae=t=>{const e=new Map;let n=0;for(;n<t.length;){const r=t[n++],o=[];let s,a=1;for(;s=t[n],typeof s=="number";)s<0?a=-s/10:o.push({$name$:t[s],$importProbability$:a,$factor$:1}),n++;e.set(r,o)}return e},le=t=>{let e=Z.get(t);if(!e){let n;if(A){if(n=A.get(t),!n)return;n.length||(n=void 0)}e=Oe(t,n),Z.set(t,e)}return e},Ze=(t,e)=>{e&&("debug"in e&&(L.$DEBUG$=!!e.debug),typeof e.preloadProbability=="number"&&(L.$invPreloadProbability$=1-e.preloadProbability)),!(O!=null||!t)&&(O="",A=Ae(t))},Z=new Map,ce,B,ue=0,k=[],xe=(...t)=>{console.log(`Preloader ${Date.now()-Le}ms ${ue}/${k.length} queued>`,...t)},Qe=()=>{Z.clear(),B=!1,ce=!0,ue=0,k.length=0},ze=()=>{B&&(k.sort((t,e)=>t.$inverseProbability$-e.$inverseProbability$),B=!1)},Re=()=>{ze();let t=.4;const e=[];for(const n of k){const r=Math.round((1-n.$inverseProbability$)*10);r!==t&&(t=r,e.push(t)),e.push(n.$name$)}return e},de=(t,e,n)=>{if(n!=null&&n.has(t))return;const r=t.$inverseProbability$;if(t.$inverseProbability$=e,!(r-t.$inverseProbability$<.01)&&(O!=null&&t.$state$<Ne&&t.$inverseProbability$<L.$invPreloadProbability$&&(t.$state$===ae&&(t.$state$=Te,k.push(t),L.$DEBUG$&&xe(`queued ${Math.round((1-t.$inverseProbability$)*100)}%`,t.$name$)),B=!0),t.$deps$)){n||(n=new Set),n.add(t);const o=1-t.$inverseProbability$;for(const s of t.$deps$){const a=le(s.$name$);if(a.$inverseProbability$===0)continue;let i;if(s.$importProbability$>.5&&(o===1||o>=.99&&x<100))x++,i=Math.min(.01,1-s.$importProbability$);else{const c=1-s.$importProbability$*o,d=s.$factor$,u=c/d;i=Math.max(.02,a.$inverseProbability$*u),s.$factor$=u}de(a,i,n)}}},ne=(t,e)=>{const n=le(t);n&&n.$inverseProbability$>e&&de(n,e)},x,We=(t,e)=>{if(!(t!=null&&t.length))return;x=0;let n=e?1-e:.4;if(Array.isArray(t))for(let r=t.length-1;r>=0;r--){const o=t[r];typeof o=="number"?n=1-o/10:ne(o,n)}else ne(t,n)};function Ge(t){const e=[],n=r=>{if(r)for(const o of r)e.includes(o.url)||(e.push(o.url),o.imports&&n(o.imports))};return n(t),e}var Ue=t=>{var n;const e=ve();return(n=t==null?void 0:t.qrls)==null?void 0:n.map(r=>{var i;const o=r.$refSymbol$||r.$symbol$,s=r.$chunk$,a=e.chunkForSymbol(o,s,(i=r.dev)==null?void 0:i.file);return a?a[1]:s}).filter(Boolean)};function He(t,e,n){const r=e.prefetchStrategy;if(r===null)return[];if(!(n!=null&&n.manifest.bundleGraph))return Ue(t);if(typeof(r==null?void 0:r.symbolsToPrefetch)=="function")try{const s=r.symbolsToPrefetch({manifest:n.manifest});return Ge(s)}catch(s){console.error("getPrefetchUrls, symbolsToPrefetch()",s)}const o=new Set;for(const s of(t==null?void 0:t.qrls)||[]){const a=I(s.$refSymbol$||s.$symbol$);a&&a.length>=10&&o.add(a)}return[...o]}var Ve=(t,e)=>{if(!(e!=null&&e.manifest.bundleGraph))return[...new Set(t)];Qe();let n=.99;for(const r of t.slice(0,15))We(r,n),n*=.85;return Re()},Q=(t,e)=>{if(e==null)return null;const n=`${t}${e}`.split("/"),r=[];for(const o of n)o===".."&&r.length>0?r.pop():r.push(o);return r.join("/")},Xe=(t,e,n,r,o)=>{var c;const s=Q(t,(c=e==null?void 0:e.manifest)==null?void 0:c.preloader),a="/"+(e==null?void 0:e.manifest.bundleGraphAsset);if(s&&a&&n!==!1){const d=typeof n=="object"?{debug:n.debug,preloadProbability:n.ssrPreloadProbability}:void 0;Ze(e==null?void 0:e.manifest.bundleGraph,d);const u=[];n!=null&&n.debug&&u.push("d:1"),n!=null&&n.maxIdlePreloads&&u.push(`P:${n.maxIdlePreloads}`),n!=null&&n.preloadProbability&&u.push(`Q:${n.preloadProbability}`);const f=u.length?`,{${u.join(",")}}`:"",h=`let b=fetch("${a}");import("${s}").then(({l})=>l(${JSON.stringify(t)},b${f}));`;r.push(_("link",{rel:"modulepreload",href:s}),_("link",{rel:"preload",href:a,as:"fetch",crossorigin:"anonymous"}),_("script",{type:"module",async:!0,dangerouslySetInnerHTML:h,nonce:o}))}const i=Q(t,e==null?void 0:e.manifest.core);i&&r.push(_("link",{rel:"modulepreload",href:i}))},Je=(t,e,n,r,o)=>{if(r.length===0||n===!1)return null;const{ssrPreloads:s,ssrPreloadProbability:a}=Ye(typeof n=="boolean"?void 0:n);let i=s;const c=[],d=[],u=e==null?void 0:e.manifest.manifestHash;if(i){const q=e==null?void 0:e.manifest.preloader,m=e==null?void 0:e.manifest.core,j=Ve(r,e);let w=4;const C=a*10;for(const l of j)if(typeof l=="string"){if(w<C)break;if(l===q||l===m)continue;if(d.push(l),--i===0)break}else w=l}const f=Q(t,u&&(e==null?void 0:e.manifest.preloader));let g=d.length?`${JSON.stringify(d)}.map((l,e)=>{e=document.createElement('link');e.rel='modulepreload';e.href=${JSON.stringify(t)}+l;document.head.appendChild(e)});`:"";return f&&(g+=`window.addEventListener('load',f=>{f=_=>import("${f}").then(({p})=>p(${JSON.stringify(r)}));try{requestIdleCallback(f,{timeout:2000})}catch(e){setTimeout(f,200)}})`),g&&c.push(_("script",{type:"module","q:type":"preload",async:!0,dangerouslySetInnerHTML:g,nonce:o})),c.length>0?_(z,{children:c}):null},Ke=(t,e,n,r,o)=>{var s;if(n.preloader!==!1){const a=He(e,n,r);if(a.length>0){const i=Je(t,r,n.preloader,a,(s=n.serverData)==null?void 0:s.nonce);i&&o.push(i)}}};function Ye(t){return{...Me,...t}}var Me={ssrPreloads:7,ssrPreloadProbability:.5,debug:!1,maxIdlePreloads:25,preloadProbability:.35},et='const t=document,e=window,n=new Set,o=new Set([t]);let r;const s=(t,e)=>Array.from(t.querySelectorAll(e)),i=t=>{const e=[];return o.forEach((n=>e.push(...s(n,t)))),e},a=t=>{g(t),s(t,"[q\\\\:shadowroot]").forEach((t=>{const e=t.shadowRoot;e&&a(e)}))},c=t=>t&&"function"==typeof t.then;let l=!0;const f=(t,e,n=e.type)=>{let o=l;i("[on"+t+"\\\\:"+n+"]").forEach((r=>{o=!0,b(r,t,e,n)})),o||window[t.slice(1)].removeEventListener(n,"-window"===t?d:_)},p=e=>{if(void 0===e._qwikjson_){let n=(e===t.documentElement?t.body:e).lastElementChild;for(;n;){if("SCRIPT"===n.tagName&&"qwik/json"===n.getAttribute("type")){e._qwikjson_=JSON.parse(n.textContent.replace(/\\\\x3C(\\/?script)/gi,"<$1"));break}n=n.previousElementSibling}}},u=(t,e)=>new CustomEvent(t,{detail:e}),b=async(e,n,o,r=o.type)=>{const s="on"+n+":"+r;e.hasAttribute("preventdefault:"+r)&&o.preventDefault(),e.hasAttribute("stoppropagation:"+r)&&o.stopPropagation();const i=e._qc_,a=i&&i.li.filter((t=>t[0]===s));if(a&&a.length>0){for(const t of a){const n=t[1].getFn([e,o],(()=>e.isConnected))(o,e),r=o.cancelBubble;c(n)&&await n,r&&o.stopPropagation()}return}const l=e.getAttribute(s);if(l){const n=e.closest("[q\\\\:container]"),r=n.getAttribute("q:base"),s=n.getAttribute("q:version")||"unknown",i=n.getAttribute("q:manifest-hash")||"dev",a=new URL(r,t.baseURI);for(const f of l.split("\\n")){const l=new URL(f,a),u=l.href,b=l.hash.replace(/^#?([^?[|]*).*$/,"$1")||"default",q=performance.now();let _,d,w;const m=f.startsWith("#"),y={qBase:r,qManifest:i,qVersion:s,href:u,symbol:b,element:e,reqTime:q};if(m){const e=n.getAttribute("q:instance");_=(t["qFuncs_"+e]||[])[Number.parseInt(b)],_||(d="sync",w=Error("sym:"+b))}else{h("qsymbol",y);const t=l.href.split("#")[0];try{const e=import(t);p(n),_=(await e)[b],_||(d="no-symbol",w=Error(`${b} not in ${t}`))}catch(t){d||(d="async"),w=t}}if(!_){h("qerror",{importError:d,error:w,...y}),console.error(w);break}const g=t.__q_context__;if(e.isConnected)try{t.__q_context__=[e,o,l];const n=_(o,e);c(n)&&await n}catch(t){h("qerror",{error:t,...y})}finally{t.__q_context__=g}}}},h=(e,n)=>{t.dispatchEvent(u(e,n))},q=t=>t.replace(/([A-Z])/g,(t=>"-"+t.toLowerCase())),_=async t=>{let e=q(t.type),n=t.target;for(f("-document",t,e);n&&n.getAttribute;){const o=b(n,"",t,e);let r=t.cancelBubble;c(o)&&await o,r||(r=r||t.cancelBubble||n.hasAttribute("stoppropagation:"+t.type)),n=t.bubbles&&!0!==r?n.parentElement:null}},d=t=>{f("-window",t,q(t.type))},w=()=>{var s;const c=t.readyState;if(!r&&("interactive"==c||"complete"==c)&&(o.forEach(a),r=1,h("qinit"),(null!=(s=e.requestIdleCallback)?s:e.setTimeout).bind(e)((()=>h("qidle"))),n.has("qvisible"))){const t=i("[on\\\\:qvisible]"),e=new IntersectionObserver((t=>{for(const n of t)n.isIntersecting&&(e.unobserve(n.target),b(n.target,"",u("qvisible",n)))}));t.forEach((t=>e.observe(t)))}},m=(t,e,n,o=!1)=>{t.addEventListener(e,n,{capture:o,passive:!1})};let y;const g=(...t)=>{l=!0,clearTimeout(y),y=setTimeout((()=>l=!1),2e4);for(const r of t)"string"==typeof r?n.has(r)||(o.forEach((t=>m(t,r,_,!0))),m(e,r,d,!0),n.add(r)):o.has(r)||(n.forEach((t=>m(r,t,_,!0))),o.add(r))};if(!("__q_context__"in t)){t.__q_context__=0;const r=e.qwikevents;r&&(Array.isArray(r)?g(...r):g("click","input")),e.qwikevents={events:n,roots:o,push:g},m(t,"readystatechange",w),w()}',tt=`const doc = document;
const win = window;
const events = /* @__PURE__ */ new Set();
const roots = /* @__PURE__ */ new Set([doc]);
let hasInitialized;
const nativeQuerySelectorAll = (root, selector) => Array.from(root.querySelectorAll(selector));
const querySelectorAll = (query) => {
  const elements = [];
  roots.forEach((root) => elements.push(...nativeQuerySelectorAll(root, query)));
  return elements;
};
const findShadowRoots = (fragment) => {
  processEventOrNode(fragment);
  nativeQuerySelectorAll(fragment, "[q\\\\:shadowroot]").forEach((parent) => {
    const shadowRoot = parent.shadowRoot;
    shadowRoot && findShadowRoots(shadowRoot);
  });
};
const isPromise = (promise) => promise && typeof promise.then === "function";
let doNotClean = true;
const broadcast = (infix, ev, type = ev.type) => {
  let found = doNotClean;
  querySelectorAll("[on" + infix + "\\\\:" + type + "]").forEach((el) => {
    found = true;
    dispatch(el, infix, ev, type);
  });
  if (!found) {
    window[infix.slice(1)].removeEventListener(
      type,
      infix === "-window" ? processWindowEvent : processDocumentEvent
    );
  }
};
const resolveContainer = (containerEl) => {
  if (containerEl._qwikjson_ === void 0) {
    const parentJSON = containerEl === doc.documentElement ? doc.body : containerEl;
    let script = parentJSON.lastElementChild;
    while (script) {
      if (script.tagName === "SCRIPT" && script.getAttribute("type") === "qwik/json") {
        containerEl._qwikjson_ = JSON.parse(
          script.textContent.replace(/\\\\x3C(\\/?script)/gi, "<$1")
        );
        break;
      }
      script = script.previousElementSibling;
    }
  }
};
const createEvent = (eventName, detail) => new CustomEvent(eventName, {
  detail
});
const dispatch = async (element, onPrefix, ev, eventName = ev.type) => {
  const attrName = "on" + onPrefix + ":" + eventName;
  if (element.hasAttribute("preventdefault:" + eventName)) {
    ev.preventDefault();
  }
  if (element.hasAttribute("stoppropagation:" + eventName)) {
    ev.stopPropagation();
  }
  const ctx = element._qc_;
  const relevantListeners = ctx && ctx.li.filter((li) => li[0] === attrName);
  if (relevantListeners && relevantListeners.length > 0) {
    for (const listener of relevantListeners) {
      const results = listener[1].getFn([element, ev], () => element.isConnected)(ev, element);
      const cancelBubble = ev.cancelBubble;
      if (isPromise(results)) {
        await results;
      }
      if (cancelBubble) {
        ev.stopPropagation();
      }
    }
    return;
  }
  const attrValue = element.getAttribute(attrName);
  if (attrValue) {
    const container = element.closest("[q\\\\:container]");
    const qBase = container.getAttribute("q:base");
    const qVersion = container.getAttribute("q:version") || "unknown";
    const qManifest = container.getAttribute("q:manifest-hash") || "dev";
    const base = new URL(qBase, doc.baseURI);
    for (const qrl of attrValue.split("\\n")) {
      const url = new URL(qrl, base);
      const href = url.href;
      const symbol = url.hash.replace(/^#?([^?[|]*).*$/, "$1") || "default";
      const reqTime = performance.now();
      let handler;
      let importError;
      let error;
      const isSync = qrl.startsWith("#");
      const eventData = {
        qBase,
        qManifest,
        qVersion,
        href,
        symbol,
        element,
        reqTime
      };
      if (isSync) {
        const hash = container.getAttribute("q:instance");
        handler = (doc["qFuncs_" + hash] || [])[Number.parseInt(symbol)];
        if (!handler) {
          importError = "sync";
          error = new Error("sym:" + symbol);
        }
      } else {
        emitEvent("qsymbol", eventData);
        const uri = url.href.split("#")[0];
        try {
          const module = import(
                        uri
          );
          resolveContainer(container);
          handler = (await module)[symbol];
          if (!handler) {
            importError = "no-symbol";
            error = new Error(\`\${symbol} not in \${uri}\`);
          }
        } catch (err) {
          importError || (importError = "async");
          error = err;
        }
      }
      if (!handler) {
        emitEvent("qerror", {
          importError,
          error,
          ...eventData
        });
        console.error(error);
        break;
      }
      const previousCtx = doc.__q_context__;
      if (element.isConnected) {
        try {
          doc.__q_context__ = [element, ev, url];
          const results = handler(ev, element);
          if (isPromise(results)) {
            await results;
          }
        } catch (error2) {
          emitEvent("qerror", { error: error2, ...eventData });
        } finally {
          doc.__q_context__ = previousCtx;
        }
      }
    }
  }
};
const emitEvent = (eventName, detail) => {
  doc.dispatchEvent(createEvent(eventName, detail));
};
const camelToKebab = (str) => str.replace(/([A-Z])/g, (a) => "-" + a.toLowerCase());
const processDocumentEvent = async (ev) => {
  let type = camelToKebab(ev.type);
  let element = ev.target;
  broadcast("-document", ev, type);
  while (element && element.getAttribute) {
    const results = dispatch(element, "", ev, type);
    let cancelBubble = ev.cancelBubble;
    if (isPromise(results)) {
      await results;
    }
    cancelBubble || (cancelBubble = cancelBubble || ev.cancelBubble || element.hasAttribute("stoppropagation:" + ev.type));
    element = ev.bubbles && cancelBubble !== true ? element.parentElement : null;
  }
};
const processWindowEvent = (ev) => {
  broadcast("-window", ev, camelToKebab(ev.type));
};
const processReadyStateChange = () => {
  var _a;
  const readyState = doc.readyState;
  if (!hasInitialized && (readyState == "interactive" || readyState == "complete")) {
    roots.forEach(findShadowRoots);
    hasInitialized = 1;
    emitEvent("qinit");
    const riC = (_a = win.requestIdleCallback) != null ? _a : win.setTimeout;
    riC.bind(win)(() => emitEvent("qidle"));
    if (events.has("qvisible")) {
      const results = querySelectorAll("[on\\\\:qvisible]");
      const observer = new IntersectionObserver((entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            observer.unobserve(entry.target);
            dispatch(entry.target, "", createEvent("qvisible", entry));
          }
        }
      });
      results.forEach((el) => observer.observe(el));
    }
  }
};
const addEventListener = (el, eventName, handler, capture = false) => {
  el.addEventListener(eventName, handler, { capture, passive: false });
};
let cleanTimer;
const processEventOrNode = (...eventNames) => {
  doNotClean = true;
  clearTimeout(cleanTimer);
  cleanTimer = setTimeout(() => doNotClean = false, 2e4);
  for (const eventNameOrNode of eventNames) {
    if (typeof eventNameOrNode === "string") {
      if (!events.has(eventNameOrNode)) {
        roots.forEach(
          (root) => addEventListener(root, eventNameOrNode, processDocumentEvent, true)
        );
        addEventListener(win, eventNameOrNode, processWindowEvent, true);
        events.add(eventNameOrNode);
      }
    } else {
      if (!roots.has(eventNameOrNode)) {
        events.forEach(
          (eventName) => addEventListener(eventNameOrNode, eventName, processDocumentEvent, true)
        );
        roots.add(eventNameOrNode);
      }
    }
  }
};
if (!("__q_context__" in doc)) {
  doc.__q_context__ = 0;
  const qwikevents = win.qwikevents;
  if (qwikevents) {
    if (Array.isArray(qwikevents)) {
      processEventOrNode(...qwikevents);
    } else {
      processEventOrNode("click", "input");
    }
  }
  win.qwikevents = {
    events,
    roots,
    push: processEventOrNode
  };
  addEventListener(doc, "readystatechange", processReadyStateChange);
  processReadyStateChange();
}`;function nt(t={}){return t.debug?tt:et}function F(){if(typeof performance>"u")return()=>0;const t=performance.now();return()=>(performance.now()-t)/1e6}function rt(t){let e=t.base;return typeof t.base=="function"&&(e=t.base(t)),typeof e=="string"?(e.endsWith("/")||(e+="/"),e):"/build/"}var st="<!DOCTYPE html>";async function ot(t,e){var U,H,V;let n=e.stream,r=0,o=0,s=0,a=0,i="",c;const d=((U=e.streaming)==null?void 0:U.inOrder)??{strategy:"auto",maximunInitialChunk:5e4,maximunChunk:3e4},u=e.containerTagName??"html",f=e.containerAttributes??{},h=n,g=F(),q=rt(e),m=me(e.manifest);function j(){i&&(h.write(i),i="",r=0,s++,s===1&&(a=g()))}function w(p){const y=p.length;r+=y,o+=y,i+=p}switch(d.strategy){case"disabled":n={write:w};break;case"direct":n=h;break;case"auto":let p=0,y=!1;const X=d.maximunChunk??0,N=d.maximunInitialChunk??0;n={write(E){E==="<!--qkssr-f-->"?y||(y=!0):E==="<!--qkssr-pu-->"?p++:E==="<!--qkssr-po-->"?p--:w(E),p===0&&(y||r>=(s===0?N:X))&&(y=!1,j())}};break}u==="html"?n.write(st):n.write("<!--cq-->"),m||console.warn("Missing client manifest, loading symbols in the client might 404. Please ensure the client build has run and generated the manifest for the server build."),await Se(e,m);const C=m==null?void 0:m.manifest.injections,l=C?C.map(p=>_(p.tag,p.attributes??{})):[],v=((H=e.qwikLoader)==null?void 0:H.include)??"auto",T=m==null?void 0:m.manifest.qwikLoader;let R=!1;v!=="never"&&T&&(l.unshift(_("link",{rel:"modulepreload",href:`${q}${T}`}),_("script",{type:"module",async:!0,src:`${q}${T}`})),R=!0),Xe(q,m,e.preloader,l,(V=e.serverData)==null?void 0:V.nonce);const fe=F(),pe=[];let W=0,G=0;await qe(t,{stream:n,containerTagName:u,containerAttributes:f,serverData:e.serverData,base:q,beforeContent:l,beforeClose:async(p,y,X,N)=>{var K,Y,M,ee;W=fe();const E=F();c=await ye(p,y,void 0,N);const $=[];Ke(q,c,e,m,$);const be=JSON.stringify(c.state,void 0,void 0);if($.push(_("script",{type:"qwik/json",dangerouslySetInnerHTML:at(be),nonce:(K=e.serverData)==null?void 0:K.nonce})),c.funcs.length>0){const D=f[Ie];$.push(_("script",{"q:func":"qwik/json",dangerouslySetInnerHTML:ut(D,c.funcs),nonce:(Y=e.serverData)==null?void 0:Y.nonce}))}const he=!c||c.mode!=="static";if(!R&&(v==="always"||v==="auto"&&he)){const D=nt({debug:e.debug});$.push(_("script",{id:"qwikloader",async:!0,type:"module",dangerouslySetInnerHTML:D,nonce:(M=e.serverData)==null?void 0:M.nonce}))}const J=Array.from(y.$events$,D=>JSON.stringify(D));if(J.length>0){const D=`(window.qwikevents||(window.qwikevents=[])).push(${J.join(",")})`;$.push(_("script",{dangerouslySetInnerHTML:D,nonce:(ee=e.serverData)==null?void 0:ee.nonce}))}return lt(pe,p),G=E(),_(z,{children:$})},manifestHash:(m==null?void 0:m.manifest.manifestHash)||"dev"+it()}),u!=="html"&&n.write("<!--/cq-->"),j();const _e=c.resources.some(p=>p._cache!==1/0);return{prefetchResources:void 0,snapshotResult:c,flushes:s,manifest:m==null?void 0:m.manifest,size:o,isStatic:!_e,timing:{render:W,snapshot:G,firstFlush:a}}}function it(){return Math.random().toString(36).slice(2)}function me(t){const e=t?{...te,...t}:te;if(!e||"mapper"in e)return e;if(e.mapping){const n={};return Object.entries(e.mapping).forEach(([r,o])=>{n[I(r)]=[r,o]}),{mapper:n,manifest:e,injections:e.injections||[]}}}var at=t=>t.replace(/<(\/?script)/gi,"\\x3C$1");function lt(t,e){var n;for(const r of e){const o=(n=r.$componentQrl$)==null?void 0:n.getSymbol();o&&!t.includes(o)&&t.push(o)}}var ct='document["qFuncs_HASH"]=';function ut(t,e){return ct.replace("HASH",t)+`[${e.join(`,
`)}]`}async function qt(t){const e=ie({},me(t));re(e)}const dt=()=>{var c,d,u,f,h,g,q,m,j,w,C;const t=ge(),e=we(),n=je(),r=((d=(c=n.value)==null?void 0:c.site)==null?void 0:d.site_name)||t.title||"Card Issuing Web",o=((f=(u=n.value)==null?void 0:u.site)==null?void 0:f.site_desc)||"Card Issuing Web Application",s=((g=(h=n.value)==null?void 0:h.site)==null?void 0:g.keywords)||"",a=((m=(q=n.value)==null?void 0:q.site)==null?void 0:m.site_logo)||"/favicon.svg",i=((w=(j=n.value)==null?void 0:j.site)==null?void 0:w.custom_html)||"";return P(z,{children:[b("title",null,null,t.title||r,1,null),b("meta",{content:((C=t.meta.find(l=>l.name==="description"))==null?void 0:C.content)||o},{name:"description"},null,3,null),s&&b("meta",{content:s},{name:"keywords"},null,3,"0D_0"),b("link",null,{rel:"canonical",href:Ce(l=>l.url.href,[e],"p0.url.href")},null,3,null),b("meta",null,{name:"viewport",content:"width=device-width, initial-scale=1.0"},null,3,null),b("link",{href:a},{rel:"icon",type:"image/svg+xml"},null,3,null),t.meta.map(l=>S("meta",{...l},null,0,l.key)),t.links.map(l=>S("link",{...l},null,0,l.key)),t.styles.map(l=>{var v;return S("style",{...l.props,...(v=l.props)!=null&&v.dangerouslySetInnerHTML?{}:{dangerouslySetInnerHTML:l.style}},null,0,l.key)}),t.scripts.map(l=>{var v;return S("script",{...l.props,...(v=l.props)!=null&&v.dangerouslySetInnerHTML?{}:{dangerouslySetInnerHTML:l.script}},null,0,l.key)}),i&&b("div",{dangerouslySetInnerHTML:i},null,null,3,"0D_1")]},1,"0D_2")},mt=se(oe(dt,"s_0vphQYqOdZI")),ft=()=>P(De,{children:[b("head",null,null,[b("meta",null,{charset:"utf-8"},null,3,null),b("link",null,{rel:"manifest",href:"/manifest.json"},null,3,"vp_0"),P(mt,null,3,"vp_1"),b("script",null,{"disable-devtool-auto":!0,src:"https://cdn.jsdelivr.net/npm/disable-devtool@latest","clear-log":"true","disable-menu":"false","disable-select":"false","disable-copy":"false","disable-cut":"false","disable-paste":"false"},null,3,"vp_2")],1,null),b("body",null,{class:"bg-background text-foreground min-h-screen transition-colors"},P($e,null,3,"vp_3"),1,null)]},1,"vp_4"),pt=se(oe(ft,"s_tntnak2DhJ8"));function yt(t){var r;const n=new Ee((r=t.serverData)==null?void 0:r.requestHeaders.cookie).getRealTheme();return ot(P(pt,null,3,"Qb_0"),{...t,containerAttributes:{lang:"zh-CN",class:n,style:"color-scheme: "+n,...t.containerAttributes},serverData:{...t.serverData}})}export{yt as r,qt as s};
