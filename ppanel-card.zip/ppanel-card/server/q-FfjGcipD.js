import { H as setPlatform, I as jsx, J as _renderSSR, K as _pauseFromContexts, F as Fragment, M as getPlatform, c as componentQrl, i as inlinedQrl, N as useDocumentHead, B as useLocation, O as useSiteConfig, e as _jsxC, b as _jsxQ, j as _fnSignal, q as _jsxS, R as RouterOutlet, Q as QwikCityProvider, T as ThemeManager } from "./q-_LNWSPPT.js";
const manifest = { "manifestHash": "spcmg7", "core": "q-BWEi-VkW.js", "preloader": "q-XYi0b4s7.js", "qwikLoader": "q-CuPr1DR2.js", "bundleGraphAsset": "assets/o6oUt3x7-bundle-graph.json", "injections": [{ "tag": "link", "location": "head", "attributes": { "rel": "stylesheet", "href": "/assets/6YmA5bh4-style.css" } }], "mapping": { "s_W7z7DpskUFM": "q-BamD8OrO.js", "s_WYpzmq1XX0s": "q-BFPQ7udb.js", "s_oiJJPw4N5ec": "q-PtGxlCVi.js", "s_s721gb1oPNg": "q-BFPQ7udb.js", "s_uriPj4dOhLY": "q-CoQ8E_Ld.js", "s_wqmFiuqc0n0": "q-BamD8OrO.js", "s_ehhyUk2f1TI": "q-B6ls7NvQ.js", "s_9CWk06j70CE": "q-CF-DzL4g.js", "s_Ysfvd0zsHZc": "q-CKWOB9Lo.js", "s_aHq5phOi7kM": "q-C_FzZXZw.js", "s_eJD7O1W6Dks": "q-C_FzZXZw.js", "s_g9KAbSZKhGM": "q-CF-DzL4g.js", "s_gi28gSpEk3Y": "q-CF-DzL4g.js", "s_uR5X0KRPC5A": "q-CF-DzL4g.js", "s_26Zk9LevwR4": "q-DiWmxTXi.js", "s_35YlVmV10xA": "q-c577VfBs.js", "s_Fw08BHofx3E": "q-wLBq80c-.js", "s_Mn4wVM9cJVk": "q-DQFVr1-L.js", "s_RbgA8jLQung": "q-CK2T9Dia.js", "s_U0XfefWO7EM": "q-BGKKR_Zr.js", "s_ZqIsJSAU9MM": "q-BamD8OrO.js", "s_bPVdCU20Qes": "q-CF-DzL4g.js", "s_bQyFv5z8xyw": "q-CEF5UNSb.js", "s_hs55Cc65pvA": "q-Ie1TmZDn.js", "s_0409WLJe4ZA": "q-BCd1zT9Z.js", "s_0aOiYLLcTuA": "q-CF-DzL4g.js", "s_0vphQYqOdZI": "q-CIWYBxEG.js", "s_1aSnYa4cZNY": "q-OhnMhSbf.js", "s_1raneLGffO8": "q-c577VfBs.js", "s_3Wcj1rjxuVI": "q-B6ls7NvQ.js", "s_7oeZyJeSJLc": "q-BURs4eF3.js", "s_8EHhsuLG6wc": "q-wLBq80c-.js", "s_B0lqk5IDDy4": "q-Ie1TmZDn.js", "s_BUrbVyeVOeI": "q-C8fHP23v.js", "s_BVEnU88JlmQ": "q-BGKKR_Zr.js", "s_HS2QQnuizIg": "q-CEF5UNSb.js", "s_IPk10GunI7g": "q-C_FzZXZw.js", "s_J7gsaTABbu0": "q-B6lvKQIJ.js", "s_MiPVFWJLcMo": "q-D4-fDNlm.js", "s_OAwbeyfgs0c": "q-xN0FLWRr.js", "s_PlMhMWQHW9g": "q-Bd2pzuGF.js", "s_ScE8eseirUA": "q-D8ghaIHm.js", "s_VKFlAWJuVm8": "q-BOwaPIGj.js", "s_Vm4GdHPtpg4": "q-C2rlsJ_M.js", "s_VxsQCZFcAyQ": "q-CK2T9Dia.js", "s_WqP80aZTB6s": "q-BamD8OrO.js", "s_XugbeigHGlc": "q-D2LD8Cl6.js", "s_YcwI1nCjycY": "q-PtGxlCVi.js", "s_bmV0oH7tsks": "q-BWEi-VkW.js", "s_czjMKqmqjMo": "q-Bezc9TVT.js", "s_mPQ6C7ycb5Q": "q-CoQ8E_Ld.js", "s_p1yCGpFL1xE": "q-CKWOB9Lo.js", "s_pWsmcogutG8": "q-CpXsYXGO.js", "s_tV00JQB9Z00": "q-DQFVr1-L.js", "s_tntnak2DhJ8": "q-BlehoOV3.js", "s_uE2rykD0NII": "q-DVGvd5dB.js", "s_yG9BTd3fEjw": "q-BFPQ7udb.js", "s_zgSncxM7sfI": "q-Dv4ZuhlI.js", "s_7vrZdIvRuqk": "q-B6ls7NvQ.js", "s_BJyWQfhuby0": "q-B6ls7NvQ.js", "s_C1sSbhNvf08": "q-BiD6grx0.js", "s_K4gvalEGCME": "q-CKWOB9Lo.js", "s_skL3E556KHA": "q-xN0FLWRr.js", "s_9KRx0IOCHt8": "q-BK3N2c0s.js", "s_A5SCimyrjAE": "q-DsiIYu_P.js", "s_N26RLdG0oBg": "q-BnB3DTdc.js", "s_WfTOxT4IrdA": "q-DX5uRNbt.js", "s_0Qp5b6nbTLU": "q-CF-DzL4g.js", "s_0ufq6hXd0xE": "q-Ie1TmZDn.js", "s_4tsR9rwTp24": "q-C_FzZXZw.js", "s_8BfOSddddMg": "q-BamD8OrO.js", "s_DSzPrlQthIQ": "q-C_FzZXZw.js", "s_FdQ8zERN4uM": "q-c577VfBs.js", "s_Ffb2InG0GWM": "q-Ie1TmZDn.js", "s_GeWwv3oL9qU": "q-Ie1TmZDn.js", "s_GukVrWhE1m8": "q-CF-DzL4g.js", "s_I6YONFTIFiM": "q-C_FzZXZw.js", "s_IvAmdwXNTM4": "q-BamD8OrO.js", "s_JM6a9kNYMAE": "q-Ie1TmZDn.js", "s_K74wC07VK3w": "q-BamD8OrO.js", "s_L1mdPr9ezqs": "q-B6ls7NvQ.js", "s_LzwHuJDGmnA": "q-CK2T9Dia.js", "s_N8XT5kw5nFI": "q-CF-DzL4g.js", "s_OIGgvvYWlgA": "q-CF-DzL4g.js", "s_OTYsbHoCgnA": "q-Ie1TmZDn.js", "s_PmWjL2RrvZM": "q-D4-fDNlm.js", "s_RRMobuad0OM": "q-C_FzZXZw.js", "s_TZVlEVQ5zFw": "q-CF-DzL4g.js", "s_UC0oFS4Erjk": "q-Ie1TmZDn.js", "s_US0pTyQnOdc": "q-BWEi-VkW.js", "s_WQLz0FTWy8A": "q-CK2T9Dia.js", "s_WXSDGs99ICg": "q-Ie1TmZDn.js", "s_WysUX9ZGuY4": "q-CF-DzL4g.js", "s_XKo0unq9QyI": "q-CF-DzL4g.js", "s_ZCIhQLvlQ0k": "q-C_FzZXZw.js", "s_Ze98mGqnscA": "q-C_FzZXZw.js", "s_Zl0usuuOGCQ": "q-Ie1TmZDn.js", "s_aRGEq0pPEGI": "q-C_FzZXZw.js", "s_aww2BzpANGM": "q-CKWOB9Lo.js", "s_b0RHwa83Q6I": "q-C_FzZXZw.js", "s_dgZrr3sXauw": "q-B6ls7NvQ.js", "s_dj8ExO27MUw": "q-B6ls7NvQ.js", "s_dxQo6jvuA6w": "q-C_FzZXZw.js", "s_e3oiEnnfZVU": "q-Ie1TmZDn.js", "s_gPTd50s8Qk0": "q-Dv4ZuhlI.js", "s_hiFJasaL4yY": "q-C_FzZXZw.js", "s_i5kXixhtrRM": "q-CF-DzL4g.js", "s_iXGbNUleynA": "q-CF-DzL4g.js", "s_jJA842Zg3Rw": "q-Ie1TmZDn.js", "s_jdF7ckWvmLI": "q-B6ls7NvQ.js", "s_k6kpAK0WJmM": "q-CF-DzL4g.js", "s_kKUsA2BuTZ4": "q-C_FzZXZw.js", "s_lLHP6ncra00": "q-BamD8OrO.js", "s_lqGVUGtYf2c": "q-Ie1TmZDn.js", "s_naMQsUFBW6Q": "q-Ie1TmZDn.js", "s_nuj8ZMDx6JU": "q-Ie1TmZDn.js", "s_oFUauznEUQY": "q-CF-DzL4g.js", "s_oPDUtqqA9NM": "q-C_FzZXZw.js", "s_pOePtepJrko": "q-B6ls7NvQ.js", "s_q6U0B105hNo": "q-Ie1TmZDn.js", "s_qGVD1Sz413o": "q-CKWOB9Lo.js", "s_qqN0d9btNrI": "q-CF-DzL4g.js", "s_rRcDtxY6IHc": "q-CF-DzL4g.js", "s_s7eZ7boERXM": "q-B6ls7NvQ.js", "s_t1F0dnXItaM": "q-Ie1TmZDn.js", "s_t8NnV05Urd8": "q-CF-DzL4g.js", "s_trf0apS3WW0": "q-Ie1TmZDn.js", "s_u6El8y8wd84": "q-BGKKR_Zr.js", "s_xe8duyQ5aaU": "q-CpXsYXGO.js", "s_z60vAP09fiw": "q-C_FzZXZw.js", "s_zJz001DfrqE": "q-Ie1TmZDn.js", "s_zPJUEsxZLIA": "q-c577VfBs.js", "s_zpHcJzYZ88E": "q-CpXsYXGO.js" } };
/**
 * @license
 * @builder.io/qwik/server 1.15.0
 * Copyright Builder.io, Inc. All Rights Reserved.
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/QwikDev/qwik/blob/main/LICENSE
 */
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var SYNC_QRL = "<sync>";
function createPlatform(opts, resolvedManifest) {
  const mapper = resolvedManifest == null ? void 0 : resolvedManifest.mapper;
  const mapperFn = opts.symbolMapper ? opts.symbolMapper : (symbolName, _chunk, parent) => {
    var _a;
    if (mapper) {
      const hash2 = getSymbolHash(symbolName);
      const result = mapper[hash2];
      if (!result) {
        if (hash2 === SYNC_QRL) {
          return [hash2, ""];
        }
        const isRegistered = (_a = globalThis.__qwik_reg_symbols) == null ? void 0 : _a.has(hash2);
        if (isRegistered) {
          return [symbolName, "_"];
        }
        if (parent) {
          return [symbolName, `${parent}?qrl=${symbolName}`];
        }
        console.error("Cannot resolve symbol", symbolName, "in", mapper, parent);
      }
      return result;
    }
  };
  const serverPlatform = {
    isServer: true,
    async importSymbol(_containerEl, url, symbolName) {
      var _a;
      const hash2 = getSymbolHash(symbolName);
      const regSym = (_a = globalThis.__qwik_reg_symbols) == null ? void 0 : _a.get(hash2);
      if (regSym) {
        return regSym;
      }
      let modulePath = String(url);
      if (!modulePath.endsWith(".js")) {
        modulePath += ".js";
      }
      const module = __require(modulePath);
      if (!(symbolName in module)) {
        throw new Error(`Q-ERROR: missing symbol '${symbolName}' in module '${modulePath}'.`);
      }
      return module[symbolName];
    },
    raf: () => {
      console.error("server can not rerender");
      return Promise.resolve();
    },
    nextTick: (fn) => {
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(fn());
        });
      });
    },
    chunkForSymbol(symbolName, _chunk, parent) {
      return mapperFn(symbolName, mapper, parent);
    }
  };
  return serverPlatform;
}
async function setServerPlatform(opts, manifest2) {
  const platform = createPlatform(opts, manifest2);
  setPlatform(platform);
}
var getSymbolHash = (symbolName) => {
  const index = symbolName.lastIndexOf("_");
  if (index > -1) {
    return symbolName.slice(index + 1);
  }
  return symbolName;
};
var QInstance = "q:instance";
var config = {
  $DEBUG$: false,
  $invPreloadProbability$: 0.65
};
var loadStart = Date.now();
var isJSRegex = /\.[mc]?js$/;
var BundleImportState_None = 0;
var BundleImportState_Queued = 1;
var BundleImportState_Preload = 2;
var BundleImportState_Alias = 3;
var base;
var graph;
var makeBundle = (name, deps) => {
  return {
    $name$: name,
    $state$: isJSRegex.test(name) ? BundleImportState_None : BundleImportState_Alias,
    $deps$: shouldResetFactor ? deps == null ? void 0 : deps.map((d) => ({ ...d, $factor$: 1 })) : deps,
    $inverseProbability$: 1,
    $createdTs$: Date.now(),
    $waitedMs$: 0,
    $loadedMs$: 0
  };
};
var parseBundleGraph = (serialized) => {
  const graph2 = /* @__PURE__ */ new Map();
  let i = 0;
  while (i < serialized.length) {
    const name = serialized[i++];
    const deps = [];
    let idx;
    let probability = 1;
    while (idx = serialized[i], typeof idx === "number") {
      if (idx < 0) {
        probability = -idx / 10;
      } else {
        deps.push({
          $name$: serialized[idx],
          $importProbability$: probability,
          $factor$: 1
        });
      }
      i++;
    }
    graph2.set(name, deps);
  }
  return graph2;
};
var getBundle = (name) => {
  let bundle = bundles.get(name);
  if (!bundle) {
    let deps;
    if (graph) {
      deps = graph.get(name);
      if (!deps) {
        return;
      }
      if (!deps.length) {
        deps = void 0;
      }
    }
    bundle = makeBundle(name, deps);
    bundles.set(name, bundle);
  }
  return bundle;
};
var initPreloader = (serializedBundleGraph, opts) => {
  if (opts) {
    if ("debug" in opts) {
      config.$DEBUG$ = !!opts.debug;
    }
    if (typeof opts.preloadProbability === "number") {
      config.$invPreloadProbability$ = 1 - opts.preloadProbability;
    }
  }
  if (base != null || !serializedBundleGraph) {
    return;
  }
  base = "";
  graph = parseBundleGraph(serializedBundleGraph);
};
var bundles = /* @__PURE__ */ new Map();
var shouldResetFactor;
var queueDirty;
var preloadCount = 0;
var queue = [];
var log = (...args) => {
  console.log(
    `Preloader ${Date.now() - loadStart}ms ${preloadCount}/${queue.length} queued>`,
    ...args
  );
};
var resetQueue = () => {
  bundles.clear();
  queueDirty = false;
  shouldResetFactor = true;
  preloadCount = 0;
  queue.length = 0;
};
var sortQueue = () => {
  if (queueDirty) {
    queue.sort((a, b) => a.$inverseProbability$ - b.$inverseProbability$);
    queueDirty = false;
  }
};
var getQueue = () => {
  sortQueue();
  let probability = 0.4;
  const result = [];
  for (const b of queue) {
    const nextProbability = Math.round((1 - b.$inverseProbability$) * 10);
    if (nextProbability !== probability) {
      probability = nextProbability;
      result.push(probability);
    }
    result.push(b.$name$);
  }
  return result;
};
var adjustProbabilities = (bundle, newInverseProbability, seen) => {
  if (seen == null ? void 0 : seen.has(bundle)) {
    return;
  }
  const previousInverseProbability = bundle.$inverseProbability$;
  bundle.$inverseProbability$ = newInverseProbability;
  if (previousInverseProbability - bundle.$inverseProbability$ < 0.01) {
    return;
  }
  if (
    // don't queue until we have initialized the preloader
    base != null && bundle.$state$ < BundleImportState_Preload && bundle.$inverseProbability$ < config.$invPreloadProbability$
  ) {
    if (bundle.$state$ === BundleImportState_None) {
      bundle.$state$ = BundleImportState_Queued;
      queue.push(bundle);
      config.$DEBUG$ && log(`queued ${Math.round((1 - bundle.$inverseProbability$) * 100)}%`, bundle.$name$);
    }
    queueDirty = true;
  }
  if (bundle.$deps$) {
    seen || (seen = /* @__PURE__ */ new Set());
    seen.add(bundle);
    const probability = 1 - bundle.$inverseProbability$;
    for (const dep of bundle.$deps$) {
      const depBundle = getBundle(dep.$name$);
      if (depBundle.$inverseProbability$ === 0) {
        continue;
      }
      let newInverseProbability2;
      if (dep.$importProbability$ > 0.5 && (probability === 1 || probability >= 0.99 && depsCount < 100)) {
        depsCount++;
        newInverseProbability2 = Math.min(0.01, 1 - dep.$importProbability$);
      } else {
        const newInverseImportProbability = 1 - dep.$importProbability$ * probability;
        const prevAdjust = dep.$factor$;
        const factor = newInverseImportProbability / prevAdjust;
        newInverseProbability2 = Math.max(0.02, depBundle.$inverseProbability$ * factor);
        dep.$factor$ = factor;
      }
      adjustProbabilities(depBundle, newInverseProbability2, seen);
    }
  }
};
var handleBundle = (name, inverseProbability) => {
  const bundle = getBundle(name);
  if (bundle && bundle.$inverseProbability$ > inverseProbability) {
    adjustProbabilities(bundle, inverseProbability);
  }
};
var depsCount;
var preload = (name, probability) => {
  if (!(name == null ? void 0 : name.length)) {
    return;
  }
  depsCount = 0;
  let inverseProbability = probability ? 1 - probability : 0.4;
  if (Array.isArray(name)) {
    for (let i = name.length - 1; i >= 0; i--) {
      const item = name[i];
      if (typeof item === "number") {
        inverseProbability = 1 - item / 10;
      } else {
        handleBundle(item, inverseProbability);
      }
    }
  } else {
    handleBundle(name, inverseProbability);
  }
};
function flattenPrefetchResources(prefetchResources) {
  const urls = [];
  const addPrefetchResource = (prefetchResources2) => {
    if (prefetchResources2) {
      for (const prefetchResource of prefetchResources2) {
        if (!urls.includes(prefetchResource.url)) {
          urls.push(prefetchResource.url);
          if (prefetchResource.imports) {
            addPrefetchResource(prefetchResource.imports);
          }
        }
      }
    }
  };
  addPrefetchResource(prefetchResources);
  return urls;
}
var getBundles = (snapshotResult) => {
  var _a;
  const platform = getPlatform();
  return (_a = snapshotResult == null ? void 0 : snapshotResult.qrls) == null ? void 0 : _a.map((qrl) => {
    var _a2;
    const symbol = qrl.$refSymbol$ || qrl.$symbol$;
    const chunk = qrl.$chunk$;
    const result = platform.chunkForSymbol(symbol, chunk, (_a2 = qrl.dev) == null ? void 0 : _a2.file);
    if (result) {
      return result[1];
    }
    return chunk;
  }).filter(Boolean);
};
function getPreloadPaths(snapshotResult, opts, resolvedManifest) {
  const prefetchStrategy = opts.prefetchStrategy;
  if (prefetchStrategy === null) {
    return [];
  }
  if (!(resolvedManifest == null ? void 0 : resolvedManifest.manifest.bundleGraph)) {
    return getBundles(snapshotResult);
  }
  if (typeof (prefetchStrategy == null ? void 0 : prefetchStrategy.symbolsToPrefetch) === "function") {
    try {
      const prefetchResources = prefetchStrategy.symbolsToPrefetch({
        manifest: resolvedManifest.manifest
      });
      return flattenPrefetchResources(prefetchResources);
    } catch (e) {
      console.error("getPrefetchUrls, symbolsToPrefetch()", e);
    }
  }
  const symbols = /* @__PURE__ */ new Set();
  for (const qrl of (snapshotResult == null ? void 0 : snapshotResult.qrls) || []) {
    const symbol = getSymbolHash(qrl.$refSymbol$ || qrl.$symbol$);
    if (symbol && symbol.length >= 10) {
      symbols.add(symbol);
    }
  }
  return [...symbols];
}
var expandBundles = (names, resolvedManifest) => {
  if (!(resolvedManifest == null ? void 0 : resolvedManifest.manifest.bundleGraph)) {
    return [...new Set(names)];
  }
  resetQueue();
  let probability = 0.99;
  for (const name of names.slice(0, 15)) {
    preload(name, probability);
    probability *= 0.85;
  }
  return getQueue();
};
var simplifyPath = (base2, path) => {
  if (path == null) {
    return null;
  }
  const segments = `${base2}${path}`.split("/");
  const simplified = [];
  for (const segment of segments) {
    if (segment === ".." && simplified.length > 0) {
      simplified.pop();
    } else {
      simplified.push(segment);
    }
  }
  return simplified.join("/");
};
var preloaderPre = (base2, resolvedManifest, options, beforeContent, nonce) => {
  var _a;
  const preloaderPath = simplifyPath(base2, (_a = resolvedManifest == null ? void 0 : resolvedManifest.manifest) == null ? void 0 : _a.preloader);
  const bundleGraphPath = "/" + (resolvedManifest == null ? void 0 : resolvedManifest.manifest.bundleGraphAsset);
  if (preloaderPath && bundleGraphPath && options !== false) {
    const preloaderOpts = typeof options === "object" ? {
      debug: options.debug,
      preloadProbability: options.ssrPreloadProbability
    } : void 0;
    initPreloader(resolvedManifest == null ? void 0 : resolvedManifest.manifest.bundleGraph, preloaderOpts);
    const opts = [];
    if (options == null ? void 0 : options.debug) {
      opts.push("d:1");
    }
    if (options == null ? void 0 : options.maxIdlePreloads) {
      opts.push(`P:${options.maxIdlePreloads}`);
    }
    if (options == null ? void 0 : options.preloadProbability) {
      opts.push(`Q:${options.preloadProbability}`);
    }
    const optsStr = opts.length ? `,{${opts.join(",")}}` : "";
    const script = `let b=fetch("${bundleGraphPath}");import("${preloaderPath}").then(({l})=>l(${JSON.stringify(base2)},b${optsStr}));`;
    beforeContent.push(
      /**
       * We add modulepreloads even when the script is at the top because they already fire during
       * html download
       */
      jsx("link", { rel: "modulepreload", href: preloaderPath }),
      jsx("link", {
        rel: "preload",
        href: bundleGraphPath,
        as: "fetch",
        crossorigin: "anonymous"
      }),
      jsx("script", {
        type: "module",
        async: true,
        dangerouslySetInnerHTML: script,
        nonce
      })
    );
  }
  const corePath = simplifyPath(base2, resolvedManifest == null ? void 0 : resolvedManifest.manifest.core);
  if (corePath) {
    beforeContent.push(jsx("link", { rel: "modulepreload", href: corePath }));
  }
};
var includePreloader = (base2, resolvedManifest, options, referencedBundles, nonce) => {
  if (referencedBundles.length === 0 || options === false) {
    return null;
  }
  const { ssrPreloads, ssrPreloadProbability } = normalizePreLoaderOptions(
    typeof options === "boolean" ? void 0 : options
  );
  let allowed = ssrPreloads;
  const nodes = [];
  const links = [];
  const manifestHash = resolvedManifest == null ? void 0 : resolvedManifest.manifest.manifestHash;
  if (allowed) {
    const preloaderBundle = resolvedManifest == null ? void 0 : resolvedManifest.manifest.preloader;
    const coreBundle = resolvedManifest == null ? void 0 : resolvedManifest.manifest.core;
    const expandedBundles = expandBundles(referencedBundles, resolvedManifest);
    let probability = 4;
    const tenXMinProbability = ssrPreloadProbability * 10;
    for (const hrefOrProbability of expandedBundles) {
      if (typeof hrefOrProbability === "string") {
        if (probability < tenXMinProbability) {
          break;
        }
        if (hrefOrProbability === preloaderBundle || hrefOrProbability === coreBundle) {
          continue;
        }
        links.push(hrefOrProbability);
        if (--allowed === 0) {
          break;
        }
      } else {
        probability = hrefOrProbability;
      }
    }
  }
  const preloaderPath = simplifyPath(base2, manifestHash && (resolvedManifest == null ? void 0 : resolvedManifest.manifest.preloader));
  const insertLinks = links.length ? (
    /**
     * We only use modulepreload links because they behave best. Older browsers can rely on the
     * preloader which does feature detection and which will be available soon after inserting these
     * links.
     */
    `${JSON.stringify(links)}.map((l,e)=>{e=document.createElement('link');e.rel='modulepreload';e.href=${JSON.stringify(base2)}+l;document.head.appendChild(e)});`
  ) : "";
  let script = insertLinks;
  if (preloaderPath) {
    script += `window.addEventListener('load',f=>{f=_=>import("${preloaderPath}").then(({p})=>p(${JSON.stringify(referencedBundles)}));try{requestIdleCallback(f,{timeout:2000})}catch(e){setTimeout(f,200)}})`;
  }
  if (script) {
    nodes.push(
      jsx("script", {
        type: "module",
        "q:type": "preload",
        /**
         * This async allows the preloader to be executed before the DOM is fully parsed even though
         * it's at the bottom of the body
         */
        async: true,
        dangerouslySetInnerHTML: script,
        nonce
      })
    );
  }
  if (nodes.length > 0) {
    return jsx(Fragment, { children: nodes });
  }
  return null;
};
var preloaderPost = (base2, snapshotResult, opts, resolvedManifest, output) => {
  var _a;
  if (opts.preloader !== false) {
    const preloadBundles = getPreloadPaths(snapshotResult, opts, resolvedManifest);
    if (preloadBundles.length > 0) {
      const result = includePreloader(
        base2,
        resolvedManifest,
        opts.preloader,
        preloadBundles,
        (_a = opts.serverData) == null ? void 0 : _a.nonce
      );
      if (result) {
        output.push(result);
      }
    }
  }
};
function normalizePreLoaderOptions(input) {
  return { ...PreLoaderOptionsDefault, ...input };
}
var PreLoaderOptionsDefault = {
  ssrPreloads: 7,
  ssrPreloadProbability: 0.5,
  debug: false,
  maxIdlePreloads: 25,
  preloadProbability: 0.35
};
var QWIK_LOADER_DEFAULT_MINIFIED = 'const t=document,e=window,n=new Set,o=new Set([t]);let r;const s=(t,e)=>Array.from(t.querySelectorAll(e)),i=t=>{const e=[];return o.forEach((n=>e.push(...s(n,t)))),e},a=t=>{g(t),s(t,"[q\\\\:shadowroot]").forEach((t=>{const e=t.shadowRoot;e&&a(e)}))},c=t=>t&&"function"==typeof t.then;let l=!0;const f=(t,e,n=e.type)=>{let o=l;i("[on"+t+"\\\\:"+n+"]").forEach((r=>{o=!0,b(r,t,e,n)})),o||window[t.slice(1)].removeEventListener(n,"-window"===t?d:_)},p=e=>{if(void 0===e._qwikjson_){let n=(e===t.documentElement?t.body:e).lastElementChild;for(;n;){if("SCRIPT"===n.tagName&&"qwik/json"===n.getAttribute("type")){e._qwikjson_=JSON.parse(n.textContent.replace(/\\\\x3C(\\/?script)/gi,"<$1"));break}n=n.previousElementSibling}}},u=(t,e)=>new CustomEvent(t,{detail:e}),b=async(e,n,o,r=o.type)=>{const s="on"+n+":"+r;e.hasAttribute("preventdefault:"+r)&&o.preventDefault(),e.hasAttribute("stoppropagation:"+r)&&o.stopPropagation();const i=e._qc_,a=i&&i.li.filter((t=>t[0]===s));if(a&&a.length>0){for(const t of a){const n=t[1].getFn([e,o],(()=>e.isConnected))(o,e),r=o.cancelBubble;c(n)&&await n,r&&o.stopPropagation()}return}const l=e.getAttribute(s);if(l){const n=e.closest("[q\\\\:container]"),r=n.getAttribute("q:base"),s=n.getAttribute("q:version")||"unknown",i=n.getAttribute("q:manifest-hash")||"dev",a=new URL(r,t.baseURI);for(const f of l.split("\\n")){const l=new URL(f,a),u=l.href,b=l.hash.replace(/^#?([^?[|]*).*$/,"$1")||"default",q=performance.now();let _,d,w;const m=f.startsWith("#"),y={qBase:r,qManifest:i,qVersion:s,href:u,symbol:b,element:e,reqTime:q};if(m){const e=n.getAttribute("q:instance");_=(t["qFuncs_"+e]||[])[Number.parseInt(b)],_||(d="sync",w=Error("sym:"+b))}else{h("qsymbol",y);const t=l.href.split("#")[0];try{const e=import(t);p(n),_=(await e)[b],_||(d="no-symbol",w=Error(`${b} not in ${t}`))}catch(t){d||(d="async"),w=t}}if(!_){h("qerror",{importError:d,error:w,...y}),console.error(w);break}const g=t.__q_context__;if(e.isConnected)try{t.__q_context__=[e,o,l];const n=_(o,e);c(n)&&await n}catch(t){h("qerror",{error:t,...y})}finally{t.__q_context__=g}}}},h=(e,n)=>{t.dispatchEvent(u(e,n))},q=t=>t.replace(/([A-Z])/g,(t=>"-"+t.toLowerCase())),_=async t=>{let e=q(t.type),n=t.target;for(f("-document",t,e);n&&n.getAttribute;){const o=b(n,"",t,e);let r=t.cancelBubble;c(o)&&await o,r||(r=r||t.cancelBubble||n.hasAttribute("stoppropagation:"+t.type)),n=t.bubbles&&!0!==r?n.parentElement:null}},d=t=>{f("-window",t,q(t.type))},w=()=>{var s;const c=t.readyState;if(!r&&("interactive"==c||"complete"==c)&&(o.forEach(a),r=1,h("qinit"),(null!=(s=e.requestIdleCallback)?s:e.setTimeout).bind(e)((()=>h("qidle"))),n.has("qvisible"))){const t=i("[on\\\\:qvisible]"),e=new IntersectionObserver((t=>{for(const n of t)n.isIntersecting&&(e.unobserve(n.target),b(n.target,"",u("qvisible",n)))}));t.forEach((t=>e.observe(t)))}},m=(t,e,n,o=!1)=>{t.addEventListener(e,n,{capture:o,passive:!1})};let y;const g=(...t)=>{l=!0,clearTimeout(y),y=setTimeout((()=>l=!1),2e4);for(const r of t)"string"==typeof r?n.has(r)||(o.forEach((t=>m(t,r,_,!0))),m(e,r,d,!0),n.add(r)):o.has(r)||(n.forEach((t=>m(r,t,_,!0))),o.add(r))};if(!("__q_context__"in t)){t.__q_context__=0;const r=e.qwikevents;r&&(Array.isArray(r)?g(...r):g("click","input")),e.qwikevents={events:n,roots:o,push:g},m(t,"readystatechange",w),w()}';
var QWIK_LOADER_DEFAULT_DEBUG = 'const doc = document;\nconst win = window;\nconst events = /* @__PURE__ */ new Set();\nconst roots = /* @__PURE__ */ new Set([doc]);\nlet hasInitialized;\nconst nativeQuerySelectorAll = (root, selector) => Array.from(root.querySelectorAll(selector));\nconst querySelectorAll = (query) => {\n  const elements = [];\n  roots.forEach((root) => elements.push(...nativeQuerySelectorAll(root, query)));\n  return elements;\n};\nconst findShadowRoots = (fragment) => {\n  processEventOrNode(fragment);\n  nativeQuerySelectorAll(fragment, "[q\\\\:shadowroot]").forEach((parent) => {\n    const shadowRoot = parent.shadowRoot;\n    shadowRoot && findShadowRoots(shadowRoot);\n  });\n};\nconst isPromise = (promise) => promise && typeof promise.then === "function";\nlet doNotClean = true;\nconst broadcast = (infix, ev, type = ev.type) => {\n  let found = doNotClean;\n  querySelectorAll("[on" + infix + "\\\\:" + type + "]").forEach((el) => {\n    found = true;\n    dispatch(el, infix, ev, type);\n  });\n  if (!found) {\n    window[infix.slice(1)].removeEventListener(\n      type,\n      infix === "-window" ? processWindowEvent : processDocumentEvent\n    );\n  }\n};\nconst resolveContainer = (containerEl) => {\n  if (containerEl._qwikjson_ === void 0) {\n    const parentJSON = containerEl === doc.documentElement ? doc.body : containerEl;\n    let script = parentJSON.lastElementChild;\n    while (script) {\n      if (script.tagName === "SCRIPT" && script.getAttribute("type") === "qwik/json") {\n        containerEl._qwikjson_ = JSON.parse(\n          script.textContent.replace(/\\\\x3C(\\/?script)/gi, "<$1")\n        );\n        break;\n      }\n      script = script.previousElementSibling;\n    }\n  }\n};\nconst createEvent = (eventName, detail) => new CustomEvent(eventName, {\n  detail\n});\nconst dispatch = async (element, onPrefix, ev, eventName = ev.type) => {\n  const attrName = "on" + onPrefix + ":" + eventName;\n  if (element.hasAttribute("preventdefault:" + eventName)) {\n    ev.preventDefault();\n  }\n  if (element.hasAttribute("stoppropagation:" + eventName)) {\n    ev.stopPropagation();\n  }\n  const ctx = element._qc_;\n  const relevantListeners = ctx && ctx.li.filter((li) => li[0] === attrName);\n  if (relevantListeners && relevantListeners.length > 0) {\n    for (const listener of relevantListeners) {\n      const results = listener[1].getFn([element, ev], () => element.isConnected)(ev, element);\n      const cancelBubble = ev.cancelBubble;\n      if (isPromise(results)) {\n        await results;\n      }\n      if (cancelBubble) {\n        ev.stopPropagation();\n      }\n    }\n    return;\n  }\n  const attrValue = element.getAttribute(attrName);\n  if (attrValue) {\n    const container = element.closest("[q\\\\:container]");\n    const qBase = container.getAttribute("q:base");\n    const qVersion = container.getAttribute("q:version") || "unknown";\n    const qManifest = container.getAttribute("q:manifest-hash") || "dev";\n    const base = new URL(qBase, doc.baseURI);\n    for (const qrl of attrValue.split("\\n")) {\n      const url = new URL(qrl, base);\n      const href = url.href;\n      const symbol = url.hash.replace(/^#?([^?[|]*).*$/, "$1") || "default";\n      const reqTime = performance.now();\n      let handler;\n      let importError;\n      let error;\n      const isSync = qrl.startsWith("#");\n      const eventData = {\n        qBase,\n        qManifest,\n        qVersion,\n        href,\n        symbol,\n        element,\n        reqTime\n      };\n      if (isSync) {\n        const hash = container.getAttribute("q:instance");\n        handler = (doc["qFuncs_" + hash] || [])[Number.parseInt(symbol)];\n        if (!handler) {\n          importError = "sync";\n          error = new Error("sym:" + symbol);\n        }\n      } else {\n        emitEvent("qsymbol", eventData);\n        const uri = url.href.split("#")[0];\n        try {\n          const module = import(\n                        uri\n          );\n          resolveContainer(container);\n          handler = (await module)[symbol];\n          if (!handler) {\n            importError = "no-symbol";\n            error = new Error(`${symbol} not in ${uri}`);\n          }\n        } catch (err) {\n          importError || (importError = "async");\n          error = err;\n        }\n      }\n      if (!handler) {\n        emitEvent("qerror", {\n          importError,\n          error,\n          ...eventData\n        });\n        console.error(error);\n        break;\n      }\n      const previousCtx = doc.__q_context__;\n      if (element.isConnected) {\n        try {\n          doc.__q_context__ = [element, ev, url];\n          const results = handler(ev, element);\n          if (isPromise(results)) {\n            await results;\n          }\n        } catch (error2) {\n          emitEvent("qerror", { error: error2, ...eventData });\n        } finally {\n          doc.__q_context__ = previousCtx;\n        }\n      }\n    }\n  }\n};\nconst emitEvent = (eventName, detail) => {\n  doc.dispatchEvent(createEvent(eventName, detail));\n};\nconst camelToKebab = (str) => str.replace(/([A-Z])/g, (a) => "-" + a.toLowerCase());\nconst processDocumentEvent = async (ev) => {\n  let type = camelToKebab(ev.type);\n  let element = ev.target;\n  broadcast("-document", ev, type);\n  while (element && element.getAttribute) {\n    const results = dispatch(element, "", ev, type);\n    let cancelBubble = ev.cancelBubble;\n    if (isPromise(results)) {\n      await results;\n    }\n    cancelBubble || (cancelBubble = cancelBubble || ev.cancelBubble || element.hasAttribute("stoppropagation:" + ev.type));\n    element = ev.bubbles && cancelBubble !== true ? element.parentElement : null;\n  }\n};\nconst processWindowEvent = (ev) => {\n  broadcast("-window", ev, camelToKebab(ev.type));\n};\nconst processReadyStateChange = () => {\n  var _a;\n  const readyState = doc.readyState;\n  if (!hasInitialized && (readyState == "interactive" || readyState == "complete")) {\n    roots.forEach(findShadowRoots);\n    hasInitialized = 1;\n    emitEvent("qinit");\n    const riC = (_a = win.requestIdleCallback) != null ? _a : win.setTimeout;\n    riC.bind(win)(() => emitEvent("qidle"));\n    if (events.has("qvisible")) {\n      const results = querySelectorAll("[on\\\\:qvisible]");\n      const observer = new IntersectionObserver((entries) => {\n        for (const entry of entries) {\n          if (entry.isIntersecting) {\n            observer.unobserve(entry.target);\n            dispatch(entry.target, "", createEvent("qvisible", entry));\n          }\n        }\n      });\n      results.forEach((el) => observer.observe(el));\n    }\n  }\n};\nconst addEventListener = (el, eventName, handler, capture = false) => {\n  el.addEventListener(eventName, handler, { capture, passive: false });\n};\nlet cleanTimer;\nconst processEventOrNode = (...eventNames) => {\n  doNotClean = true;\n  clearTimeout(cleanTimer);\n  cleanTimer = setTimeout(() => doNotClean = false, 2e4);\n  for (const eventNameOrNode of eventNames) {\n    if (typeof eventNameOrNode === "string") {\n      if (!events.has(eventNameOrNode)) {\n        roots.forEach(\n          (root) => addEventListener(root, eventNameOrNode, processDocumentEvent, true)\n        );\n        addEventListener(win, eventNameOrNode, processWindowEvent, true);\n        events.add(eventNameOrNode);\n      }\n    } else {\n      if (!roots.has(eventNameOrNode)) {\n        events.forEach(\n          (eventName) => addEventListener(eventNameOrNode, eventName, processDocumentEvent, true)\n        );\n        roots.add(eventNameOrNode);\n      }\n    }\n  }\n};\nif (!("__q_context__" in doc)) {\n  doc.__q_context__ = 0;\n  const qwikevents = win.qwikevents;\n  if (qwikevents) {\n    if (Array.isArray(qwikevents)) {\n      processEventOrNode(...qwikevents);\n    } else {\n      processEventOrNode("click", "input");\n    }\n  }\n  win.qwikevents = {\n    events,\n    roots,\n    push: processEventOrNode\n  };\n  addEventListener(doc, "readystatechange", processReadyStateChange);\n  processReadyStateChange();\n}';
function getQwikLoaderScript(opts = {}) {
  return opts.debug ? QWIK_LOADER_DEFAULT_DEBUG : QWIK_LOADER_DEFAULT_MINIFIED;
}
function createTimer() {
  if (typeof performance === "undefined") {
    return () => 0;
  }
  const start = performance.now();
  return () => {
    const end = performance.now();
    const delta = end - start;
    return delta / 1e6;
  };
}
function getBuildBase(opts) {
  let base2 = opts.base;
  if (typeof opts.base === "function") {
    base2 = opts.base(opts);
  }
  if (typeof base2 === "string") {
    if (!base2.endsWith("/")) {
      base2 += "/";
    }
    return base2;
  }
  return `${"/"}build/`;
}
var DOCTYPE = "<!DOCTYPE html>";
async function renderToStream(rootNode, opts) {
  var _a, _b, _c;
  let stream = opts.stream;
  let bufferSize = 0;
  let totalSize = 0;
  let networkFlushes = 0;
  let firstFlushTime = 0;
  let buffer = "";
  let snapshotResult;
  const inOrderStreaming = ((_a = opts.streaming) == null ? void 0 : _a.inOrder) ?? {
    strategy: "auto",
    maximunInitialChunk: 5e4,
    maximunChunk: 3e4
  };
  const containerTagName = opts.containerTagName ?? "html";
  const containerAttributes = opts.containerAttributes ?? {};
  const nativeStream = stream;
  const firstFlushTimer = createTimer();
  const buildBase = getBuildBase(opts);
  const resolvedManifest = resolveManifest(opts.manifest);
  function flush() {
    if (buffer) {
      nativeStream.write(buffer);
      buffer = "";
      bufferSize = 0;
      networkFlushes++;
      if (networkFlushes === 1) {
        firstFlushTime = firstFlushTimer();
      }
    }
  }
  function enqueue(chunk) {
    const len = chunk.length;
    bufferSize += len;
    totalSize += len;
    buffer += chunk;
  }
  switch (inOrderStreaming.strategy) {
    case "disabled":
      stream = {
        write: enqueue
      };
      break;
    case "direct":
      stream = nativeStream;
      break;
    case "auto":
      let count = 0;
      let forceFlush = false;
      const minimunChunkSize = inOrderStreaming.maximunChunk ?? 0;
      const initialChunkSize = inOrderStreaming.maximunInitialChunk ?? 0;
      stream = {
        write(chunk) {
          if (chunk === "<!--qkssr-f-->") {
            forceFlush || (forceFlush = true);
          } else if (chunk === "<!--qkssr-pu-->") {
            count++;
          } else if (chunk === "<!--qkssr-po-->") {
            count--;
          } else {
            enqueue(chunk);
          }
          const chunkSize = networkFlushes === 0 ? initialChunkSize : minimunChunkSize;
          if (count === 0 && (forceFlush || bufferSize >= chunkSize)) {
            forceFlush = false;
            flush();
          }
        }
      };
      break;
  }
  if (containerTagName === "html") {
    stream.write(DOCTYPE);
  } else {
    stream.write("<!--cq-->");
  }
  if (!resolvedManifest && true) {
    console.warn(
      `Missing client manifest, loading symbols in the client might 404. Please ensure the client build has run and generated the manifest for the server build.`
    );
  }
  await setServerPlatform(opts, resolvedManifest);
  const injections = resolvedManifest == null ? void 0 : resolvedManifest.manifest.injections;
  const beforeContent = injections ? injections.map((injection) => jsx(injection.tag, injection.attributes ?? {})) : [];
  const includeMode = ((_b = opts.qwikLoader) == null ? void 0 : _b.include) ?? "auto";
  const qwikLoaderChunk = resolvedManifest == null ? void 0 : resolvedManifest.manifest.qwikLoader;
  let didAddQwikLoader = false;
  if (includeMode !== "never" && qwikLoaderChunk) {
    beforeContent.unshift(
      jsx("link", { rel: "modulepreload", href: `${buildBase}${qwikLoaderChunk}` }),
      jsx("script", {
        type: "module",
        async: true,
        src: `${buildBase}${qwikLoaderChunk}`
      })
    );
    didAddQwikLoader = true;
  }
  preloaderPre(buildBase, resolvedManifest, opts.preloader, beforeContent, (_c = opts.serverData) == null ? void 0 : _c.nonce);
  const renderTimer = createTimer();
  const renderSymbols = [];
  let renderTime = 0;
  let snapshotTime = 0;
  await _renderSSR(rootNode, {
    stream,
    containerTagName,
    containerAttributes,
    serverData: opts.serverData,
    base: buildBase,
    beforeContent,
    beforeClose: async (contexts, containerState, _dynamic, textNodes) => {
      var _a2, _b2, _c2, _d;
      renderTime = renderTimer();
      const snapshotTimer = createTimer();
      snapshotResult = await _pauseFromContexts(contexts, containerState, void 0, textNodes);
      const children = [];
      preloaderPost(buildBase, snapshotResult, opts, resolvedManifest, children);
      const jsonData = JSON.stringify(snapshotResult.state, void 0, void 0);
      children.push(
        jsx("script", {
          type: "qwik/json",
          dangerouslySetInnerHTML: escapeText(jsonData),
          nonce: (_a2 = opts.serverData) == null ? void 0 : _a2.nonce
        })
      );
      if (snapshotResult.funcs.length > 0) {
        const hash2 = containerAttributes[QInstance];
        children.push(
          jsx("script", {
            "q:func": "qwik/json",
            dangerouslySetInnerHTML: serializeFunctions(hash2, snapshotResult.funcs),
            nonce: (_b2 = opts.serverData) == null ? void 0 : _b2.nonce
          })
        );
      }
      const needLoader = !snapshotResult || snapshotResult.mode !== "static";
      const includeLoader = includeMode === "always" || includeMode === "auto" && needLoader;
      if (!didAddQwikLoader && includeLoader) {
        const qwikLoaderScript = getQwikLoaderScript({
          debug: opts.debug
        });
        children.push(
          jsx("script", {
            id: "qwikloader",
            // execute even before DOM order
            async: true,
            type: "module",
            dangerouslySetInnerHTML: qwikLoaderScript,
            nonce: (_c2 = opts.serverData) == null ? void 0 : _c2.nonce
          })
        );
      }
      const extraListeners = Array.from(containerState.$events$, (s) => JSON.stringify(s));
      if (extraListeners.length > 0) {
        const content = `(window.qwikevents||(window.qwikevents=[])).push(${extraListeners.join(",")})`;
        children.push(
          jsx("script", {
            dangerouslySetInnerHTML: content,
            nonce: (_d = opts.serverData) == null ? void 0 : _d.nonce
          })
        );
      }
      collectRenderSymbols(renderSymbols, contexts);
      snapshotTime = snapshotTimer();
      return jsx(Fragment, { children });
    },
    manifestHash: (resolvedManifest == null ? void 0 : resolvedManifest.manifest.manifestHash) || "dev" + hash()
  });
  if (containerTagName !== "html") {
    stream.write("<!--/cq-->");
  }
  flush();
  const isDynamic = snapshotResult.resources.some((r) => r._cache !== Infinity);
  const result = {
    prefetchResources: void 0,
    snapshotResult,
    flushes: networkFlushes,
    manifest: resolvedManifest == null ? void 0 : resolvedManifest.manifest,
    size: totalSize,
    isStatic: !isDynamic,
    timing: {
      render: renderTime,
      snapshot: snapshotTime,
      firstFlush: firstFlushTime
    }
  };
  return result;
}
function hash() {
  return Math.random().toString(36).slice(2);
}
function resolveManifest(manifest$1) {
  const mergedManifest = manifest$1 ? { ...manifest, ...manifest$1 } : manifest;
  if (!mergedManifest || "mapper" in mergedManifest) {
    return mergedManifest;
  }
  if (mergedManifest.mapping) {
    const mapper = {};
    Object.entries(mergedManifest.mapping).forEach(([symbol, bundleFilename]) => {
      mapper[getSymbolHash(symbol)] = [symbol, bundleFilename];
    });
    return {
      mapper,
      manifest: mergedManifest,
      injections: mergedManifest.injections || []
    };
  }
  return void 0;
}
var escapeText = (str) => {
  return str.replace(/<(\/?script)/gi, "\\x3C$1");
};
function collectRenderSymbols(renderSymbols, elements) {
  var _a;
  for (const ctx of elements) {
    const symbol = (_a = ctx.$componentQrl$) == null ? void 0 : _a.getSymbol();
    if (symbol && !renderSymbols.includes(symbol)) {
      renderSymbols.push(symbol);
    }
  }
}
var Q_FUNCS_PREFIX = 'document["qFuncs_HASH"]=';
function serializeFunctions(hash2, funcs) {
  return Q_FUNCS_PREFIX.replace("HASH", hash2) + `[${funcs.join(",\n")}]`;
}
async function setServerPlatform2(manifest2) {
  const platform = createPlatform({}, resolveManifest(manifest2));
  setPlatform(platform);
}
const s_0vphQYqOdZI = () => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
  const head = useDocumentHead();
  const loc = useLocation();
  const siteConfig = useSiteConfig();
  const siteTitle = ((_b = (_a = siteConfig.value) == null ? void 0 : _a.site) == null ? void 0 : _b.site_name) || head.title || "Card Issuing Web";
  const siteDesc = ((_d = (_c = siteConfig.value) == null ? void 0 : _c.site) == null ? void 0 : _d.site_desc) || "Card Issuing Web Application";
  const siteKeywords = ((_f = (_e = siteConfig.value) == null ? void 0 : _e.site) == null ? void 0 : _f.keywords) || "";
  const siteLogo = ((_h = (_g = siteConfig.value) == null ? void 0 : _g.site) == null ? void 0 : _h.site_logo) || "/favicon.svg";
  const customHtml = ((_j = (_i = siteConfig.value) == null ? void 0 : _i.site) == null ? void 0 : _j.custom_html) || "";
  return /* @__PURE__ */ _jsxC(Fragment, {
    children: [
      /* @__PURE__ */ _jsxQ("title", null, null, head.title || siteTitle, 1, null),
      /* @__PURE__ */ _jsxQ("meta", {
        content: ((_k = head.meta.find((m) => m.name === "description")) == null ? void 0 : _k.content) || siteDesc
      }, {
        name: "description"
      }, null, 3, null),
      siteKeywords && /* @__PURE__ */ _jsxQ("meta", {
        content: siteKeywords
      }, {
        name: "keywords"
      }, null, 3, "0D_0"),
      /* @__PURE__ */ _jsxQ("link", null, {
        rel: "canonical",
        href: _fnSignal((p0) => p0.url.href, [
          loc
        ], "p0.url.href")
      }, null, 3, null),
      /* @__PURE__ */ _jsxQ("meta", null, {
        name: "viewport",
        content: "width=device-width, initial-scale=1.0"
      }, null, 3, null),
      /* @__PURE__ */ _jsxQ("link", {
        href: siteLogo
      }, {
        rel: "icon",
        type: "image/svg+xml"
      }, null, 3, null),
      head.meta.map((m) => /* @__PURE__ */ _jsxS("meta", {
        ...m
      }, null, 0, m.key)),
      head.links.map((l) => /* @__PURE__ */ _jsxS("link", {
        ...l
      }, null, 0, l.key)),
      head.styles.map((s) => {
        var _a2;
        return /* @__PURE__ */ _jsxS("style", {
          ...s.props,
          ...((_a2 = s.props) == null ? void 0 : _a2.dangerouslySetInnerHTML) ? {} : {
            dangerouslySetInnerHTML: s.style
          }
        }, null, 0, s.key);
      }),
      head.scripts.map((s) => {
        var _a2;
        return /* @__PURE__ */ _jsxS("script", {
          ...s.props,
          ...((_a2 = s.props) == null ? void 0 : _a2.dangerouslySetInnerHTML) ? {} : {
            dangerouslySetInnerHTML: s.script
          }
        }, null, 0, s.key);
      }),
      customHtml && /* @__PURE__ */ _jsxQ("div", {
        dangerouslySetInnerHTML: customHtml
      }, null, null, 3, "0D_1")
    ]
  }, 1, "0D_2");
};
const RouterHead = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_0vphQYqOdZI, "s_0vphQYqOdZI"));
const s_tntnak2DhJ8 = () => {
  return /* @__PURE__ */ _jsxC(QwikCityProvider, {
    children: [
      /* @__PURE__ */ _jsxQ("head", null, null, [
        /* @__PURE__ */ _jsxQ("meta", null, {
          charset: "utf-8"
        }, null, 3, null),
        /* @__PURE__ */ _jsxQ("link", null, {
          rel: "manifest",
          href: `${"/"}manifest.json`
        }, null, 3, "vp_0"),
        /* @__PURE__ */ _jsxC(RouterHead, null, 3, "vp_1"),
        /* @__PURE__ */ _jsxQ("script", null, {
          "disable-devtool-auto": true,
          src: "https://cdn.jsdelivr.net/npm/disable-devtool@latest",
          "clear-log": "true",
          "disable-menu": "false",
          "disable-select": "false",
          "disable-copy": "false",
          "disable-cut": "false",
          "disable-paste": "false"
        }, null, 3, "vp_2")
      ], 1, null),
      /* @__PURE__ */ _jsxQ("body", null, {
        class: "bg-background text-foreground min-h-screen transition-colors"
      }, /* @__PURE__ */ _jsxC(RouterOutlet, null, 3, "vp_3"), 1, null)
    ]
  }, 1, "vp_4");
};
const Root = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_tntnak2DhJ8, "s_tntnak2DhJ8"));
function render(opts) {
  var _a;
  const themeManager = new ThemeManager((_a = opts.serverData) == null ? void 0 : _a.requestHeaders.cookie);
  const theme = themeManager.getRealTheme();
  return renderToStream(/* @__PURE__ */ _jsxC(Root, null, 3, "Qb_0"), {
    ...opts,
    // Use container attributes to set attributes on the html tag.
    containerAttributes: {
      lang: "zh-CN",
      class: theme,
      style: "color-scheme: " + theme,
      ...opts.containerAttributes
    },
    serverData: {
      ...opts.serverData
    }
  });
}
export {
  render as r,
  setServerPlatform2 as s
};
