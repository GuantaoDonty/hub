import"./q-Bot-3uzW.js";import{r as p}from"./q-BaA9MOgV.js";import"universal-cookie";export{p as default};
