import axios from "axios";
import { c as componentQrl, i as inlinedQrl, b as _jsxQ, d as _jsxBranch, e as _jsxC, f as _IMMUTABLE, L as LuCheck, g as _wrapSignal, h as LuAlertTriangle, j as _fnSignal, k as LuZap, l as LuX, m as _noopQrl, F as Fragment, n as LuLoader2, o as LuChevronLeft, p as _restProps, q as _jsxS, S as Slot, u as useSignal, r as useVisibleTaskQrl, s as useLexicalScope, t as useStore, w as useComputedQrl, x as LuCheckCircle, y as themeManager, z as LuCopy, A as routeLoaderQrl, B as useLocation, C as LuKey, D as LuAlertCircle, E as LuLoader, G as Layout_ } from "./q-_LNWSPPT.js";
import QRCode$1 from "qrcode";
import "universal-cookie";
function handleApiError(error) {
  console.error("API Error (server):", (error == null ? void 0 : error.message) || "Unknown error");
  return;
}
const request = axios.create({});
request.interceptors.request.use(async (config) => {
  const Authorization = config.Authorization;
  if (Authorization) config.headers.Authorization = Authorization;
  return config;
}, (error) => {
  console.error("Request config error:", error);
  return Promise.reject(error);
});
function processResponseError(response) {
  if (response.config.skipErrorHandler) throw response;
  handleApiError(response);
  throw response;
}
request.interceptors.response.use((response) => {
  var _a;
  if (((_a = response.data) == null ? void 0 : _a.code) !== 200) return processResponseError(response);
  return response;
}, (error) => {
  console.error("Response error:", error);
  handleApiError(error);
  return Promise.reject(error);
});
async function userLogin(body, options) {
  return request("/v1/auth/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    data: body,
    ...options || {}
  });
}
async function getGlobalConfig(options) {
  return request("/v1/common/site/config", {
    method: "GET",
    ...options || {}
  });
}
var define_import_meta_env_default$1 = { BASE_URL: "/", DEV: false, MODE: "production", PROD: true, SSR: true };
let adminToken = null;
let tokenExpiry = 0;
let globalSiteConfig = null;
let configExpiry = 0;
async function getGlobalSiteConfig(apiUrl) {
  const now = Date.now();
  if (globalSiteConfig && configExpiry > now + 18e5) return globalSiteConfig;
  try {
    const options = apiUrl ? {
      baseURL: apiUrl
    } : {};
    const response = await getGlobalConfig(options);
    if (response.data.data) {
      globalSiteConfig = response.data.data;
      configExpiry = now + 216e5;
      console.log("全局站点配置已缓存");
      return globalSiteConfig;
    }
    console.error("获取全局站点配置失败：未获取到数据");
    return null;
  } catch (error) {
    console.error("获取全局站点配置失败：", error);
    return null;
  }
}
async function getAdminToken(apiUrl, adminEmail, adminPassword) {
  var _a;
  const now = Date.now();
  if (adminToken && tokenExpiry > now + 3e5) return adminToken;
  const email = adminEmail;
  const password = adminPassword;
  try {
    const options = apiUrl ? {
      baseURL: apiUrl
    } : {};
    const response = await userLogin({
      email,
      password
    }, options);
    const token = (_a = response.data.data) == null ? void 0 : _a.token;
    if (token) {
      adminToken = token;
      tokenExpiry = now + 864e5;
      console.log("管理员认证成功，token已缓存");
      return token;
    }
    console.error("管理员登录失败：未获取到token");
    return null;
  } catch (error) {
    console.error("管理员登录失败：", error);
    return null;
  }
}
const onRequest = async ({ next, env, sharedMap, json }) => {
  try {
    const buildTimeApiUrl = define_import_meta_env_default$1.API_URL;
    const runtimeApiUrl = env.get("API_URL");
    if (buildTimeApiUrl && runtimeApiUrl && buildTimeApiUrl !== runtimeApiUrl) {
      json(500, {
        success: false,
        error: "系统配置异常",
        message: "应用完整性验证失败，请联系技术支持",
        code: "CONFIG_INTEGRITY_ERROR"
      });
      return;
    }
    const adminEmail = env.get("ADMIN_EMAIL") || "admin@ppanel.dev";
    const adminPassword = env.get("ADMIN_PASSWORD") || "password";
    const apiUrl = runtimeApiUrl || buildTimeApiUrl || "";
    const baseAuthOptions = {
      baseURL: apiUrl
    };
    const token = await getAdminToken(apiUrl, adminEmail, adminPassword);
    const authOptions = token ? {
      ...baseAuthOptions,
      Authorization: token
    } : baseAuthOptions;
    sharedMap.set("authOptions", authOptions);
    const siteConfig = await getGlobalSiteConfig(apiUrl);
    if (siteConfig) sharedMap.set("globalSiteConfig", siteConfig);
    return next();
  } catch (error) {
    console.error("API中间件错误：", error);
    return next();
  }
};
function getCachedAdminToken() {
  return adminToken;
}
function getCachedGlobalSiteConfig() {
  return globalSiteConfig;
}
function clearAdminToken() {
  adminToken = null;
  tokenExpiry = 0;
}
function clearGlobalSiteConfig() {
  globalSiteConfig = null;
  configExpiry = 0;
}
function clearAllCache() {
  clearAdminToken();
  clearGlobalSiteConfig();
}
const ApiLayout_ = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  clearAdminToken,
  clearAllCache,
  clearGlobalSiteConfig,
  getCachedAdminToken,
  getCachedGlobalSiteConfig,
  onRequest
}, Symbol.toStringTag, { value: "Module" }));
const s_1aSnYa4cZNY = (props) => {
  const steps = [
    {
      step: 1,
      title: "选择服务",
      mobileTitle: "选择"
    },
    {
      step: 2,
      title: "确认订单",
      mobileTitle: "订单"
    },
    {
      step: 3,
      title: "支付订单",
      mobileTitle: "支付"
    },
    {
      step: 4,
      title: "获取兑换码",
      mobileTitle: "完成"
    }
  ];
  return /* @__PURE__ */ _jsxQ("div", null, {
    class: "bg-card/90 border-border/50 mb-6 border-b backdrop-blur-sm"
  }, /* @__PURE__ */ _jsxQ("div", null, {
    class: "mx-auto max-w-6xl px-4 py-4"
  }, /* @__PURE__ */ _jsxQ("div", null, {
    class: "flex items-center justify-center space-x-2 md:space-x-3"
  }, steps.map((item, index2) => /* @__PURE__ */ _jsxBranch(/* @__PURE__ */ _jsxQ("div", null, {
    class: "flex items-center"
  }, [
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "flex flex-col items-center"
    }, [
      /* @__PURE__ */ _jsxQ("div", {
        class: `flex h-7 w-7 items-center justify-center rounded-full text-xs font-medium transition-all duration-200 md:h-8 md:w-8 ${props.currentStep >= item.step ? "bg-primary text-primary-foreground ring-primary/20 shadow-sm ring-2" : "bg-muted/80 text-muted-foreground hover:bg-muted border-border/50 border"}`
      }, null, props.currentStep > item.step ? /* @__PURE__ */ _jsxC(LuCheck, {
        class: "h-3 w-3 md:h-4 md:w-4",
        [_IMMUTABLE]: {
          class: _IMMUTABLE
        }
      }, 3, "tA_0") : item.step, 1, null),
      /* @__PURE__ */ _jsxQ("span", {
        class: `mt-1.5 text-center text-xs font-medium transition-colors duration-200 ${props.currentStep >= item.step ? "text-foreground" : "text-muted-foreground/80"}`
      }, null, [
        /* @__PURE__ */ _jsxQ("span", null, {
          class: "hidden sm:inline"
        }, _wrapSignal(item, "title"), 1, null),
        /* @__PURE__ */ _jsxQ("span", null, {
          class: "sm:hidden"
        }, _wrapSignal(item, "mobileTitle"), 1, null)
      ], 1, null)
    ], 1, null),
    index2 < 3 && /* @__PURE__ */ _jsxQ("div", {
      class: `mx-1 h-0.5 w-4 transition-all duration-200 md:mx-3 md:w-8 ${props.currentStep > item.step ? "bg-primary/80" : "bg-border/60"}`
    }, null, null, 3, "tA_1")
  ], 1, item.step))), 1, null), 1, null), 1, "tA_2");
};
const StepIndicator = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_1aSnYa4cZNY, "s_1aSnYa4cZNY"));
const s_Vm4GdHPtpg4 = (props) => {
  _jsxBranch();
  if (!props.error) return null;
  return /* @__PURE__ */ _jsxQ("div", null, {
    class: "border-destructive/30 bg-destructive/5 mb-6 rounded-xl border p-4 shadow-sm backdrop-blur-sm"
  }, /* @__PURE__ */ _jsxQ("div", null, {
    class: "flex items-center"
  }, [
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "bg-destructive/10 text-destructive border-destructive/20 mr-3 flex h-8 w-8 items-center justify-center rounded-full border shadow-sm"
    }, /* @__PURE__ */ _jsxC(LuAlertTriangle, {
      class: "h-4 w-4",
      [_IMMUTABLE]: {
        class: _IMMUTABLE
      }
    }, 3, "NI_0"), 1, null),
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "min-w-0 flex-1"
    }, [
      /* @__PURE__ */ _jsxQ("h4", null, {
        class: "text-destructive text-sm font-medium"
      }, "出现错误", 3, null),
      /* @__PURE__ */ _jsxQ("p", null, {
        class: "text-destructive/80 mt-1 text-sm leading-relaxed"
      }, _fnSignal((p0) => p0.error, [
        props
      ], "p0.error"), 3, null)
    ], 3, null)
  ], 1, null), 1, "NI_1");
};
const ErrorDisplay = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_Vm4GdHPtpg4, "s_Vm4GdHPtpg4"));
function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return "0 GB";
  const k = 1024;
  const sizes = [
    "B",
    "KB",
    "MB",
    "GB",
    "TB",
    "PB",
    "EB",
    "ZB",
    "YB"
  ];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(decimals)) + " " + sizes[i];
}
const unitTimeMap = {
  Day: "天",
  Hour: "小时",
  Minute: "分钟",
  Month: "月",
  NoLimit: "无限制",
  Year: "年"
};
const formatBytesWithUnlimited = (bytes) => {
  if (bytes === 0) return "无限制";
  return formatBytes(bytes);
};
const formatPrice = (priceInCents) => {
  return (priceInCents / 100).toFixed(2);
};
const formatTime = (seconds) => {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
};
const calculateDiscountedPrice = (product, qty) => {
  let discountRate = 0;
  if (product.discount && product.discount.length > 0) {
    const exactDiscount = product.discount.find((d) => d.quantity === qty);
    if (exactDiscount) discountRate = 100 - exactDiscount.discount;
  }
  const originalPrice = product.unit_price * qty;
  return {
    originalPrice,
    discountedPrice: originalPrice * (1 - discountRate / 100),
    discountRate,
    savings: originalPrice * (discountRate / 100)
  };
};
const getQuantityOptions = (product) => {
  const options = [
    1
  ];
  const isYear = product.unit_time === "Year";
  if (product.discount && product.discount.length > 0) product.discount.forEach((d) => {
    if (!options.includes(d.quantity)) options.push(d.quantity);
  });
  if (isYear)
    [
      2,
      3
    ].forEach((qty) => {
      if (!options.includes(qty)) options.push(qty);
    });
  else
    [
      3,
      6,
      12
    ].forEach((qty) => {
      if (!options.includes(qty)) options.push(qty);
    });
  return options.sort((a, b) => a - b);
};
const getOrderStatusDisplay = (status) => {
  switch (status) {
    case "1":
      return {
        text: "待支付",
        color: "text-yellow-600",
        bgColor: "bg-yellow-50",
        borderColor: "border-yellow-200",
        icon: "⏳"
      };
    case "2":
      return {
        text: "已支付",
        color: "text-green-600",
        bgColor: "bg-green-50",
        borderColor: "border-green-200",
        icon: "✅"
      };
    case "3":
      return {
        text: "已取消",
        color: "text-red-600",
        bgColor: "bg-red-50",
        borderColor: "border-red-200",
        icon: "❌"
      };
    case "4":
      return {
        text: "已关闭",
        color: "text-gray-600",
        bgColor: "bg-gray-50",
        borderColor: "border-gray-200",
        icon: "🔒"
      };
    case "5":
      return {
        text: "已完成",
        color: "text-blue-600",
        bgColor: "bg-blue-50",
        borderColor: "border-blue-200",
        icon: "🎉"
      };
    default:
      return {
        text: "未知状态",
        color: "text-gray-600",
        bgColor: "bg-gray-50",
        borderColor: "border-gray-200",
        icon: "❓"
      };
  }
};
const s_mPQ6C7ycb5Q = (props) => {
  return /* @__PURE__ */ _jsxQ("div", null, {
    class: "space-y-4"
  }, [
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "from-accent/40 via-accent/25 to-accent/15 border-accent-foreground/20 rounded-xl border bg-gradient-to-r p-3 shadow-sm backdrop-blur-sm md:p-4"
    }, /* @__PURE__ */ _jsxQ("div", null, {
      class: "flex items-center justify-between"
    }, [
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "flex min-w-0 flex-1 items-center space-x-2 md:space-x-3"
      }, [
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "bg-accent text-accent-foreground flex-shrink-0 rounded-lg p-1.5 shadow-sm md:p-2"
        }, /* @__PURE__ */ _jsxC(LuZap, {
          class: "h-4 w-4 md:h-5 md:w-5",
          [_IMMUTABLE]: {
            class: _IMMUTABLE
          }
        }, 3, "oh_0"), 1, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "min-w-0 flex-1"
        }, [
          /* @__PURE__ */ _jsxQ("h3", null, {
            class: "text-foreground text-sm font-semibold md:text-base"
          }, "已有兑换码？", 3, null),
          /* @__PURE__ */ _jsxQ("p", null, {
            class: "text-muted-foreground/80 truncate text-xs md:text-sm"
          }, "输入兑换码即可快速开通服务", 3, null)
        ], 3, null)
      ], 1, null),
      /* @__PURE__ */ _jsxQ("a", null, {
        href: "/redeem",
        class: "bg-primary text-primary-foreground hover:bg-primary/90 focus-visible:ring-primary focus-visible:ring-offset-background ml-2 inline-flex h-8 flex-shrink-0 items-center justify-center rounded-lg px-3 text-xs font-medium shadow-sm transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none md:h-10 md:px-4 md:text-sm"
      }, [
        /* @__PURE__ */ _jsxQ("span", null, {
          class: "hidden sm:inline"
        }, "立即激活", 3, null),
        /* @__PURE__ */ _jsxQ("span", null, {
          class: "sm:hidden"
        }, "激活", 3, null)
      ], 3, null)
    ], 1, null), 1, null),
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "space-y-2 text-center"
    }, [
      /* @__PURE__ */ _jsxQ("h2", null, {
        class: "text-foreground mb-1 text-xl font-semibold tracking-tight md:text-2xl"
      }, "选择适合您的服务套餐", 3, null),
      /* @__PURE__ */ _jsxQ("p", null, {
        class: "text-muted-foreground/80 mx-auto max-w-md text-sm"
      }, "多种套餐任您选择，满足不同使用需求", 3, null)
    ], 3, null),
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "grid gap-3 sm:grid-cols-2 md:gap-4 lg:grid-cols-3 xl:grid-cols-4"
    }, props.products.map((product) => /* @__PURE__ */ _jsxQ("div", null, {
      class: "group border-border bg-card hover:border-accent-foreground/40 hover:bg-card/80 rounded-xl border-2 p-3 backdrop-blur-sm transition-all duration-200 hover:shadow-md md:p-4"
    }, [
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "mb-3"
      }, /* @__PURE__ */ _jsxQ("div", null, {
        class: "mb-2 flex items-start justify-between"
      }, [
        /* @__PURE__ */ _jsxQ("h3", null, {
          class: "text-card-foreground group-hover:text-foreground flex-1 pr-2 text-base font-semibold transition-colors duration-200 md:text-lg"
        }, _wrapSignal(product, "name"), 1, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "ml-2 flex-shrink-0 text-right"
        }, [
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "text-primary text-base font-semibold md:text-lg"
          }, [
            "¥",
            formatPrice(product.unit_price),
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-muted-foreground/70 ml-1 text-xs font-medium"
            }, [
              "/",
              unitTimeMap[product.unit_time] || product.unit_time
            ], 1, null)
          ], 1, null),
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "mt-1 h-6"
          }, product.discount && product.discount.length > 0 && /* @__PURE__ */ _jsxQ("div", null, {
            class: "bg-primary/10 text-primary border-primary/20 inline-flex items-center rounded-full border px-1.5 py-0.5 text-xs font-medium md:px-2 md:py-1"
          }, [
            "🎉 最高优惠",
            Math.max(...product.discount.map((d) => 100 - d.discount)),
            "%"
          ], 1, "oh_1"), 1, null)
        ], 1, null)
      ], 1, null), 1, null),
      (typeof product.description === "object" && (product.description.description || product.description.features.length > 0) || typeof product.description === "string" && product.description.trim()) && /* @__PURE__ */ _jsxQ("div", null, {
        class: "mb-3"
      }, typeof product.description === "object" ? /* @__PURE__ */ _jsxQ("div", null, null, [
        product.description.description && /* @__PURE__ */ _jsxQ("p", null, {
          class: "text-muted-foreground/90 mb-2 text-xs leading-relaxed"
        }, _wrapSignal(product.description, "description"), 1, "oh_2"),
        product.description.features.length > 0 && /* @__PURE__ */ _jsxQ("div", null, {
          class: "space-y-1"
        }, product.description.features.map((feature, index2) => /* @__PURE__ */ _jsxBranch(/* @__PURE__ */ _jsxQ("div", null, {
          class: "hover:bg-muted/50 flex items-center space-x-2 rounded-md p-1 transition-colors duration-150"
        }, [
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "flex-shrink-0"
          }, feature.type === "success" ? /* @__PURE__ */ _jsxQ("div", null, {
            class: "bg-primary/15 text-primary ring-primary/20 rounded-full p-0.5 ring-1"
          }, /* @__PURE__ */ _jsxC(LuCheck, {
            class: "h-3 w-3",
            [_IMMUTABLE]: {
              class: _IMMUTABLE
            }
          }, 3, "oh_3"), 1, "oh_4") : feature.type === "destructive" ? /* @__PURE__ */ _jsxQ("div", null, {
            class: "bg-destructive/15 text-destructive ring-destructive/20 rounded-full p-0.5 ring-1"
          }, /* @__PURE__ */ _jsxC(LuX, {
            class: "h-3 w-3",
            [_IMMUTABLE]: {
              class: _IMMUTABLE
            }
          }, 3, "oh_5"), 1, "oh_6") : feature.icon && /* @__PURE__ */ _jsxQ("span", null, {
            class: "text-sm opacity-80"
          }, _wrapSignal(feature, "icon"), 1, "oh_7"), 1, null),
          /* @__PURE__ */ _jsxQ("span", {
            class: `text-xs font-medium ${feature.type === "success" ? "text-primary" : feature.type === "destructive" ? "text-destructive" : "text-muted-foreground/80"}`
          }, null, _wrapSignal(feature, "label"), 1, null)
        ], 1, index2))), 1, "oh_8")
      ], 1, "oh_9") : /* @__PURE__ */ _jsxQ("p", null, {
        class: "text-muted-foreground/90 text-xs leading-relaxed"
      }, _wrapSignal(product, "description"), 1, null), 1, "oh_10"),
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "bg-muted/50 border-border/50 mb-3 rounded-lg border p-2 md:p-3"
      }, [
        /* @__PURE__ */ _jsxQ("h4", null, {
          class: "text-muted-foreground/80 mb-2 text-xs font-medium tracking-wide uppercase"
        }, "套餐规格", 3, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "space-y-1.5 text-xs"
        }, [
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "flex items-center justify-between"
          }, [
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-muted-foreground/70 flex items-center gap-1"
            }, "📊 流量", 3, null),
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-foreground font-medium"
            }, formatBytesWithUnlimited(product.traffic), 1, null)
          ], 1, null),
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "flex items-center justify-between"
          }, [
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-muted-foreground/70 flex items-center gap-1"
            }, "⚡ 速度", 3, null),
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-foreground font-medium"
            }, [
              formatBytesWithUnlimited(product.speed_limit),
              "/s"
            ], 1, null)
          ], 1, null),
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "flex items-center justify-between"
          }, [
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-muted-foreground/70 flex items-center gap-1"
            }, "📱 设备", 3, null),
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-foreground font-medium"
            }, product.device_limit === 0 ? "无限制" : `${product.device_limit}个`, 1, null)
          ], 1, null)
        ], 1, null)
      ], 1, null),
      /* @__PURE__ */ _jsxQ("button", {
        onClick$: /* @__PURE__ */ _noopQrl("s_uriPj4dOhLY", [
          product,
          props
        ])
      }, {
        class: "bg-primary text-primary-foreground hover:bg-primary/90 focus-visible:ring-primary focus-visible:ring-offset-background w-full rounded-lg px-4 py-2.5 text-sm font-medium shadow-sm transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50"
      }, "立即选购 ✨", 2, null)
    ], 1, product.id)), 1, null)
  ], 1, "oh_11");
};
const ProductSelector = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_mPQ6C7ycb5Q, "s_mPQ6C7ycb5Q"));
const s_yG9BTd3fEjw = (props) => {
  _jsxBranch();
  const displayUnit = unitTimeMap[props.selectedProduct.unit_time] || "月";
  return /* @__PURE__ */ _jsxQ("div", null, {
    class: "space-y-4"
  }, /* @__PURE__ */ _jsxQ("div", null, {
    class: "mx-auto max-w-4xl"
  }, /* @__PURE__ */ _jsxQ("div", null, {
    class: "grid gap-4 lg:grid-cols-3"
  }, [
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "lg:col-span-2"
    }, /* @__PURE__ */ _jsxQ("div", null, {
      class: "bg-card/90 border-border/50 rounded-xl border p-3 shadow-sm backdrop-blur-sm md:p-4"
    }, [
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "mb-4"
      }, [
        /* @__PURE__ */ _jsxQ("h3", null, {
          class: "mb-3 text-base font-semibold tracking-tight md:text-lg"
        }, "选择服务时长", 3, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "grid grid-cols-2 gap-2 md:grid-cols-3 md:gap-3"
        }, getQuantityOptions(props.selectedProduct).map((qty) => {
          const pricing = calculateDiscountedPrice(props.selectedProduct, qty);
          return /* @__PURE__ */ _jsxQ("button", {
            class: `group relative rounded-lg border p-3 text-center transition-colors duration-200 md:p-4 ${props.quantity === qty ? "border-primary/40 bg-primary/10 ring-primary/20 ring-1" : "border-border/60 bg-card hover:border-primary/30 hover:bg-primary/5"}`,
            onClick$: /* @__PURE__ */ _noopQrl("s_WYpzmq1XX0s", [
              props,
              qty
            ])
          }, null, [
            pricing.discountRate > 0 && /* @__PURE__ */ _jsxQ("div", null, {
              class: "bg-primary text-primary-foreground absolute -top-2 -right-2 rounded-full px-1.5 py-0.5 text-xs font-medium shadow-sm md:px-2 md:py-1"
            }, [
              "-",
              _wrapSignal(pricing, "discountRate"),
              "%"
            ], 1, "FN_0"),
            /* @__PURE__ */ _jsxQ("div", null, {
              class: "text-foreground text-lg font-semibold md:text-xl"
            }, [
              qty,
              displayUnit,
              " "
            ], 1, null),
            /* @__PURE__ */ _jsxQ("div", null, {
              class: "text-primary mt-1 text-base font-semibold md:mt-2 md:text-lg"
            }, [
              "¥",
              formatPrice(pricing.discountedPrice)
            ], 1, null),
            pricing.discountRate > 0 && /* @__PURE__ */ _jsxQ("div", null, {
              class: "text-muted-foreground/70 mt-1 text-xs line-through"
            }, [
              "¥",
              formatPrice(pricing.originalPrice)
            ], 1, "FN_1")
          ], 0, qty);
        }), 1, null)
      ], 1, null),
      /* @__PURE__ */ _jsxQ("div", null, null, [
        /* @__PURE__ */ _jsxQ("h3", null, {
          class: "mb-3 text-base font-semibold tracking-tight md:text-lg"
        }, "选择支付方式", 3, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "grid gap-2 md:grid-cols-2 md:gap-3"
        }, props.paymentMethods.map((method) => {
          var _a, _b;
          return /* @__PURE__ */ _jsxBranch(/* @__PURE__ */ _jsxQ("button", {
            class: `group flex items-center justify-between rounded-lg border p-3 transition-colors duration-200 md:p-4 ${((_a = props.selectedPayment) == null ? void 0 : _a.id) === method.id ? "border-primary/40 bg-primary/10 ring-primary/20 ring-1" : "border-border/60 bg-card hover:border-primary/30 hover:bg-primary/5"}`,
            onClick$: /* @__PURE__ */ _noopQrl("s_s721gb1oPNg", [
              method,
              props
            ])
          }, null, [
            /* @__PURE__ */ _jsxQ("div", null, {
              class: "flex items-center space-x-3"
            }, [
              /* @__PURE__ */ _jsxQ("div", null, {
                class: "bg-accent text-accent-foreground rounded-lg p-2 shadow-sm"
              }, "💳", 3, null),
              /* @__PURE__ */ _jsxQ("span", null, {
                class: "text-foreground font-medium"
              }, _wrapSignal(method, "name"), 1, null)
            ], 1, null),
            ((_b = props.selectedPayment) == null ? void 0 : _b.id) === method.id && /* @__PURE__ */ _jsxQ("div", null, {
              class: "bg-primary text-primary-foreground rounded-full p-1 shadow-sm"
            }, /* @__PURE__ */ _jsxC(LuCheck, {
              class: "h-3 w-3",
              [_IMMUTABLE]: {
                class: _IMMUTABLE
              }
            }, 3, "FN_2"), 1, "FN_3")
          ], 0, method.id));
        }), 1, null)
      ], 1, null)
    ], 1, null), 1, null),
    /* @__PURE__ */ _jsxQ("div", null, null, /* @__PURE__ */ _jsxQ("div", null, {
      class: "bg-card/90 border-border/50 rounded-xl border p-3 shadow-sm backdrop-blur-sm md:p-4 lg:sticky lg:top-4"
    }, [
      /* @__PURE__ */ _jsxQ("h3", null, {
        class: "mb-4 text-base font-semibold tracking-tight md:text-lg"
      }, "订单摘要", 3, null),
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "space-y-3"
      }, [
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "mb-2 flex items-center justify-between"
        }, [
          /* @__PURE__ */ _jsxQ("span", null, {
            class: "text-muted-foreground/80 text-sm"
          }, "商品", 3, null),
          /* @__PURE__ */ _jsxQ("span", null, {
            class: "text-foreground ml-2 flex-1 truncate text-right text-sm font-medium"
          }, _fnSignal((p0) => p0.selectedProduct.name, [
            props
          ], "p0.selectedProduct.name"), 3, null)
        ], 3, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "flex items-center justify-between"
        }, [
          /* @__PURE__ */ _jsxQ("span", null, {
            class: "text-muted-foreground/80 text-sm"
          }, "时长", 3, null),
          /* @__PURE__ */ _jsxQ("span", null, {
            class: "text-foreground text-sm font-medium"
          }, [
            _fnSignal((p0) => p0.quantity, [
              props
            ], "p0.quantity"),
            displayUnit,
            " "
          ], 1, null)
        ], 1, null),
        (() => {
          const pricing = calculateDiscountedPrice(props.selectedProduct, props.quantity);
          return /* @__PURE__ */ _jsxQ("div", null, {
            class: "space-y-2"
          }, [
            /* @__PURE__ */ _jsxQ("div", null, {
              class: "flex items-center justify-between"
            }, [
              /* @__PURE__ */ _jsxQ("span", null, {
                class: "text-muted-foreground/80 text-sm"
              }, "原价", 3, null),
              /* @__PURE__ */ _jsxQ("span", {
                class: `text-sm ${pricing.discountRate > 0 ? "text-muted-foreground/70 line-through" : "text-foreground font-medium"}`
              }, null, [
                "¥",
                formatPrice(pricing.originalPrice)
              ], 1, null)
            ], 1, null),
            pricing.discountRate > 0 && /* @__PURE__ */ _jsxC(Fragment, {
              children: [
                /* @__PURE__ */ _jsxQ("div", null, {
                  class: "flex items-center justify-between"
                }, [
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "text-primary/90 text-sm"
                  }, [
                    "优惠 (",
                    _wrapSignal(pricing, "discountRate"),
                    "%)"
                  ], 1, null),
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "text-primary/90 text-sm"
                  }, [
                    "-¥",
                    formatPrice(pricing.savings)
                  ], 1, null)
                ], 1, null),
                /* @__PURE__ */ _jsxQ("div", null, {
                  class: "border-border/50 border-t pt-2"
                }, /* @__PURE__ */ _jsxQ("div", null, {
                  class: "flex items-center justify-between"
                }, [
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "text-foreground font-semibold"
                  }, "实付金额", 3, null),
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "text-primary text-lg font-semibold"
                  }, [
                    "¥",
                    formatPrice(pricing.discountedPrice)
                  ], 1, null)
                ], 1, null), 1, null)
              ]
            }, 1, "FN_4"),
            pricing.discountRate === 0 && /* @__PURE__ */ _jsxQ("div", null, {
              class: "border-border/50 border-t pt-2"
            }, /* @__PURE__ */ _jsxQ("div", null, {
              class: "flex items-center justify-between"
            }, [
              /* @__PURE__ */ _jsxQ("span", null, {
                class: "text-foreground font-semibold"
              }, "总计", 3, null),
              /* @__PURE__ */ _jsxQ("span", null, {
                class: "text-primary text-lg font-semibold"
              }, [
                "¥",
                formatPrice(pricing.originalPrice)
              ], 1, null)
            ], 1, null), 1, "FN_5")
          ], 1, "FN_6");
        })()
      ], 1, null),
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "mt-6 space-y-3"
      }, [
        /* @__PURE__ */ _jsxQ("button", {
          onClick$: props.onCreateOrder
        }, {
          class: "bg-primary text-primary-foreground hover:bg-primary/90 focus-visible:ring-primary focus-visible:ring-offset-background inline-flex h-11 w-full items-center justify-center rounded-lg px-6 text-base font-medium shadow-sm transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50",
          disabled: _fnSignal((p0) => p0.isLoading || !p0.selectedPayment, [
            props
          ], "p0.isLoading||!p0.selectedPayment")
        }, props.isLoading ? /* @__PURE__ */ _jsxQ("span", null, {
          class: "flex items-center"
        }, [
          /* @__PURE__ */ _jsxC(LuLoader2, {
            class: "mr-2 h-4 w-4 animate-spin",
            [_IMMUTABLE]: {
              class: _IMMUTABLE
            }
          }, 3, "FN_7"),
          "处理中..."
        ], 1, "FN_8") : /* @__PURE__ */ _jsxC(Fragment, {
          children: "确认下单 ✨"
        }, 3, "FN_9"), 0, null),
        /* @__PURE__ */ _jsxQ("button", {
          onClick$: props.onGoBack
        }, {
          class: "border-input bg-background hover:bg-accent hover:text-accent-foreground focus-visible:ring-primary focus-visible:ring-offset-background inline-flex h-11 w-full items-center justify-center rounded-lg border px-6 text-base font-medium transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50"
        }, [
          /* @__PURE__ */ _jsxC(LuChevronLeft, {
            class: "mr-2 h-4 w-4",
            [_IMMUTABLE]: {
              class: _IMMUTABLE
            }
          }, 3, "FN_10"),
          "返回选择"
        ], 0, null)
      ], 1, null)
    ], 1, null), 1, null)
  ], 1, null), 1, null), 1, "FN_11");
};
const OrderConfig = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_yG9BTd3fEjw, "s_yG9BTd3fEjw"));
function cn(...classes) {
  return classes.filter(Boolean).join(" ");
}
const getButtonClasses = (variant, size, className) => {
  const baseClasses = "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0";
  const variantClasses = {
    default: "bg-primary text-primary-foreground shadow-xs hover:bg-primary/90",
    destructive: "bg-destructive text-destructive-foreground shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
    outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
    secondary: "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
    ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
    link: "text-primary underline-offset-4 hover:underline"
  };
  const sizeClasses = {
    default: "h-9 px-4 py-2 has-[>svg]:px-3",
    sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
    lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
    icon: "size-9"
  };
  return cn(baseClasses, variantClasses[variant], sizeClasses[size], className);
};
const s_BUrbVyeVOeI = (props) => {
  const props1 = _restProps(props, [
    "type",
    "disabled",
    "class",
    "variant",
    "size",
    "onClick$"
  ]);
  return /* @__PURE__ */ _jsxS("button", {
    get type() {
      return props.type ?? "button";
    },
    get disabled() {
      return props.disabled;
    },
    "data-slot": "button",
    class: getButtonClasses(props.variant ?? "default", props.size ?? "default", props.class),
    ...props1,
    children: /* @__PURE__ */ _jsxC(Slot, null, 3, "ze_0"),
    onClick$: props.onClick$
  }, {
    type: _fnSignal((p0) => p0.type ?? "button", [
      props
    ], 'p0.type??"button"'),
    disabled: _fnSignal((p0) => p0.disabled, [
      props
    ], "p0.disabled"),
    "data-slot": _IMMUTABLE
  }, 0, "ze_1");
};
const Button = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_BUrbVyeVOeI, "s_BUrbVyeVOeI"));
const getInputClasses = (className) => {
  return cn("file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input flex h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]", "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", className);
};
const s_7oeZyJeSJLc = (props) => {
  const props1 = _restProps(props, [
    "type",
    "value",
    "placeholder",
    "class",
    "onInput$",
    "id",
    "disabled"
  ]);
  return /* @__PURE__ */ _jsxS("input", {
    get type() {
      return props.type ?? "text";
    },
    get value() {
      return props.value;
    },
    get placeholder() {
      return props.placeholder;
    },
    "data-slot": "input",
    class: getInputClasses(props.class),
    get id() {
      return props.id;
    },
    get disabled() {
      return props.disabled;
    },
    ...props1,
    onInput$: props.onInput$
  }, {
    type: _fnSignal((p0) => p0.type ?? "text", [
      props
    ], 'p0.type??"text"'),
    value: _fnSignal((p0) => p0.value, [
      props
    ], "p0.value"),
    placeholder: _fnSignal((p0) => p0.placeholder, [
      props
    ], "p0.placeholder"),
    "data-slot": _IMMUTABLE,
    id: _fnSignal((p0) => p0.id, [
      props
    ], "p0.id"),
    disabled: _fnSignal((p0) => p0.disabled, [
      props
    ], "p0.disabled")
  }, 0, "nI_0");
};
const Input = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_7oeZyJeSJLc, "s_7oeZyJeSJLc"));
const getLabelClasses = (className) => {
  return cn("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70", className);
};
const s_J7gsaTABbu0 = (props) => {
  const props1 = _restProps(props, [
    "for",
    "class"
  ]);
  return /* @__PURE__ */ _jsxS("label", {
    get for() {
      return props.for;
    },
    class: getLabelClasses(props.class),
    ...props1,
    children: /* @__PURE__ */ _jsxC(Slot, null, 3, "2t_0")
  }, {
    for: _fnSignal((p0) => p0.for, [
      props
    ], "p0.for")
  }, 0, "2t_1");
};
const Label = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_J7gsaTABbu0, "s_J7gsaTABbu0"));
const s_tV00JQB9Z00 = (props) => {
  const qrCanvas = useSignal();
  const containerRef = useSignal();
  const containerSize = useSignal(props.size);
  useVisibleTaskQrl(/* @__PURE__ */ _noopQrl("s_Mn4wVM9cJVk", [
    containerRef,
    containerSize,
    props,
    qrCanvas
  ]));
  return /* @__PURE__ */ _jsxQ("div", {
    ref: containerRef,
    class: cn("relative flex items-center justify-center", props.responsive ?? false ? "h-full max-h-[100%] w-full max-w-[100%]" : "", props.class)
  }, null, /* @__PURE__ */ _jsxQ("canvas", {
    ref: qrCanvas
  }, null, null, 3, null), 1, "Oc_0");
};
const QRCode = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_tV00JQB9Z00, "s_tV00JQB9Z00"));
const s_HS2QQnuizIg = (props) => {
  const elementRef = useSignal();
  useVisibleTaskQrl(/* @__PURE__ */ _noopQrl("s_bQyFv5z8xyw", [
    elementRef,
    props
  ]));
  return /* @__PURE__ */ _jsxQ("div", {
    ref: elementRef
  }, {
    class: "stripe-element min-h-[24px]"
  }, null, 3, "6R_0");
};
const StripeElement = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_HS2QQnuizIg, "s_HS2QQnuizIg"));
const s_L1mdPr9ezqs = () => ({
  base: {
    fontSize: "16px",
    color: themeManager.getRealTheme() === "dark" ? "#fff" : "#000",
    "::placeholder": {
      color: "#aab7c4"
    }
  },
  invalid: {
    color: "#EF4444",
    iconColor: "#EF4444"
  }
});
const s_jdF7ckWvmLI = () => {
  const [elementStyle] = useLexicalScope();
  return {
    style: elementStyle.value,
    showIcon: true
  };
};
const s_s7eZ7boERXM = (event, field) => {
  const [errors] = useLexicalScope();
  if (event.error) errors[field] = event.error.message;
  else errors[field] = void 0;
};
const s_dgZrr3sXauw = async () => {
  const [cardholderName, errors, processing, props, succeeded] = useLexicalScope();
  if (!props.stripeInstance || !props.elementsInstance) {
    props.onError$("请等待 Stripe 加载完成");
    return;
  }
  if (!cardholderName.value.trim()) {
    errors.name = "请输入持卡人姓名";
    return;
  }
  processing.value = true;
  try {
    const cardElement = props.elementsInstance.getElement("cardNumber");
    const result = await props.stripeInstance.confirmCardPayment(props.clientSecret, {
      payment_method: {
        card: cardElement,
        billing_details: {
          name: cardholderName.value
        }
      }
    });
    if (result.error) props.onError$(result.error.message || "支付失败");
    else if (result.paymentIntent && result.paymentIntent.status === "succeeded") succeeded.value = true;
    else props.onError$("支付处理中，请稍候");
  } catch {
    props.onError$("支付失败");
  } finally {
    processing.value = false;
  }
};
const s_7vrZdIvRuqk = (e, el) => {
  const [cardholderName] = useLexicalScope();
  return cardholderName.value = el.value;
};
const s_dj8ExO27MUw = (e) => {
  const [handleChange] = useLexicalScope();
  return handleChange(e, "cardNumber");
};
const s_pOePtepJrko = (e) => {
  const [handleChange] = useLexicalScope();
  return handleChange(e, "cardExpiry");
};
const s_BJyWQfhuby0 = (e) => {
  const [handleChange] = useLexicalScope();
  return handleChange(e, "cardCvc");
};
const s_3Wcj1rjxuVI = (props) => {
  _jsxBranch();
  const processing = useSignal(false);
  const succeeded = useSignal(false);
  const errors = useStore({});
  const cardholderName = useSignal("");
  const elementStyle = useComputedQrl(/* @__PURE__ */ inlinedQrl(s_L1mdPr9ezqs, "s_L1mdPr9ezqs"));
  const elementOptions = useComputedQrl(/* @__PURE__ */ inlinedQrl(s_jdF7ckWvmLI, "s_jdF7ckWvmLI", [
    elementStyle
  ]));
  const handleChange = /* @__PURE__ */ inlinedQrl(s_s7eZ7boERXM, "s_s7eZ7boERXM", [
    errors
  ]);
  const handleSubmit = /* @__PURE__ */ inlinedQrl(s_dgZrr3sXauw, "s_dgZrr3sXauw", [
    cardholderName,
    errors,
    processing,
    props,
    succeeded
  ]);
  return /* @__PURE__ */ _jsxQ("form", null, {
    "preventdefault:submit": true,
    onSubmit$: /* @__PURE__ */ _noopQrl("s_ehhyUk2f1TI", [
      handleSubmit
    ])
  }, succeeded.value ? /* @__PURE__ */ _jsxQ("div", null, {
    class: "py-6 text-center"
  }, [
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "mb-4 flex justify-center"
    }, /* @__PURE__ */ _jsxC(LuCheckCircle, {
      class: "text-primary text-5xl",
      [_IMMUTABLE]: {
        class: _IMMUTABLE
      }
    }, 3, "6R_1"), 1, null),
    /* @__PURE__ */ _jsxQ("p", null, {
      class: "text-xl font-medium"
    }, "支付成功", 3, null),
    /* @__PURE__ */ _jsxQ("p", null, {
      class: "text-muted-foreground mt-2"
    }, "您的支付已完成。订单状态可能需要一些时间更新，请耐心等待", 3, null)
  ], 1, "6R_2") : /* @__PURE__ */ _jsxC(Fragment, {
    children: [
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "space-y-4"
      }, [
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "space-y-1"
        }, [
          /* @__PURE__ */ _jsxC(Label, {
            for: "cardholderName",
            class: "text-sm font-medium",
            children: "持卡人姓名",
            [_IMMUTABLE]: {
              for: _IMMUTABLE,
              class: _IMMUTABLE
            }
          }, 3, "6R_3"),
          /* @__PURE__ */ _jsxC(Input, {
            id: "cardholderName",
            type: "text",
            get value() {
              return cardholderName.value;
            },
            onInput$: /* @__PURE__ */ inlinedQrl(s_7vrZdIvRuqk, "s_7vrZdIvRuqk", [
              cardholderName
            ]),
            placeholder: "请输入持卡人姓名",
            get class() {
              return errors.name ? "aria-invalid:border-destructive border-destructive" : "";
            },
            [_IMMUTABLE]: {
              id: _IMMUTABLE,
              type: _IMMUTABLE,
              value: _fnSignal((p0) => p0.value, [
                cardholderName
              ], "p0.value"),
              onInput$: _IMMUTABLE,
              placeholder: _IMMUTABLE,
              class: _fnSignal((p0) => p0.name ? "aria-invalid:border-destructive border-destructive" : "", [
                errors
              ], 'p0.name?"aria-invalid:border-destructive border-destructive":""')
            }
          }, 3, "6R_4"),
          errors.name && /* @__PURE__ */ _jsxQ("p", null, {
            class: "text-destructive text-xs break-words"
          }, _fnSignal((p0) => p0.name, [
            errors
          ], "p0.name"), 3, "6R_5")
        ], 1, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "space-y-1"
        }, [
          /* @__PURE__ */ _jsxC(Label, {
            for: "cardNumber",
            class: "text-sm font-medium",
            children: "银行卡号",
            [_IMMUTABLE]: {
              for: _IMMUTABLE,
              class: _IMMUTABLE
            }
          }, 3, "6R_6"),
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "relative"
          }, /* @__PURE__ */ _jsxQ("div", {
            class: `focus-within:border-ring focus-within:ring-ring/50 rounded-md border px-3 pt-2 pb-1 transition-[color,box-shadow] focus-within:ring-[3px] ${errors.cardNumber ? "border-destructive" : "border-input"}`
          }, null, /* @__PURE__ */ _jsxC(StripeElement, {
            type: "cardNumber",
            onChange$: /* @__PURE__ */ inlinedQrl(s_dj8ExO27MUw, "s_dj8ExO27MUw", [
              handleChange
            ]),
            get options() {
              return elementOptions.value;
            },
            get elementsInstance() {
              return props.elementsInstance;
            },
            [_IMMUTABLE]: {
              type: _IMMUTABLE,
              onChange$: _IMMUTABLE,
              options: _fnSignal((p0) => p0.value, [
                elementOptions
              ], "p0.value"),
              elementsInstance: _fnSignal((p0) => p0.elementsInstance, [
                props
              ], "p0.elementsInstance")
            }
          }, 3, "6R_7"), 1, null), 1, null),
          errors.cardNumber && /* @__PURE__ */ _jsxQ("p", null, {
            class: "text-destructive w-full text-xs break-words"
          }, _fnSignal((p0) => p0.cardNumber, [
            errors
          ], "p0.cardNumber"), 3, "6R_8")
        ], 1, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "grid grid-cols-2 gap-4"
        }, [
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "space-y-1"
          }, [
            /* @__PURE__ */ _jsxC(Label, {
              for: "cardExpiry",
              class: "text-sm font-medium",
              children: "有效期",
              [_IMMUTABLE]: {
                for: _IMMUTABLE,
                class: _IMMUTABLE
              }
            }, 3, "6R_9"),
            /* @__PURE__ */ _jsxQ("div", {
              class: `focus-within:border-ring focus-within:ring-ring/50 rounded-md border px-3 pt-2 pb-1 transition-[color,box-shadow] focus-within:ring-[3px] ${errors.cardExpiry ? "border-destructive" : "border-input"}`
            }, null, /* @__PURE__ */ _jsxC(StripeElement, {
              type: "cardExpiry",
              onChange$: /* @__PURE__ */ inlinedQrl(s_pOePtepJrko, "s_pOePtepJrko", [
                handleChange
              ]),
              get options() {
                return {
                  style: elementStyle.value
                };
              },
              get elementsInstance() {
                return props.elementsInstance;
              },
              [_IMMUTABLE]: {
                type: _IMMUTABLE,
                onChange$: _IMMUTABLE,
                options: _fnSignal((p0) => ({
                  style: p0.value
                }), [
                  elementStyle
                ], "{style:p0.value}"),
                elementsInstance: _fnSignal((p0) => p0.elementsInstance, [
                  props
                ], "p0.elementsInstance")
              }
            }, 3, "6R_10"), 1, null),
            errors.cardExpiry && /* @__PURE__ */ _jsxQ("p", null, {
              class: "text-destructive w-full text-xs break-words"
            }, _fnSignal((p0) => p0.cardExpiry, [
              errors
            ], "p0.cardExpiry"), 3, "6R_11")
          ], 1, null),
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "space-y-1"
          }, [
            /* @__PURE__ */ _jsxC(Label, {
              for: "cardCvc",
              class: "text-sm font-medium",
              children: "安全码",
              [_IMMUTABLE]: {
                for: _IMMUTABLE,
                class: _IMMUTABLE
              }
            }, 3, "6R_12"),
            /* @__PURE__ */ _jsxQ("div", {
              class: `focus-within:border-ring focus-within:ring-ring/50 rounded-md border px-3 pt-2 pb-1 transition-[color,box-shadow] focus-within:ring-[3px] ${errors.cardCvc ? "border-destructive" : "border-input"}`
            }, null, /* @__PURE__ */ _jsxC(StripeElement, {
              type: "cardCvc",
              onChange$: /* @__PURE__ */ inlinedQrl(s_BJyWQfhuby0, "s_BJyWQfhuby0", [
                handleChange
              ]),
              get options() {
                return {
                  style: elementStyle.value
                };
              },
              get elementsInstance() {
                return props.elementsInstance;
              },
              [_IMMUTABLE]: {
                type: _IMMUTABLE,
                onChange$: _IMMUTABLE,
                options: _fnSignal((p0) => ({
                  style: p0.value
                }), [
                  elementStyle
                ], "{style:p0.value}"),
                elementsInstance: _fnSignal((p0) => p0.elementsInstance, [
                  props
                ], "p0.elementsInstance")
              }
            }, 3, "6R_13"), 1, null),
            errors.cardCvc && /* @__PURE__ */ _jsxQ("p", null, {
              class: "text-destructive text-xs break-words"
            }, _fnSignal((p0) => p0.cardCvc, [
              errors
            ], "p0.cardCvc"), 3, "6R_14")
          ], 1, null)
        ], 1, null)
      ], 1, null),
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "mt-6 flex flex-col space-y-4"
      }, [
        /* @__PURE__ */ _jsxC(Button, {
          type: "submit",
          size: "lg",
          get disabled() {
            return processing.value || !props.stripeInstance || !props.elementsInstance;
          },
          class: "w-full",
          children: processing.value ? /* @__PURE__ */ _jsxC(Fragment, {
            children: [
              /* @__PURE__ */ _jsxC(LuLoader2, {
                class: "mr-2 h-4 w-4 animate-spin",
                [_IMMUTABLE]: {
                  class: _IMMUTABLE
                }
              }, 3, "6R_15"),
              "处理中..."
            ]
          }, 1, "6R_16") : "立即支付",
          [_IMMUTABLE]: {
            type: _IMMUTABLE,
            size: _IMMUTABLE,
            disabled: _fnSignal((p0, p1) => p0.value || !p1.stripeInstance || !p1.elementsInstance, [
              processing,
              props
            ], "p0.value||!p1.stripeInstance||!p1.elementsInstance"),
            class: _IMMUTABLE
          }
        }, 1, "6R_17"),
        /* @__PURE__ */ _jsxQ("p", null, {
          class: "text-muted-foreground text-center text-xs"
        }, "您的支付信息将被安全处理", 3, null)
      ], 1, null)
    ]
  }, 1, "6R_18"), 1, "6R_19");
};
const CardPaymentForm = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_3Wcj1rjxuVI, "s_3Wcj1rjxuVI"));
const s_LzwHuJDGmnA = (message) => {
  const [errorMessage] = useLexicalScope();
  errorMessage.value = message;
};
const s_WQLz0FTWy8A = async () => {
  var _a, _b;
  const [handleError, props, qrCodeUrl] = useLexicalScope();
  if (!props.stripeInstance) {
    handleError("请等待 Stripe 加载完成");
    return;
  }
  try {
    let result;
    if (props.method === "alipay") result = await props.stripeInstance.confirmAlipayPayment(props.client_secret, {
      return_url: window.location.href
    }, {
      handleActions: false
    });
    else if (props.method === "wechat_pay") result = await props.stripeInstance.confirmWechatPayPayment(props.client_secret, {
      payment_method_options: {
        wechat_pay: {
          client: "web"
        }
      }
    }, {
      handleActions: false
    });
    if (!result) return;
    if (result.error) handleError(result.error.message);
    else if (result.paymentIntent.status === "requires_action") {
      const nextAction = result.paymentIntent.next_action;
      const qrUrl = props.method === "alipay" ? (_a = nextAction == null ? void 0 : nextAction.alipay_handle_redirect) == null ? void 0 : _a.url : (_b = nextAction == null ? void 0 : nextAction.wechat_pay_display_qr_code) == null ? void 0 : _b.image_url_svg;
      qrCodeUrl.value = qrUrl || null;
    }
  } catch {
    handleError("处理请求时出错");
  }
};
const s_C1sSbhNvf08 = () => window.location.reload();
const s_VxsQCZFcAyQ = (props) => {
  _jsxBranch();
  const errorMessage = useSignal(null);
  const qrCodeUrl = useSignal(null);
  const handleError = /* @__PURE__ */ inlinedQrl(s_LzwHuJDGmnA, "s_LzwHuJDGmnA", [
    errorMessage
  ]);
  const confirmPayment = /* @__PURE__ */ inlinedQrl(s_WQLz0FTWy8A, "s_WQLz0FTWy8A", [
    handleError,
    props,
    qrCodeUrl
  ]);
  useVisibleTaskQrl(/* @__PURE__ */ _noopQrl("s_RbgA8jLQung", [
    confirmPayment,
    props
  ]));
  const qrCodeInstructions = {
    alipay: "请使用支付宝扫描二维码完成支付",
    wechat_pay: "请使用微信扫描二维码完成支付"
  };
  return props.method === "card" ? /* @__PURE__ */ _jsxQ("div", null, {
    class: "min-w-80 text-left md:min-w-sm"
  }, /* @__PURE__ */ _jsxC(CardPaymentForm, {
    get clientSecret() {
      return props.client_secret;
    },
    onError$: handleError,
    get stripeInstance() {
      return props.stripeInstance;
    },
    get elementsInstance() {
      return props.elementsInstance;
    },
    [_IMMUTABLE]: {
      clientSecret: _fnSignal((p0) => p0.client_secret, [
        props
      ], "p0.client_secret"),
      onError$: _IMMUTABLE,
      stripeInstance: _fnSignal((p0) => p0.stripeInstance, [
        props
      ], "p0.stripeInstance"),
      elementsInstance: _fnSignal((p0) => p0.elementsInstance, [
        props
      ], "p0.elementsInstance")
    }
  }, 3, "6R_20"), 1, "6R_21") : qrCodeUrl.value ? /* @__PURE__ */ _jsxQ("div", null, {
    class: "text-center"
  }, [
    /* @__PURE__ */ _jsxC(QRCode, {
      get text() {
        return qrCodeUrl.value;
      },
      size: 208,
      [_IMMUTABLE]: {
        text: _fnSignal((p0) => p0.value, [
          qrCodeUrl
        ], "p0.value"),
        size: _IMMUTABLE
      }
    }, 3, "6R_22"),
    /* @__PURE__ */ _jsxQ("p", null, {
      class: "text-muted-foreground mt-4"
    }, qrCodeInstructions[props.method], 1, null)
  ], 1, "6R_23") : /* @__PURE__ */ _jsxQ("div", null, {
    class: "text-center"
  }, errorMessage.value ? /* @__PURE__ */ _jsxQ("div", null, {
    class: "space-y-3"
  }, [
    /* @__PURE__ */ _jsxQ("p", null, {
      class: "text-destructive"
    }, _fnSignal((p0) => p0.value, [
      errorMessage
    ], "p0.value"), 3, null),
    /* @__PURE__ */ _jsxC(Button, {
      variant: "outline",
      onClick$: /* @__PURE__ */ inlinedQrl(s_C1sSbhNvf08, "s_C1sSbhNvf08"),
      children: "重新尝试",
      [_IMMUTABLE]: {
        variant: _IMMUTABLE,
        onClick$: _IMMUTABLE
      }
    }, 3, "6R_24")
  ], 1, "6R_25") : /* @__PURE__ */ _jsxQ("div", null, {
    class: "flex items-center justify-center"
  }, [
    /* @__PURE__ */ _jsxC(LuLoader2, {
      class: "mr-2 h-4 w-4 animate-spin",
      [_IMMUTABLE]: {
        class: _IMMUTABLE
      }
    }, 3, "6R_26"),
    "准备支付中..."
  ], 1, null), 1, null);
};
const CheckoutForm = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_VxsQCZFcAyQ, "s_VxsQCZFcAyQ"));
const s_8EHhsuLG6wc = (props) => {
  _jsxBranch();
  const stripeInstance = useSignal(null);
  const elementsInstance = useSignal(null);
  const isLoading = useSignal(true);
  useVisibleTaskQrl(/* @__PURE__ */ _noopQrl("s_Fw08BHofx3E", [
    elementsInstance,
    isLoading,
    props,
    stripeInstance
  ]));
  return /* @__PURE__ */ _jsxQ("div", null, null, isLoading.value ? /* @__PURE__ */ _jsxQ("div", null, {
    class: "flex items-center justify-center py-8"
  }, [
    /* @__PURE__ */ _jsxC(LuLoader2, {
      class: "mr-2 h-5 w-5 animate-spin",
      [_IMMUTABLE]: {
        class: _IMMUTABLE
      }
    }, 3, "6R_27"),
    "加载支付组件中..."
  ], 1, "6R_28") : /* @__PURE__ */ _jsxC(CheckoutForm, {
    get method() {
      return props.method;
    },
    get client_secret() {
      return props.client_secret;
    },
    get stripeInstance() {
      return stripeInstance.value;
    },
    get elementsInstance() {
      return elementsInstance.value;
    },
    [_IMMUTABLE]: {
      method: _fnSignal((p0) => p0.method, [
        props
      ], "p0.method"),
      client_secret: _fnSignal((p0) => p0.client_secret, [
        props
      ], "p0.client_secret"),
      stripeInstance: _fnSignal((p0) => p0.value, [
        stripeInstance
      ], "p0.value"),
      elementsInstance: _fnSignal((p0) => p0.value, [
        elementsInstance
      ], "p0.value")
    }
  }, 3, "6R_29"), 1, "6R_30");
};
const StripePayment = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_8EHhsuLG6wc, "s_8EHhsuLG6wc"));
const s_YcwI1nCjycY = (props) => {
  _jsxBranch();
  const statusDisplay = getOrderStatusDisplay(props.orderInfo.status.toString());
  return /* @__PURE__ */ _jsxQ("div", null, {
    class: "space-y-4"
  }, [
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "text-center"
    }, [
      /* @__PURE__ */ _jsxQ("h2", null, {
        class: "mb-2 text-xl font-semibold tracking-tight md:text-2xl"
      }, _fnSignal((p0) => p0.orderInfo.status === 3 ? "重新支付" : "请完成支付", [
        props
      ], 'p0.orderInfo.status===3?"重新支付":"请完成支付"'), 3, null),
      /* @__PURE__ */ _jsxQ("p", null, {
        class: "text-muted-foreground/80 mx-auto max-w-lg text-sm leading-relaxed"
      }, props.orderInfo.status === 3 ? "订单已取消，您可以重新支付完成购买" : "请在新打开的支付页面完成付款，支付成功后将自动生成兑换码", 1, null)
    ], 1, null),
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "mx-auto max-w-4xl"
    }, /* @__PURE__ */ _jsxQ("div", null, {
      class: "grid gap-4 lg:grid-cols-3"
    }, [
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "lg:col-span-2"
      }, /* @__PURE__ */ _jsxQ("div", null, {
        class: "bg-card/90 border-border/50 rounded-xl border p-3 shadow-sm backdrop-blur-sm md:p-4"
      }, [
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "mb-4"
        }, [
          /* @__PURE__ */ _jsxQ("h3", null, {
            class: "mb-3 text-base font-semibold tracking-tight md:text-lg"
          }, "支付状态", 3, null),
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "space-y-3"
          }, [
            /* @__PURE__ */ _jsxQ("div", null, {
              class: "flex justify-center"
            }, /* @__PURE__ */ _jsxQ("div", {
              class: `flex items-center space-x-2 rounded-full px-4 py-2 ${statusDisplay.bgColor} ${statusDisplay.borderColor} border shadow-sm`
            }, null, [
              /* @__PURE__ */ _jsxQ("span", null, {
                class: "text-base"
              }, _wrapSignal(statusDisplay, "icon"), 1, null),
              /* @__PURE__ */ _jsxQ("span", {
                class: `text-base font-semibold ${statusDisplay.color}`
              }, null, props.timeRemaining <= 0 && (props.orderInfo.status === 1 || props.orderInfo.status === 3) ? "已取消" : statusDisplay.text, 1, null)
            ], 1, null), 1, null),
            props.orderInfo.status === 1 && props.timeRemaining > 0 && /* @__PURE__ */ _jsxQ("div", null, {
              class: "flex justify-center"
            }, /* @__PURE__ */ _jsxQ("div", null, {
              class: "bg-background/90 border-border/50 rounded-lg border px-4 py-2"
            }, /* @__PURE__ */ _jsxQ("div", null, {
              class: "flex items-center space-x-2"
            }, [
              /* @__PURE__ */ _jsxQ("span", null, {
                class: "text-muted-foreground/70 text-sm"
              }, "⏱️ 剩余时间", 3, null),
              /* @__PURE__ */ _jsxQ("span", null, {
                class: "text-foreground font-mono text-base font-bold"
              }, formatTime(props.timeRemaining), 1, null)
            ], 1, null), 1, null), 1, "0g_0")
          ], 1, null)
        ], 1, null),
        props.orderInfo.paymentInfo && /* @__PURE__ */ _jsxQ("div", null, null, [
          /* @__PURE__ */ _jsxQ("h3", null, {
            class: "mb-3 text-base font-semibold tracking-tight md:text-lg"
          }, "支付方式", 3, null),
          props.orderInfo.paymentInfo.type === "url" && props.orderInfo.paymentInfo.checkoutUrl && /* @__PURE__ */ _jsxQ("div", null, null, /* @__PURE__ */ _jsxQ("p", null, {
            class: "text-foreground/90 mb-4 text-center text-sm"
          }, "点击下方按钮前往支付页面完成付款", 3, null), 3, "0g_1"),
          props.orderInfo.paymentInfo.type === "qr" && props.orderInfo.paymentInfo.checkoutUrl && /* @__PURE__ */ _jsxQ("div", null, {
            class: "text-center"
          }, [
            /* @__PURE__ */ _jsxQ("p", null, {
              class: "text-foreground/90 mb-3 text-sm"
            }, "扫描二维码或点击按钮前往支付页面", 3, null),
            /* @__PURE__ */ _jsxQ("div", null, {
              class: "bg-background/90 border-border/50 mx-auto mb-3 inline-block rounded-lg border p-3"
            }, /* @__PURE__ */ _jsxC(QRCode, {
              get text() {
                return props.orderInfo.paymentInfo.checkoutUrl;
              },
              size: 160,
              [_IMMUTABLE]: {
                text: _fnSignal((p0) => p0.orderInfo.paymentInfo.checkoutUrl, [
                  props
                ], "p0.orderInfo.paymentInfo.checkoutUrl"),
                size: _IMMUTABLE
              }
            }, 3, "0g_2"), 1, null),
            /* @__PURE__ */ _jsxQ("p", null, {
              class: "text-muted-foreground/80 mb-4 text-xs"
            }, "二维码无法显示？请刷新页面", 3, null)
          ], 1, "0g_3"),
          props.orderInfo.paymentInfo.type === "stripe" && props.orderInfo.paymentInfo.stripe && /* @__PURE__ */ _jsxQ("div", null, null, [
            /* @__PURE__ */ _jsxQ("div", null, {
              class: "mb-3 text-center"
            }, /* @__PURE__ */ _jsxQ("p", null, {
              class: "text-foreground/90 text-sm"
            }, "使用信用卡或借记卡支付", 3, null), 3, null),
            /* @__PURE__ */ _jsxC(StripePayment, {
              get method() {
                return props.orderInfo.paymentInfo.stripe.method;
              },
              get client_secret() {
                return props.orderInfo.paymentInfo.stripe.client_secret;
              },
              get publishable_key() {
                return props.orderInfo.paymentInfo.stripe.publishable_key;
              },
              [_IMMUTABLE]: {
                method: _fnSignal((p0) => p0.orderInfo.paymentInfo.stripe.method, [
                  props
                ], "p0.orderInfo.paymentInfo.stripe.method"),
                client_secret: _fnSignal((p0) => p0.orderInfo.paymentInfo.stripe.client_secret, [
                  props
                ], "p0.orderInfo.paymentInfo.stripe.client_secret"),
                publishable_key: _fnSignal((p0) => p0.orderInfo.paymentInfo.stripe.publishable_key, [
                  props
                ], "p0.orderInfo.paymentInfo.stripe.publishable_key")
              }
            }, 3, "0g_4")
          ], 1, "0g_5"),
          props.orderInfo.paymentInfo.type === "balance" && /* @__PURE__ */ _jsxQ("div", null, {
            class: "text-center"
          }, [
            /* @__PURE__ */ _jsxQ("p", null, {
              class: "font-medium"
            }, "余额支付", 3, null),
            /* @__PURE__ */ _jsxQ("p", null, {
              class: "text-sm"
            }, "系统确认中，请稍候...", 3, null)
          ], 3, "0g_6"),
          props.orderInfo.status === 1 && props.timeRemaining > 0 && (props.orderInfo.paymentInfo.type === "url" || props.orderInfo.paymentInfo.type === "qr") && /* @__PURE__ */ _jsxQ("div", null, {
            class: "mt-4"
          }, /* @__PURE__ */ _jsxQ("button", null, {
            class: "bg-primary text-primary-foreground hover:bg-primary/90 focus-visible:ring-primary focus-visible:ring-offset-background inline-flex h-11 w-full items-center justify-center rounded-lg px-6 text-base font-medium shadow-sm transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50",
            onClick$: /* @__PURE__ */ _noopQrl("s_oiJJPw4N5ec", [
              props
            ])
          }, "去支付 ✨", 3, null), 3, "0g_7")
        ], 1, "0g_8")
      ], 1, null), 1, null),
      /* @__PURE__ */ _jsxQ("div", null, null, /* @__PURE__ */ _jsxQ("div", null, {
        class: "bg-card/90 border-border/50 rounded-xl border p-3 shadow-sm backdrop-blur-sm md:p-4 lg:sticky lg:top-4"
      }, [
        /* @__PURE__ */ _jsxQ("h3", null, {
          class: "mb-4 text-base font-semibold tracking-tight md:text-lg"
        }, "订单详情", 3, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "space-y-3"
        }, [
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "flex justify-between"
          }, [
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-muted-foreground/80 text-sm"
            }, "订单号", 3, null),
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "font-mono text-xs"
            }, _fnSignal((p0) => p0.orderInfo.order_no, [
              props
            ], "p0.orderInfo.order_no"), 3, null)
          ], 3, null),
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "flex justify-between"
          }, [
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-muted-foreground/80 text-sm"
            }, "商品", 3, null),
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-foreground text-sm font-medium"
            }, _fnSignal((p0) => {
              var _a;
              return ((_a = p0.currentProduct) == null ? void 0 : _a.name) || "未知商品";
            }, [
              props
            ], 'p0.currentProduct?.name||"未知商品"'), 3, null)
          ], 3, null),
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "flex justify-between"
          }, [
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-muted-foreground/80 text-sm"
            }, "数量", 3, null),
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-foreground text-sm font-medium"
            }, [
              _fnSignal((p0) => p0.quantity, [
                props
              ], "p0.quantity"),
              "个月"
            ], 3, null)
          ], 3, null),
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "border-border/50 border-t pt-3"
          }, /* @__PURE__ */ _jsxQ("div", null, {
            class: "flex items-center justify-between"
          }, [
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-foreground font-semibold"
            }, "总金额", 3, null),
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-primary text-lg font-semibold"
            }, [
              "¥",
              props.orderInfo.amount ? formatPrice(props.orderInfo.amount) : "0.00"
            ], 1, null)
          ], 1, null), 1, null)
        ], 1, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "mt-6 space-y-3"
        }, [
          props.orderInfo.status === 1 && props.timeRemaining > 0 && props.onCancelOrder && /* @__PURE__ */ _jsxQ("button", {
            onClick$: props.onCancelOrder
          }, {
            class: "bg-destructive text-destructive-foreground hover:bg-destructive/90 focus-visible:ring-destructive focus-visible:ring-offset-background inline-flex h-11 w-full items-center justify-center rounded-lg px-6 text-base font-medium shadow-sm transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50"
          }, [
            /* @__PURE__ */ _jsxC(LuX, {
              class: "mr-2 h-4 w-4",
              [_IMMUTABLE]: {
                class: _IMMUTABLE
              }
            }, 3, "0g_9"),
            "取消订单"
          ], 0, "0g_10"),
          (props.orderInfo.status === 3 || props.orderInfo.status === 4 || props.timeRemaining <= 0 && props.orderInfo.status === 1) && /* @__PURE__ */ _jsxQ("button", {
            onClick$: props.onResetProcess
          }, {
            class: "bg-primary text-primary-foreground hover:bg-primary/90 focus-visible:ring-primary focus-visible:ring-offset-background inline-flex h-11 w-full items-center justify-center rounded-lg px-6 text-base font-medium shadow-sm transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50"
          }, "重新购买 ✨", 2, "0g_11"),
          props.orderInfo.status === 5 && /* @__PURE__ */ _jsxQ("button", {
            onClick$: props.onResetProcess
          }, {
            class: "bg-primary text-primary-foreground hover:bg-primary/90 focus-visible:ring-primary focus-visible:ring-offset-background inline-flex h-11 w-full items-center justify-center rounded-lg px-6 text-base font-medium shadow-sm transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50"
          }, "继续购买 ✨", 2, "0g_12"),
          /* @__PURE__ */ _jsxQ("button", {
            onClick$: props.onGoBack
          }, {
            class: "border-input bg-background hover:bg-accent hover:text-accent-foreground focus-visible:ring-primary focus-visible:ring-offset-background inline-flex h-11 w-full items-center justify-center rounded-lg border px-6 text-base font-medium transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50"
          }, [
            /* @__PURE__ */ _jsxC(LuChevronLeft, {
              class: "mr-2 h-4 w-4",
              [_IMMUTABLE]: {
                class: _IMMUTABLE
              }
            }, 3, "0g_13"),
            "返回选择"
          ], 0, null)
        ], 1, null)
      ], 1, null), 1, null)
    ], 1, null), 1, null)
  ], 1, "0g_14");
};
const PaymentStatus = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_YcwI1nCjycY, "s_YcwI1nCjycY"));
const s_gPTd50s8Qk0 = async () => {
  const [copyState, props] = useLexicalScope();
  copyState.value = "copying";
  try {
    await props.onCopyRedeemCode(props.redeemCode);
    copyState.value = "success";
    setTimeout(() => {
      copyState.value = "idle";
    }, 2e3);
  } catch {
    copyState.value = "error";
    setTimeout(() => {
      copyState.value = "idle";
    }, 2e3);
  }
};
const s_zgSncxM7sfI = (props) => {
  _jsxBranch();
  const copyState = useSignal("idle");
  const handleCopy = /* @__PURE__ */ inlinedQrl(s_gPTd50s8Qk0, "s_gPTd50s8Qk0", [
    copyState,
    props
  ]);
  return /* @__PURE__ */ _jsxQ("div", null, {
    class: "space-y-6"
  }, [
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "text-center"
    }, [
      /* @__PURE__ */ _jsxQ("h2", null, {
        class: "mb-2 text-xl font-semibold tracking-tight md:text-2xl"
      }, "购买成功！🎉", 3, null),
      /* @__PURE__ */ _jsxQ("p", null, {
        class: "text-muted-foreground/80 mx-auto max-w-lg text-sm leading-relaxed"
      }, "您的兑换码已生成，请妥善保存并及时使用", 3, null)
    ], 3, null),
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "mx-auto max-w-2xl"
    }, /* @__PURE__ */ _jsxQ("div", null, {
      class: "bg-card/90 border-border/50 space-y-4 rounded-xl border p-3 shadow-sm backdrop-blur-sm md:p-4"
    }, [
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "text-center"
      }, /* @__PURE__ */ _jsxQ("div", null, {
        class: "bg-primary/10 border-primary/20 mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full border shadow-sm"
      }, /* @__PURE__ */ _jsxC(LuCheck, {
        class: "text-primary h-6 w-6",
        [_IMMUTABLE]: {
          class: _IMMUTABLE
        }
      }, 3, "Ep_0"), 1, null), 1, null),
      /* @__PURE__ */ _jsxQ("div", null, null, [
        /* @__PURE__ */ _jsxQ("label", null, {
          class: "mb-2 block text-base font-semibold tracking-tight md:text-lg"
        }, "您的服务兑换码", 3, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "border-primary/40 bg-primary/5 rounded-xl border-2 border-dashed p-3 shadow-sm backdrop-blur-sm md:p-4"
        }, /* @__PURE__ */ _jsxQ("div", null, {
          class: "text-center"
        }, /* @__PURE__ */ _jsxQ("div", null, {
          class: "flex items-center justify-center space-x-2"
        }, [
          /* @__PURE__ */ _jsxQ("code", null, {
            class: "bg-muted/80 text-primary border-border/50 rounded-lg border px-3 py-2 text-lg font-semibold tracking-widest shadow-sm md:text-xl"
          }, _fnSignal((p0) => p0.redeemCode, [
            props
          ], "p0.redeemCode"), 3, null),
          /* @__PURE__ */ _jsxQ("button", {
            class: `flex h-10 w-10 items-center justify-center rounded-lg shadow-sm transition-colors duration-200 ${copyState.value === "success" ? "bg-primary/15 text-primary border-primary/30 border" : copyState.value === "error" ? "bg-destructive/15 text-destructive border-destructive/30 border" : "bg-primary/10 text-primary hover:bg-primary/20 border-primary/20 border"}`
          }, {
            disabled: _fnSignal((p0) => p0.value === "copying", [
              copyState
            ], 'p0.value==="copying"'),
            title: _fnSignal((p0) => p0.value === "success" ? "复制成功" : p0.value === "error" ? "复制失败" : "复制兑换码", [
              copyState
            ], 'p0.value==="success"?"复制成功":p0.value==="error"?"复制失败":"复制兑换码"'),
            onClick$: handleCopy
          }, copyState.value === "success" ? /* @__PURE__ */ _jsxC(LuCheck, {
            class: "h-4 w-4",
            [_IMMUTABLE]: {
              class: _IMMUTABLE
            }
          }, 3, "Ep_1") : /* @__PURE__ */ _jsxC(LuCopy, {
            class: "h-4 w-4",
            [_IMMUTABLE]: {
              class: _IMMUTABLE
            }
          }, 3, "Ep_2"), 1, null)
        ], 1, null), 1, null), 1, null)
      ], 1, null),
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "bg-muted/30 border-border/50 rounded-lg border p-3 shadow-sm"
      }, [
        /* @__PURE__ */ _jsxQ("h4", null, {
          class: "mb-2 text-base font-semibold tracking-tight"
        }, "📋 下一步操作", 3, null),
        /* @__PURE__ */ _jsxQ("p", null, {
          class: "text-muted-foreground/90 mb-2 text-sm leading-relaxed"
        }, "点击下方按钮前往激活页面，兑换码将自动填入。", 3, null),
        /* @__PURE__ */ _jsxQ("ul", null, {
          class: "text-muted-foreground/80 space-y-1 text-xs"
        }, [
          /* @__PURE__ */ _jsxQ("li", null, null, "• 兑换码将自动填入，无需手动输入", 3, null),
          /* @__PURE__ */ _jsxQ("li", null, null, "• 兑换码一经使用即失效", 3, null),
          /* @__PURE__ */ _jsxQ("li", null, null, "• 如有问题请联系客服", 3, null)
        ], 3, null)
      ], 3, null),
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "flex flex-col gap-3 pt-2 sm:flex-row sm:gap-4"
      }, [
        /* @__PURE__ */ _jsxQ("button", {
          onClick$: props.onGoToRedeem
        }, {
          class: "bg-primary text-primary-foreground hover:bg-primary/90 focus-visible:ring-primary focus-visible:ring-offset-background inline-flex h-11 flex-1 items-center justify-center rounded-lg px-4 py-2 text-sm font-medium shadow-md transition-all duration-200 hover:shadow-lg focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50"
        }, [
          /* @__PURE__ */ _jsxQ("span", null, {
            class: "mr-2"
          }, "🚀", 3, null),
          "立即激活 (自动填入兑换码)"
        ], 2, null),
        /* @__PURE__ */ _jsxQ("button", {
          onClick$: props.onContinueShopping
        }, {
          class: "border-input bg-background hover:bg-accent hover:text-accent-foreground focus-visible:ring-primary focus-visible:ring-offset-background inline-flex h-11 items-center justify-center rounded-lg border px-4 py-2 text-sm font-medium transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50"
        }, "继续购买", 2, null)
      ], 1, null)
    ], 1, null), 1, null)
  ], 1, "Ep_3");
};
const SuccessPage = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_zgSncxM7sfI, "s_zgSncxM7sfI"));
var OrderStep = /* @__PURE__ */ function(OrderStep2) {
  OrderStep2[OrderStep2["SELECT_PRODUCT"] = 1] = "SELECT_PRODUCT";
  OrderStep2[OrderStep2["ORDER_CONFIG"] = 2] = "ORDER_CONFIG";
  OrderStep2[OrderStep2["PAYMENT_STATUS"] = 3] = "PAYMENT_STATUS";
  OrderStep2[OrderStep2["SUCCESS"] = 4] = "SUCCESS";
  return OrderStep2;
}({});
const STORAGE_KEYS = {
  SELECTED_PRODUCT: "card-issuing-selected-product",
  SELECTED_PAYMENT: "card-issuing-selected-payment",
  QUANTITY: "card-issuing-quantity"
};
const saveUserChoices = (selectedProduct, selectedPayment, quantity) => {
  if (typeof window !== "undefined") {
    if (selectedProduct) localStorage.setItem(STORAGE_KEYS.SELECTED_PRODUCT, JSON.stringify(selectedProduct));
    if (selectedPayment) localStorage.setItem(STORAGE_KEYS.SELECTED_PAYMENT, JSON.stringify(selectedPayment));
    localStorage.setItem(STORAGE_KEYS.QUANTITY, quantity.toString());
  }
};
const clearUserChoices = () => {
  if (typeof window !== "undefined") {
    localStorage.removeItem(STORAGE_KEYS.SELECTED_PRODUCT);
    localStorage.removeItem(STORAGE_KEYS.SELECTED_PAYMENT);
    localStorage.removeItem(STORAGE_KEYS.QUANTITY);
  }
};
const updateUrlSilently = (orderNo) => {
  if (typeof window !== "undefined") {
    const newUrl = `${window.location.origin}/?orderNo=${orderNo}`;
    window.history.pushState({
      orderNo
    }, "", newUrl);
  }
};
const clearUrlSilently = () => {
  if (typeof window !== "undefined") window.history.replaceState({}, "", "/");
};
async function safeAsyncOperation(operation, defaultError = "操作失败") {
  try {
    const result = await operation();
    return {
      success: true,
      data: result
    };
  } catch (error) {
    console.error(defaultError, error);
    return {
      success: false,
      error: error instanceof Error ? error.message : defaultError
    };
  }
}
async function safeCreateOrder(subscribeId, paymentMethodId, quantity) {
  return safeAsyncOperation(async () => {
    const response = await fetch("/api/orders/create", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        subscribeId,
        paymentMethod: paymentMethodId,
        quantity
      })
    });
    if (!response.ok) throw new Error(`创建订单失败 (${response.status})，请稍后重试`);
    const data = await response.json();
    if (!data.success) throw new Error(data.error || "创建订单失败");
    return data.data;
  }, "网络错误，请检查网络连接后重试");
}
async function safeGetOrderDetail(orderNo, returnUrl) {
  return safeAsyncOperation(async () => {
    const response = await fetch(`/api/orders/detail?orderNo=${orderNo}&returnUrl=${encodeURIComponent(returnUrl)}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    const data = await response.json();
    if (!data.success) throw new Error(data.error || "获取订单详情失败");
    return data.data;
  }, "获取订单详情失败");
}
const s_NlSe59RnKBs = async ({ url }) => {
  const result = await safeAsyncOperation(async () => {
    const baseUrl = url.origin;
    const response = await fetch(`${baseUrl}/api/products`);
    const data = await response.json();
    if (data.success) return data.data;
    else throw new Error(data.error || "获取商品列表失败");
  }, "加载商品列表失败");
  return result.success ? result.data : {
    products: {
      list: [],
      total: 0
    },
    paymentMethods: []
  };
};
const useProductsLoader = routeLoaderQrl(/* @__PURE__ */ inlinedQrl(s_NlSe59RnKBs, "s_NlSe59RnKBs"));
const s_JM6a9kNYMAE = () => {
  const [store] = useLexicalScope();
  saveUserChoices(store.orderConfig.selectedProduct, store.orderConfig.selectedPayment, store.orderConfig.quantity);
};
const s_nuj8ZMDx6JU = () => {
  const [productsData, store] = useLexicalScope();
  if (!store.orderConfig.selectedPayment && productsData.value.paymentMethods.length > 0) {
    const enabledPaymentMethods = productsData.value.paymentMethods;
    if (enabledPaymentMethods.length > 0) {
      store.orderConfig.selectedPayment = enabledPaymentMethods[0];
      return true;
    }
  }
  return false;
};
const s_naMQsUFBW6Q = async (createdAt) => {
  const [store] = useLexicalScope();
  const calculateRemaining = () => {
    const created = new Date(createdAt);
    const now = /* @__PURE__ */ new Date();
    const expireTime = new Date(created.getTime() + 9e5);
    return Math.max(0, Math.floor((expireTime.getTime() - now.getTime()) / 1e3));
  };
  store.payment.timeRemaining = calculateRemaining();
  store.payment.isExpired = store.payment.timeRemaining <= 0;
  if (store.payment.timeRemaining > 0) {
    if (store.payment.countdownTimerId) clearInterval(store.payment.countdownTimerId);
    store.payment.countdownTimerId = setInterval(() => {
      const remaining = calculateRemaining();
      store.payment.timeRemaining = remaining;
      if (remaining <= 0) {
        store.payment.isExpired = true;
        if (store.payment.countdownTimerId) {
          clearInterval(store.payment.countdownTimerId);
          store.payment.countdownTimerId = null;
        }
      }
    }, 1e3);
  }
};
const s_GeWwv3oL9qU = () => {
  const [store] = useLexicalScope();
  if (store.payment.countdownTimerId) {
    clearInterval(store.payment.countdownTimerId);
    store.payment.countdownTimerId = null;
  }
};
const s_q6U0B105hNo = () => {
  const [store] = useLexicalScope();
  if (store.payment.pollingTimerId) {
    clearTimeout(store.payment.pollingTimerId);
    store.payment.pollingTimerId = null;
  }
  store.payment.pollingCount = 0;
};
const s_jJA842Zg3Rw = () => {
  const [stopCountdown, store] = useLexicalScope();
  if (store.payment.pollingTimerId) {
    clearTimeout(store.payment.pollingTimerId);
    store.payment.pollingTimerId = null;
  }
  store.payment.pollingCount = 0;
  const poll = async () => {
    if (!store.payment.orderInfo || !store.payment.orderInfo.order_no || store.currentStep !== OrderStep.PAYMENT_STATUS) {
      store.payment.pollingTimerId = null;
      return;
    }
    store.payment.pollingCount++;
    try {
      const returnUrl = `${window.location.origin}/?orderNo=${store.payment.orderInfo.order_no}`;
      const result = await safeGetOrderDetail(store.payment.orderInfo.order_no, returnUrl);
      if (!result.success) {
        if (store.currentStep === OrderStep.PAYMENT_STATUS && store.payment.orderInfo) store.payment.pollingTimerId = setTimeout(poll, 3e3);
        return;
      }
      const orderData = result.data;
      const newStatus = orderData.status;
      if (newStatus === 2 || newStatus === 5) {
        store.payment.pollingTimerId = null;
        stopCountdown();
        store.success.orderInfo = {
          ...store.payment.orderInfo,
          ...orderData,
          paymentInfo: orderData.paymentInfo
        };
        store.success.redeemCode = orderData.redeemCode || "";
        store.currentStep = OrderStep.SUCCESS;
        return;
      } else if (newStatus === 4) {
        store.payment.pollingTimerId = null;
        stopCountdown();
        store.error = "订单已关闭";
        store.currentStep = OrderStep.SELECT_PRODUCT;
        clearUrlSilently();
        return;
      } else {
        store.payment.orderInfo = {
          ...store.payment.orderInfo,
          status: newStatus,
          ...orderData.paymentInfo && {
            paymentInfo: orderData.paymentInfo
          }
        };
        if (store.currentStep === OrderStep.PAYMENT_STATUS && store.payment.orderInfo) store.payment.pollingTimerId = setTimeout(poll, 3e3);
        else store.payment.pollingTimerId = null;
      }
    } catch {
      if (store.currentStep === OrderStep.PAYMENT_STATUS && store.payment.orderInfo) store.payment.pollingTimerId = setTimeout(poll, 3e3);
      else store.payment.pollingTimerId = null;
    }
  };
  store.payment.pollingTimerId = setTimeout(poll, 3e3);
};
const s_WXSDGs99ICg = (product) => {
  const [ensureDefaultPayment, saveChoices, store] = useLexicalScope();
  store.productSelection.selectedProduct = product;
  store.orderConfig.selectedProduct = product;
  saveChoices();
  store.currentStep = OrderStep.ORDER_CONFIG;
  ensureDefaultPayment();
};
const s_t1F0dnXItaM = (qty) => {
  const [saveChoices, store] = useLexicalScope();
  store.orderConfig.quantity = qty;
  saveChoices();
};
const s_e3oiEnnfZVU = (method) => {
  const [saveChoices, store] = useLexicalScope();
  store.orderConfig.selectedPayment = method;
  saveChoices();
};
const s_trf0apS3WW0 = async () => {
  const [startCountdown, startPolling, store] = useLexicalScope();
  if (!store.orderConfig.selectedProduct || !store.orderConfig.selectedPayment) {
    store.error = "请选择商品和支付方式";
    return;
  }
  store.isLoading = true;
  store.error = "";
  const createResult = await safeCreateOrder(store.orderConfig.selectedProduct.id, store.orderConfig.selectedPayment.id, store.orderConfig.quantity);
  if (!createResult.success) {
    store.error = createResult.error;
    store.isLoading = false;
    return;
  }
  const orderNo = createResult.data.orderNo;
  if (!orderNo) {
    store.error = "订单创建失败：未返回订单号";
    store.isLoading = false;
    return;
  }
  updateUrlSilently(orderNo);
  const returnUrl = `${window.location.origin}/?orderNo=${orderNo}`;
  const detailResult = await safeGetOrderDetail(orderNo, returnUrl);
  if (detailResult.success) {
    store.payment.orderInfo = detailResult.data;
    store.currentStep = OrderStep.PAYMENT_STATUS;
    if (detailResult.data.created_at) await startCountdown(detailResult.data.created_at);
    startPolling();
  } else store.error = detailResult.error;
  store.isLoading = false;
};
const s_OTYsbHoCgnA = () => {
  const [productsData, saveChoices, stopCountdown, stopPolling, store] = useLexicalScope();
  if (store.currentStep === OrderStep.PAYMENT_STATUS) {
    if (store.payment.orderInfo) {
      if (!store.orderConfig.selectedPayment && store.payment.orderInfo.payment_method_id) {
        const paymentMethod = productsData.value.paymentMethods.find((method) => method.id === store.payment.orderInfo.payment_method_id);
        if (paymentMethod) store.orderConfig.selectedPayment = paymentMethod;
      }
    }
    saveChoices();
    store.currentStep = OrderStep.ORDER_CONFIG;
    clearUrlSilently();
    stopPolling();
    stopCountdown();
    store.payment.orderInfo = null;
    store.payment.timeRemaining = 0;
    store.payment.isExpired = false;
    store.error = "";
  } else if (store.currentStep === OrderStep.ORDER_CONFIG) {
    store.currentStep = OrderStep.SELECT_PRODUCT;
    store.error = "";
  } else {
    store.currentStep = OrderStep.SELECT_PRODUCT;
    clearUrlSilently();
    stopPolling();
    stopCountdown();
    store.payment.orderInfo = null;
    store.payment.timeRemaining = 0;
    store.payment.isExpired = false;
    store.success.orderInfo = null;
    store.success.redeemCode = "";
    store.error = "";
  }
};
const s_zJz001DfrqE = (url) => {
  if (typeof window !== "undefined") window.open(url, "_blank");
};
const s_0ufq6hXd0xE = () => {
  const [stopCountdown, stopPolling, store] = useLexicalScope();
  stopPolling();
  stopCountdown();
  clearUserChoices();
  store.currentStep = OrderStep.SELECT_PRODUCT;
  store.productSelection.selectedProduct = null;
  store.orderConfig.selectedProduct = null;
  store.orderConfig.selectedPayment = null;
  store.orderConfig.quantity = 1;
  store.payment.orderInfo = null;
  store.payment.timeRemaining = 0;
  store.payment.isExpired = false;
  store.success.orderInfo = null;
  store.success.redeemCode = "";
  store.error = "";
  clearUrlSilently();
};
const s_lqGVUGtYf2c = async (code) => {
  await navigator.clipboard.writeText(code);
};
const s_UC0oFS4Erjk = () => {
  const [handleResetProcess] = useLexicalScope();
  handleResetProcess();
};
const s_Ffb2InG0GWM = () => {
  const [store] = useLexicalScope();
  if (typeof window !== "undefined") {
    const redeemCode = store.success.redeemCode;
    if (redeemCode)
      window.open(`/redeem?code=${encodeURIComponent(redeemCode)}`, "_blank");
    else
      window.open("/redeem", "_blank");
  }
};
const s_Zl0usuuOGCQ = () => {
  const [saveChoices, stopCountdown, stopPolling, store] = useLexicalScope();
  stopPolling();
  stopCountdown();
  store.currentStep = OrderStep.ORDER_CONFIG;
  clearUrlSilently();
  store.payment.orderInfo = null;
  store.payment.timeRemaining = 0;
  store.payment.isExpired = false;
  store.error = "";
  saveChoices();
};
const s_B0lqk5IDDy4 = () => {
  _jsxBranch();
  const productsData = useProductsLoader();
  const location = useLocation();
  const store = useStore({
    currentStep: OrderStep.SELECT_PRODUCT,
    isLoading: false,
    error: "",
    // 步骤1：商品选择
    productSelection: {
      selectedProduct: null
    },
    // 步骤2：订单配置
    orderConfig: {
      selectedProduct: null,
      selectedPayment: null,
      quantity: 1
    },
    // 步骤3：支付状态
    payment: {
      orderInfo: null,
      timeRemaining: 0,
      isExpired: false,
      pollingCount: 0,
      pollingTimerId: null,
      countdownTimerId: null
    },
    // 步骤4：成功状态
    success: {
      orderInfo: null,
      redeemCode: ""
    }
  });
  const saveChoices = /* @__PURE__ */ inlinedQrl(s_JM6a9kNYMAE, "s_JM6a9kNYMAE", [
    store
  ]);
  const ensureDefaultPayment = /* @__PURE__ */ inlinedQrl(s_nuj8ZMDx6JU, "s_nuj8ZMDx6JU", [
    productsData,
    store
  ]);
  const getCurrentProduct = () => {
    if (store.orderConfig.selectedProduct) return store.orderConfig.selectedProduct;
    return null;
  };
  const startCountdown = /* @__PURE__ */ inlinedQrl(s_naMQsUFBW6Q, "s_naMQsUFBW6Q", [
    store
  ]);
  const stopCountdown = /* @__PURE__ */ inlinedQrl(s_GeWwv3oL9qU, "s_GeWwv3oL9qU", [
    store
  ]);
  const stopPolling = /* @__PURE__ */ inlinedQrl(s_q6U0B105hNo, "s_q6U0B105hNo", [
    store
  ]);
  const startPolling = /* @__PURE__ */ inlinedQrl(s_jJA842Zg3Rw, "s_jJA842Zg3Rw", [
    stopCountdown,
    store
  ]);
  useVisibleTaskQrl(/* @__PURE__ */ _noopQrl("s_hs55Cc65pvA", [
    location,
    productsData,
    startCountdown,
    startPolling,
    store
  ]));
  const handleProductSelect = /* @__PURE__ */ inlinedQrl(s_WXSDGs99ICg, "s_WXSDGs99ICg", [
    ensureDefaultPayment,
    saveChoices,
    store
  ]);
  const handleQuantityChange = /* @__PURE__ */ inlinedQrl(s_t1F0dnXItaM, "s_t1F0dnXItaM", [
    saveChoices,
    store
  ]);
  const handlePaymentMethodChange = /* @__PURE__ */ inlinedQrl(s_e3oiEnnfZVU, "s_e3oiEnnfZVU", [
    saveChoices,
    store
  ]);
  const handleCreateOrder = /* @__PURE__ */ inlinedQrl(s_trf0apS3WW0, "s_trf0apS3WW0", [
    startCountdown,
    startPolling,
    store
  ]);
  const handleGoBack = /* @__PURE__ */ inlinedQrl(s_OTYsbHoCgnA, "s_OTYsbHoCgnA", [
    productsData,
    saveChoices,
    stopCountdown,
    stopPolling,
    store
  ]);
  const handleGoToPayment = /* @__PURE__ */ inlinedQrl(s_zJz001DfrqE, "s_zJz001DfrqE");
  const handleResetProcess = /* @__PURE__ */ inlinedQrl(s_0ufq6hXd0xE, "s_0ufq6hXd0xE", [
    stopCountdown,
    stopPolling,
    store
  ]);
  const handleCopyRedeemCode = /* @__PURE__ */ inlinedQrl(s_lqGVUGtYf2c, "s_lqGVUGtYf2c");
  const handleContinueShopping = /* @__PURE__ */ inlinedQrl(s_UC0oFS4Erjk, "s_UC0oFS4Erjk", [
    handleResetProcess
  ]);
  const handleGoToRedeem = /* @__PURE__ */ inlinedQrl(s_Ffb2InG0GWM, "s_Ffb2InG0GWM", [
    store
  ]);
  const handleCancelOrder = /* @__PURE__ */ inlinedQrl(s_Zl0usuuOGCQ, "s_Zl0usuuOGCQ", [
    saveChoices,
    stopCountdown,
    stopPolling,
    store
  ]);
  return /* @__PURE__ */ _jsxC(Fragment, {
    children: [
      /* @__PURE__ */ _jsxC(StepIndicator, {
        get currentStep() {
          return store.currentStep;
        },
        [_IMMUTABLE]: {
          currentStep: _fnSignal((p0) => p0.currentStep, [
            store
          ], "p0.currentStep")
        }
      }, 3, "i8_0"),
      /* @__PURE__ */ _jsxQ("main", null, {
        class: "mx-auto max-w-6xl p-4"
      }, [
        /* @__PURE__ */ _jsxC(ErrorDisplay, {
          get error() {
            return store.error;
          },
          [_IMMUTABLE]: {
            error: _fnSignal((p0) => p0.error, [
              store
            ], "p0.error")
          }
        }, 3, "i8_1"),
        store.currentStep === OrderStep.SELECT_PRODUCT && /* @__PURE__ */ _jsxC(ProductSelector, {
          get products() {
            return productsData.value.products.list;
          },
          onProductSelect: handleProductSelect,
          [_IMMUTABLE]: {
            products: _fnSignal((p0) => p0.value.products.list, [
              productsData
            ], "p0.value.products.list"),
            onProductSelect: _IMMUTABLE
          }
        }, 3, "i8_2"),
        store.currentStep === OrderStep.ORDER_CONFIG && store.orderConfig.selectedProduct && /* @__PURE__ */ _jsxC(OrderConfig, {
          get selectedProduct() {
            return store.orderConfig.selectedProduct;
          },
          get selectedPayment() {
            return store.orderConfig.selectedPayment;
          },
          get paymentMethods() {
            return productsData.value.paymentMethods;
          },
          get quantity() {
            return store.orderConfig.quantity;
          },
          get isLoading() {
            return store.isLoading;
          },
          onQuantityChange: handleQuantityChange,
          onPaymentMethodChange: handlePaymentMethodChange,
          onCreateOrder: handleCreateOrder,
          onGoBack: handleGoBack,
          [_IMMUTABLE]: {
            selectedProduct: _fnSignal((p0) => p0.orderConfig.selectedProduct, [
              store
            ], "p0.orderConfig.selectedProduct"),
            selectedPayment: _fnSignal((p0) => p0.orderConfig.selectedPayment, [
              store
            ], "p0.orderConfig.selectedPayment"),
            paymentMethods: _fnSignal((p0) => p0.value.paymentMethods, [
              productsData
            ], "p0.value.paymentMethods"),
            quantity: _fnSignal((p0) => p0.orderConfig.quantity, [
              store
            ], "p0.orderConfig.quantity"),
            isLoading: _fnSignal((p0) => p0.isLoading, [
              store
            ], "p0.isLoading"),
            onQuantityChange: _IMMUTABLE,
            onPaymentMethodChange: _IMMUTABLE,
            onCreateOrder: _IMMUTABLE,
            onGoBack: _IMMUTABLE
          }
        }, 3, "i8_3"),
        store.currentStep === OrderStep.PAYMENT_STATUS && store.payment.orderInfo && !store.isLoading && /* @__PURE__ */ _jsxC(PaymentStatus, {
          get orderInfo() {
            return store.payment.orderInfo;
          },
          currentProduct: getCurrentProduct(),
          get quantity() {
            return store.orderConfig.quantity;
          },
          get timeRemaining() {
            return store.payment.timeRemaining;
          },
          onGoToPayment: handleGoToPayment,
          onResetProcess: handleResetProcess,
          onGoBack: handleGoBack,
          onCancelOrder: handleCancelOrder,
          [_IMMUTABLE]: {
            orderInfo: _fnSignal((p0) => p0.payment.orderInfo, [
              store
            ], "p0.payment.orderInfo"),
            quantity: _fnSignal((p0) => p0.orderConfig.quantity, [
              store
            ], "p0.orderConfig.quantity"),
            timeRemaining: _fnSignal((p0) => p0.payment.timeRemaining, [
              store
            ], "p0.payment.timeRemaining"),
            onGoToPayment: _IMMUTABLE,
            onResetProcess: _IMMUTABLE,
            onGoBack: _IMMUTABLE,
            onCancelOrder: _IMMUTABLE
          }
        }, 3, "i8_4"),
        store.currentStep === OrderStep.SUCCESS && store.success.orderInfo && /* @__PURE__ */ _jsxC(SuccessPage, {
          get redeemCode() {
            return store.success.redeemCode;
          },
          onCopyRedeemCode: handleCopyRedeemCode,
          onContinueShopping: handleContinueShopping,
          onGoToRedeem: handleGoToRedeem,
          [_IMMUTABLE]: {
            redeemCode: _fnSignal((p0) => p0.success.redeemCode, [
              store
            ], "p0.success.redeemCode"),
            onCopyRedeemCode: _IMMUTABLE,
            onContinueShopping: _IMMUTABLE,
            onGoToRedeem: _IMMUTABLE
          }
        }, 3, "i8_5")
      ], 1, null)
    ]
  }, 1, "i8_6");
};
const index$1 = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_B0lqk5IDDy4, "s_B0lqk5IDDy4"));
const IndexRoute = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$1,
  useProductsLoader
}, Symbol.toStringTag, { value: "Module" }));
async function queryOrderDetail(params, options) {
  return request("/v1/public/order/detail", {
    method: "GET",
    params: {
      ...params
    },
    ...options || {}
  });
}
async function purchase(body, options) {
  return request("/v1/public/order/purchase", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    data: body,
    ...options || {}
  });
}
async function recharge(body, options) {
  return request("/v1/public/order/recharge", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    data: body,
    ...options || {}
  });
}
async function updateCoupon(body, options) {
  return request("/v1/admin/coupon/", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json"
    },
    data: body,
    ...options || {}
  });
}
async function createCoupon(body, options) {
  return request("/v1/admin/coupon/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    data: body,
    ...options || {}
  });
}
async function getCouponList(params, options) {
  return request("/v1/admin/coupon/list", {
    method: "GET",
    params: {
      ...params
    },
    ...options || {}
  });
}
async function getSubscribeDetails(params, options) {
  return request("/v1/admin/subscribe/details", {
    method: "GET",
    params: {
      ...params
    },
    ...options || {}
  });
}
const onPost$1 = async ({ json, parseBody, sharedMap }) => {
  var _a;
  const authOptions = sharedMap.get("authOptions") || {};
  try {
    const body = await parseBody();
    const { subscribeId, paymentMethod, quantity = 1 } = body;
    if (!subscribeId || !paymentMethod) {
      json(400, {
        success: false,
        error: "缺少必要参数：subscribeId 和 paymentMethod"
      });
      return;
    }
    const subscribeResponse = await getSubscribeDetails({
      id: subscribeId
    }, authOptions);
    const subscribeDetails = subscribeResponse.data.data;
    if (!subscribeDetails) {
      json(404, {
        success: false,
        error: "商品不存在"
      });
      return;
    }
    if (!subscribeDetails.sell || !subscribeDetails.show) {
      json(400, {
        success: false,
        error: "商品不可购买"
      });
      return;
    }
    const amount = subscribeDetails.unit_price * quantity;
    const orderResponse = await recharge({
      amount,
      payment: paymentMethod
    }, authOptions);
    const orderNo = (_a = orderResponse.data.data) == null ? void 0 : _a.order_no;
    if (!orderNo) {
      json(500, {
        success: false,
        error: "创建订单失败"
      });
      return;
    }
    const currentTime = Math.floor(Date.now());
    const expireTime = currentTime + 31536e6;
    await createCoupon({
      name: `${orderNo}-${quantity}`,
      code: ``,
      count: 1,
      type: 1,
      discount: 100,
      start_time: currentTime,
      expire_time: expireTime,
      user_limit: 1,
      subscribe: [
        subscribeId
      ],
      used_count: 0,
      enable: false
    }, authOptions).catch((error) => {
      console.error("创建兑换码失败:", error.message);
    });
    json(200, {
      success: true,
      data: {
        orderNo
      },
      message: "订单创建成功"
    });
  } catch (error) {
    json(500, {
      success: false,
      error: "创建订单失败",
      details: error.message
    });
  }
};
const ApiOrdersCreateRoute = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  onPost: onPost$1
}, Symbol.toStringTag, { value: "Module" }));
async function purchaseCheckout(body, options) {
  return request("/v1/public/portal/order/checkout", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    data: body,
    ...options || {}
  });
}
var define_import_meta_env_default = { BASE_URL: "/", DEV: false, MODE: "production", PROD: true, SSR: true };
const onGet$2 = async ({ json, query, sharedMap }) => {
  var _a;
  const authOptions = sharedMap.get("authOptions") || {};
  try {
    const orderNo = query.get("orderNo");
    if (!orderNo) {
      json(400, {
        success: false,
        error: "缺少必要参数：orderNo"
      });
      return;
    }
    const orderResponse = await queryOrderDetail({
      order_no: orderNo
    }, authOptions);
    const order = orderResponse.data.data;
    if (!order) {
      json(404, {
        success: false,
        error: "订单不存在"
      });
      return;
    }
    if (order.status !== 2 && order.status !== 5) {
      if (order.status === 1) try {
        const returnUrl = query.get("returnUrl") || `${define_import_meta_env_default.SITE_URL || "http://localhost:5173"}/?orderNo=${orderNo}`;
        const checkoutResponse = await purchaseCheckout({
          orderNo,
          returnUrl
        }, authOptions);
        const checkoutData = checkoutResponse.data.data;
        json(200, {
          success: true,
          data: {
            ...order,
            paymentInfo: {
              type: (checkoutData == null ? void 0 : checkoutData.type) || "redirect",
              checkoutUrl: checkoutData == null ? void 0 : checkoutData.checkout_url,
              stripe: checkoutData == null ? void 0 : checkoutData.stripe
            }
          },
          message: "订单待支付，已获取支付信息"
        });
        return;
      } catch (checkoutError) {
        console.error("获取支付信息失败:", checkoutError.message);
        json(200, {
          success: true,
          data: order,
          message: "订单待支付，但获取支付信息失败",
          error: "获取支付信息失败"
        });
        return;
      }
      json(200, {
        success: true,
        data: order,
        message: order.status === 1 ? "订单待支付" : order.status === 3 ? "订单已取消" : order.status === 4 ? "订单已关闭" : "订单处理中"
      });
      return;
    }
    const couponListResponse = await getCouponList({
      page: 1,
      size: 10,
      search: orderNo
    }, authOptions);
    const coupons = ((_a = couponListResponse.data.data) == null ? void 0 : _a.list) || [];
    const targetCoupon = coupons.find((coupon) => {
      var _a2;
      return (_a2 = coupon.name) == null ? void 0 : _a2.startsWith(`${orderNo}-`);
    });
    if (!targetCoupon) {
      json(500, {
        success: false,
        error: "未找到对应的兑换码"
      });
      return;
    }
    await updateCoupon({
      ...targetCoupon,
      enable: true
    }, authOptions);
    json(200, {
      success: true,
      data: {
        ...order,
        redeemCode: targetCoupon.code
      },
      message: "订单已支付，兑换码已生成"
    });
  } catch (error) {
    json(500, {
      success: false,
      error: "查询订单详情失败",
      details: error.message
    });
  }
};
const ApiOrdersDetailRoute = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  onGet: onGet$2
}, Symbol.toStringTag, { value: "Module" }));
const onGet$1 = async ({ json, sharedMap }) => {
  try {
    const globalSiteConfig2 = sharedMap.get("globalSiteConfig");
    const publicConfig = {
      site: (globalSiteConfig2 == null ? void 0 : globalSiteConfig2.site) ? {
        site_name: globalSiteConfig2.site.site_name || "数字卡片发放平台",
        site_desc: globalSiteConfig2.site.site_desc || "安全便捷的数字产品购买与激活",
        site_logo: globalSiteConfig2.site.site_logo || "",
        keywords: globalSiteConfig2.site.keywords || "",
        custom_html: globalSiteConfig2.site.custom_html || ""
      } : {
        site_name: "数字卡片发放平台",
        site_desc: "安全便捷的数字产品购买与激活",
        site_logo: "",
        keywords: "",
        custom_html: ""
      },
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    json(200, {
      success: true,
      data: publicConfig,
      message: "获取站点配置成功"
    });
  } catch (error) {
    console.error("获取站点配置失败：", error);
    json(500, {
      success: false,
      error: error.message || "获取站点配置失败",
      message: "服务器内部错误"
    });
  }
};
const ApiConfigRoute = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  onGet: onGet$1
}, Symbol.toStringTag, { value: "Module" }));
async function querySubscribeList(options) {
  return request("/v1/public/subscribe/list", {
    method: "GET",
    ...options || {}
  });
}
async function getAvailablePaymentMethods(options) {
  return request("/v1/public/payment/methods", {
    method: "GET",
    ...options || {}
  });
}
function formatProductDescription(descriptionJson) {
  try {
    return JSON.parse(descriptionJson);
  } catch {
    return {
      description: descriptionJson,
      features: []
    };
  }
}
const onGet = async ({ json, sharedMap }) => {
  var _a, _b, _c;
  const authOptions = sharedMap.get("authOptions") || {};
  try {
    const [subscribeResponse, paymentResponse] = await Promise.all([
      querySubscribeList(authOptions),
      getAvailablePaymentMethods(authOptions)
    ]);
    const products = ((_a = subscribeResponse.data.data) == null ? void 0 : _a.list.filter((item) => item.show && item.sell).map((product) => ({
      ...product,
      description: formatProductDescription(product.description)
    }))) || [];
    const paymentMethods = (((_b = paymentResponse.data.data) == null ? void 0 : _b.list) || []).filter((method) => method.id !== -1);
    json(200, {
      success: true,
      data: {
        products: {
          list: products,
          total: ((_c = subscribeResponse.data.data) == null ? void 0 : _c.total) || 0
        },
        paymentMethods
      },
      message: "获取商品列表和支付方式成功"
    });
  } catch (error) {
    json(500, {
      success: false,
      error: "获取商品列表失败",
      details: error.message
    });
  }
};
const ApiProductsRoute = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  onGet
}, Symbol.toStringTag, { value: "Module" }));
async function queryUserSubscribe(options) {
  return request("/v1/public/user/subscribe", {
    method: "GET",
    ...options || {}
  });
}
async function createUser(body, options) {
  return request("/v1/admin/user/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    data: body,
    ...options || {}
  });
}
function universalBase64Encode(str) {
  if (typeof globalThis.Buffer !== "undefined")
    return globalThis.Buffer.from(str).toString("base64");
  else if (typeof btoa !== "undefined")
    return btoa(str);
  else {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let result = "";
    let i = 0;
    while (i < str.length) {
      const byte1 = str.charCodeAt(i++);
      const byte2 = i < str.length ? str.charCodeAt(i++) : 0;
      const byte3 = i < str.length ? str.charCodeAt(i++) : 0;
      const bitmap = byte1 << 16 | byte2 << 8 | byte3;
      result += chars.charAt(bitmap >> 18 & 63);
      result += chars.charAt(bitmap >> 12 & 63);
      result += i - 2 < str.length ? chars.charAt(bitmap >> 6 & 63) : "=";
      result += i - 1 < str.length ? chars.charAt(bitmap & 63) : "=";
    }
    return result;
  }
}
function extractDomain(url, extractRoot = true) {
  try {
    const { hostname } = new URL(url);
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(hostname)) return hostname;
    const domainParts = hostname.split(".").filter(Boolean);
    if (extractRoot && domainParts.length > 2) return domainParts.slice(-2).join(".");
    return hostname;
  } catch {
    return null;
  }
}
function generateAllSubscribeLinks(token, config, url, siteName) {
  if (!token) return {};
  const subscribeConfig = (config == null ? void 0 : config.subscribe) || {};
  const { pan_domain = false, subscribe_domain = "", subscribe_path = "" } = subscribeConfig;
  const domains = subscribe_domain ? subscribe_domain.split("\n").filter((d) => d.trim()) : [
    extractDomain(url.origin, pan_domain) || url.hostname
  ];
  const baseUrls = domains.map((domain) => {
    const cleanDomain = domain.trim();
    if (pan_domain) return `https://${token}.${cleanDomain}`;
    else return `https://${cleanDomain}${subscribe_path}?token=${token}`;
  });
  const randomIndex = Math.floor(Math.random() * baseUrls.length);
  const defaultUrl = baseUrls[randomIndex];
  const appTypes = [
    "Clash",
    "Hiddify",
    "Loon",
    "NekoBox",
    "NekoRay",
    "Quantumult",
    "Shadowrocket",
    "Singbox",
    "Surfboard",
    "Surge",
    "V2box",
    "V2rayNg",
    "Stash"
  ];
  const subscribeLinks = {
    default: defaultUrl
  };
  for (const appType of appTypes) {
    const typeUrls = domains.map((domain) => {
      const cleanDomain = domain.trim();
      if (pan_domain) return `https://${token}.${appType.toLowerCase()}.${cleanDomain}`;
      else return `https://${cleanDomain}${subscribe_path}?token=${token}&type=${appType.toLowerCase()}`;
    });
    const typeRandomIndex = Math.floor(Math.random() * typeUrls.length);
    const typeUrl = typeUrls[typeRandomIndex];
    subscribeLinks[appType] = getAppSubLink(appType, typeUrl, siteName);
  }
  return subscribeLinks;
}
function getAppSubLink(type, url, siteName) {
  switch (type) {
    case "Clash":
      return `clash://install-config?url=${url}&name=${siteName}`;
    case "Hiddify":
      return `hiddify://import/${url}#${siteName}`;
    case "Loon":
      return `loon://import?sub=${encodeURIComponent(url)}&name=${encodeURIComponent(siteName)}`;
    case "NekoBox":
      return `sn://subscription?url=${url}&name=${siteName}`;
    case "NekoRay":
      return `sn://subscription?url=${url}&name=${siteName}`;
    case "Quantumult":
      return `quantumult-x://add-resource?remote-resource=${encodeURIComponent(JSON.stringify({
        server_remote: [
          `${url}, tag=${siteName}`
        ]
      }))}`;
    case "Shadowrocket":
      return `shadowrocket://add/sub://${universalBase64Encode(url)}?remark=${encodeURIComponent(siteName)}`;
    case "Singbox":
      return `sing-box://import-remote-profile?url=${encodeURIComponent(url)}#${siteName}`;
    case "Surfboard":
      return `surfboard:///install-config?url=${encodeURIComponent(url)}`;
    case "Surge":
      return `surge:///install-config?url=${encodeURIComponent(url)}`;
    case "V2box":
      return `v2box://install-sub?url=${encodeURIComponent(url)}&name=${siteName}`;
    case "V2rayNg":
      return `v2rayng://install-sub?url=${encodeURIComponent(url)}#${siteName}`;
    case "Stash":
      return `stash://install-config?url=${encodeURIComponent(url)}&name=${siteName}`;
    default:
      return "";
  }
}
function generateRandomPassword(length = 12) {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
  let password = "";
  for (let i = 0; i < length; i++) password += charset.charAt(Math.floor(Math.random() * charset.length));
  return password;
}
function generateDomainEmail(domain) {
  const timestamp = Date.now();
  const randomNum = Math.floor(Math.random() * 1e4);
  return `user${timestamp}${randomNum}@${domain}`;
}
function getValidEmailDomain(hostname) {
  if (hostname && hostname.includes(".") && !hostname.startsWith(".") && !hostname.endsWith(".")) return hostname;
  return "ppanel.dev";
}
const onPost = async ({ json, parseBody, sharedMap, url }) => {
  var _a, _b, _c, _d, _e;
  const authOptions = sharedMap.get("authOptions") || {};
  const globalConfig = sharedMap.get("globalSiteConfig");
  try {
    const body = await parseBody();
    const { redeemCode } = body;
    if (!redeemCode.trim()) {
      json(400, {
        success: false,
        error: "兑换码不能为空"
      });
      return;
    }
    const domain = getValidEmailDomain(url.hostname);
    const autoEmail = generateDomainEmail(domain);
    const autoPassword = generateRandomPassword(12);
    const couponListResponse = await getCouponList({
      page: 1,
      size: 1,
      search: redeemCode
    }, authOptions);
    const coupons = ((_a = couponListResponse.data.data) == null ? void 0 : _a.list) || [];
    const targetCoupon = coupons.find((coupon) => coupon.code === redeemCode && coupon.enable === true);
    if (!targetCoupon) {
      json(400, {
        success: false,
        error: "兑换码无效或已被禁用"
      });
      return;
    }
    const currentTime = Math.floor(Date.now() / 1e3);
    if (targetCoupon.expire_time && targetCoupon.expire_time < currentTime) {
      json(400, {
        success: false,
        error: "兑换码已过期"
      });
      return;
    }
    if (targetCoupon.used_count >= targetCoupon.count) {
      json(400, {
        success: false,
        error: "兑换码已达到使用上限"
      });
      return;
    }
    const subscribeIds = targetCoupon.subscribe || [];
    if (!subscribeIds.length) {
      json(400, {
        success: false,
        error: "兑换码未绑定任何商品"
      });
      return;
    }
    const subscribeId = subscribeIds[0];
    let quantity = 1;
    if (targetCoupon.name.includes("-")) {
      const nameParts = targetCoupon.name.split("-");
      const lastPart = nameParts[nameParts.length - 1];
      const parsedQuantity = parseInt(lastPart, 10);
      if (!isNaN(parsedQuantity) && parsedQuantity > 0) quantity = parsedQuantity;
    }
    let createUserResponse;
    try {
      createUserResponse = await createUser({
        email: autoEmail,
        telephone: "",
        telephone_area_code: "",
        password: autoPassword,
        product_id: 0,
        duration: 0,
        referer_user: "",
        refer_code: "",
        balance: 100,
        commission: 0,
        gift_amount: 0,
        is_admin: false
      }, authOptions);
    } catch (error) {
      console.error("创建用户失败:", error);
      throw new Error("创建用户失败");
    }
    if (!createUserResponse) throw new Error("创建用户响应为空");
    const loginResponse = await userLogin({
      email: autoEmail,
      password: autoPassword
    }, {
      baseURL: authOptions.baseURL || url.origin,
      Authorization: ""
    });
    if (!((_b = loginResponse.data.data) == null ? void 0 : _b.token)) throw new Error("自动登录失败");
    const token = loginResponse.data.data.token;
    const authOptionsWithToken = {
      ...authOptions,
      Authorization: token
    };
    const purchaseResponse = await purchase({
      subscribe_id: subscribeId,
      quantity,
      payment: -1,
      coupon: redeemCode
    }, authOptionsWithToken);
    if (!purchaseResponse) throw new Error("购买响应为空");
    const purchaseOrderNo = (_c = purchaseResponse.data.data) == null ? void 0 : _c.order_no;
    if (purchaseOrderNo) await purchaseCheckout({
      orderNo: purchaseOrderNo
    }, authOptionsWithToken);
    let orderNo = targetCoupon.name;
    if (targetCoupon.name.includes("-")) {
      const nameParts = targetCoupon.name.split("-");
      nameParts.pop();
      orderNo = nameParts.join("-");
    }
    await new Promise((resolve) => setTimeout(resolve, 3e3));
    const subscriptionResponse = await queryUserSubscribe(authOptionsWithToken);
    const subscriptions = ((_d = subscriptionResponse.data.data) == null ? void 0 : _d.list) || [];
    const subscription = subscriptions.length > 0 ? subscriptions[0] : null;
    let subscribeLinks = {};
    if ((subscription == null ? void 0 : subscription.token) && globalConfig) {
      const siteName = ((_e = globalConfig.site) == null ? void 0 : _e.site_name) || "订阅服务";
      subscribeLinks = generateAllSubscribeLinks(subscription.token, globalConfig, url, siteName);
    }
    json(200, {
      success: true,
      data: {
        orderNo,
        quantity,
        subscription,
        subscribeLinks
      },
      message: "兑换码激活成功，订阅已创建"
    });
  } catch (error) {
    json(500, {
      success: false,
      error: "激活兑换码时发生错误",
      details: error.message
    });
  }
};
const ApiRedeemRoute = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  onPost
}, Symbol.toStringTag, { value: "Module" }));
const s_lLHP6ncra00 = async (text) => {
  try {
    const dataUrl = await QRCode$1.toDataURL(text, {
      width: 200,
      margin: 2,
      color: {
        dark: "#000000",
        light: "#FFFFFF"
      }
    });
    return dataUrl;
  } catch (err) {
    console.error("生成二维码失败:", err);
    return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(text)}`;
  }
};
const s_8BfOSddddMg = async () => {
  var _a;
  const [error, generateQRCode, isLoading, qrCodeDataUrl, redeemCode, redeemResult] = useLexicalScope();
  if (!redeemCode.value.trim()) {
    error.value = "请输入兑换码";
    return;
  }
  isLoading.value = true;
  error.value = "";
  try {
    const response = await fetch("/api/redeem", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        redeemCode: redeemCode.value.trim()
      })
    });
    const data = await response.json();
    if (data.success) {
      redeemResult.value = data.data;
      localStorage.setItem("redeemResult", JSON.stringify(data.data));
      if ((_a = data.data.subscribeLinks) == null ? void 0 : _a.default) generateQRCode(data.data.subscribeLinks.default).then((url) => {
        qrCodeDataUrl.value = url;
      });
    } else error.value = data.error || "激活失败，请检查兑换码是否正确";
  } catch (err) {
    console.error("激活兑换码失败:", err);
    error.value = "网络错误，请重试";
  } finally {
    isLoading.value = false;
  }
};
const s_K74wC07VK3w = () => {
  localStorage.removeItem("redeemResult");
  window.location.href = "/";
};
const s_IvAmdwXNTM4 = async (text) => {
  const [copySuccess] = useLexicalScope();
  try {
    await navigator.clipboard.writeText(text);
    copySuccess.value = "链接已复制到剪贴板";
    setTimeout(() => {
      copySuccess.value = "";
    }, 3e3);
  } catch (err) {
    console.error("复制失败:", err);
    copySuccess.value = "复制失败，请手动复制";
    setTimeout(() => {
      copySuccess.value = "";
    }, 3e3);
  }
};
const s_WqP80aZTB6s = () => {
  var _a;
  _jsxBranch();
  const location = useLocation();
  const redeemCode = useSignal(location.url.searchParams.get("code") || "");
  const isLoading = useSignal(false);
  const redeemResult = useSignal(null);
  const error = useSignal("");
  const copySuccess = useSignal("");
  const qrCodeDataUrl = useSignal("");
  const generateQRCode = /* @__PURE__ */ inlinedQrl(s_lLHP6ncra00, "s_lLHP6ncra00");
  useVisibleTaskQrl(/* @__PURE__ */ _noopQrl("s_ZqIsJSAU9MM", [
    generateQRCode,
    qrCodeDataUrl,
    redeemResult
  ]));
  const activateCode = /* @__PURE__ */ inlinedQrl(s_8BfOSddddMg, "s_8BfOSddddMg", [
    error,
    generateQRCode,
    isLoading,
    qrCodeDataUrl,
    redeemCode,
    redeemResult
  ]);
  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleString("zh-CN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });
  };
  const formatBytesWithUnlimited2 = (bytes) => {
    if (bytes === 0) return "无限制";
    return formatBytes(bytes);
  };
  const clearAndGoHome = /* @__PURE__ */ inlinedQrl(s_K74wC07VK3w, "s_K74wC07VK3w");
  const copyToClipboard = /* @__PURE__ */ inlinedQrl(s_IvAmdwXNTM4, "s_IvAmdwXNTM4", [
    copySuccess
  ]);
  return /* @__PURE__ */ _jsxQ("main", null, {
    class: "mx-auto max-w-6xl px-4 py-6"
  }, [
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "mb-6 text-center"
    }, [
      /* @__PURE__ */ _jsxQ("h1", null, {
        class: "mb-2 text-2xl font-semibold tracking-tight"
      }, "激活兑换码", 3, null),
      /* @__PURE__ */ _jsxQ("p", null, {
        class: "text-muted-foreground/80 mx-auto max-w-md text-sm"
      }, "请输入您的兑换码以激活订阅服务", 3, null)
    ], 3, null),
    !redeemResult.value ? (
      /* 兑换码输入界面 */
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "mx-auto max-w-2xl"
      }, /* @__PURE__ */ _jsxQ("div", null, {
        class: "bg-card/90 text-card-foreground border-border/50 rounded-xl border p-6 shadow-lg backdrop-blur-sm"
      }, [
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "mb-8 text-center"
        }, [
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "bg-primary/10 border-primary/20 mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full border shadow-sm"
          }, /* @__PURE__ */ _jsxC(LuKey, {
            class: "text-primary h-10 w-10",
            [_IMMUTABLE]: {
              class: _IMMUTABLE
            }
          }, 3, "vb_0"), 1, null),
          /* @__PURE__ */ _jsxQ("h2", null, {
            class: "text-2xl font-semibold tracking-tight"
          }, "请输入兑换码", 3, null)
        ], 1, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "space-y-6"
        }, [
          /* @__PURE__ */ _jsxQ("div", null, null, [
            /* @__PURE__ */ _jsxQ("label", null, {
              class: "mb-3 block text-sm font-medium"
            }, "兑换码", 3, null),
            /* @__PURE__ */ _jsxQ("input", null, {
              type: "text",
              value: _fnSignal((p0) => p0.value, [
                redeemCode
              ], "p0.value"),
              placeholder: "请输入兑换码",
              class: "border-input bg-background ring-offset-background placeholder:text-muted-foreground/60 focus-visible:ring-primary flex h-12 w-full rounded-lg border px-4 py-3 text-center font-mono text-lg tracking-wider shadow-sm file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50",
              maxLength: 50,
              onInput$: /* @__PURE__ */ _noopQrl("s_wqmFiuqc0n0", [
                redeemCode
              ])
            }, null, 3, null),
            /* @__PURE__ */ _jsxQ("p", null, {
              class: "text-muted-foreground/70 mt-2 text-sm"
            }, "兑换码格式: XXXXX-XXXXX-XXXXX-XXXXX-XXXXX", 3, null)
          ], 3, null),
          error.value && /* @__PURE__ */ _jsxQ("div", null, {
            class: "border-destructive/30 bg-destructive/5 rounded-lg border p-4 shadow-sm backdrop-blur-sm"
          }, /* @__PURE__ */ _jsxQ("div", null, {
            class: "flex items-center space-x-2"
          }, [
            /* @__PURE__ */ _jsxC(LuAlertCircle, {
              class: "text-destructive h-5 w-5 flex-shrink-0",
              [_IMMUTABLE]: {
                class: _IMMUTABLE
              }
            }, 3, "vb_1"),
            /* @__PURE__ */ _jsxQ("span", null, {
              class: "text-destructive font-medium"
            }, _fnSignal((p0) => p0.value, [
              error
            ], "p0.value"), 3, null)
          ], 1, null), 1, "vb_2"),
          /* @__PURE__ */ _jsxQ("button", null, {
            disabled: _fnSignal((p0, p1) => p0.value || !p1.value.trim(), [
              isLoading,
              redeemCode
            ], "p0.value||!p1.value.trim()"),
            class: "bg-primary text-primary-foreground ring-offset-background hover:bg-primary/90 focus-visible:ring-primary inline-flex h-12 w-full items-center justify-center rounded-lg px-8 text-base font-medium shadow-sm transition-colors hover:shadow-md focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50",
            onClick$: activateCode
          }, isLoading.value ? /* @__PURE__ */ _jsxQ("span", null, {
            class: "flex items-center justify-center"
          }, [
            /* @__PURE__ */ _jsxC(LuLoader, {
              class: "mr-3 -ml-1 h-5 w-5 animate-spin",
              [_IMMUTABLE]: {
                class: _IMMUTABLE
              }
            }, 3, "vb_3"),
            "激活中..."
          ], 1, "vb_4") : "激活兑换码", 1, null),
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "bg-muted/50 border-border/50 rounded-lg border p-4 shadow-sm"
          }, [
            /* @__PURE__ */ _jsxQ("h3", null, {
              class: "mb-2 text-sm font-semibold"
            }, "温馨提示", 3, null),
            /* @__PURE__ */ _jsxQ("ul", null, {
              class: "text-muted-foreground/80 space-y-1 text-sm"
            }, [
              /* @__PURE__ */ _jsxQ("li", null, null, "• 每个兑换码仅可使用一次", 3, null),
              /* @__PURE__ */ _jsxQ("li", null, null, "• 兑换码激活后立即生效", 3, null),
              /* @__PURE__ */ _jsxQ("li", null, null, "• 如遇问题请联系客服协助", 3, null)
            ], 3, null)
          ], 3, null)
        ], 1, null)
      ], 1, null), 1, "vb_5")
    ) : (
      /* 激活成功界面 */
      /* @__PURE__ */ _jsxQ("div", null, {
        class: "space-y-6"
      }, [
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "mx-auto max-w-5xl"
        }, /* @__PURE__ */ _jsxQ("div", null, {
          class: "bg-card/90 text-card-foreground border-border/50 rounded-xl border p-4 shadow-lg backdrop-blur-sm"
        }, /* @__PURE__ */ _jsxQ("div", null, {
          class: "flex items-center justify-center space-x-4"
        }, [
          /* @__PURE__ */ _jsxQ("div", null, {
            class: "bg-primary/10 border-primary/20 flex h-16 w-16 items-center justify-center rounded-full border shadow-sm"
          }, /* @__PURE__ */ _jsxC(LuCheckCircle, {
            class: "text-primary h-8 w-8",
            [_IMMUTABLE]: {
              class: _IMMUTABLE
            }
          }, 3, "vb_6"), 1, null),
          /* @__PURE__ */ _jsxQ("div", null, null, [
            /* @__PURE__ */ _jsxQ("h2", null, {
              class: "text-xl font-semibold tracking-tight"
            }, "兑换成功！", 3, null),
            /* @__PURE__ */ _jsxQ("p", null, {
              class: "text-muted-foreground/80 text-sm"
            }, "订阅服务已激活，请选择以下方式配置客户端", 3, null)
          ], 3, null)
        ], 1, null), 1, null), 1, null),
        /* @__PURE__ */ _jsxQ("div", null, {
          class: "mx-auto max-w-5xl"
        }, /* @__PURE__ */ _jsxQ("div", null, {
          class: "bg-card text-card-foreground rounded-xl border p-6 shadow-lg backdrop-blur-sm"
        }, /* @__PURE__ */ _jsxQ("div", null, {
          class: "grid grid-cols-1 gap-6 lg:grid-cols-2"
        }, [
          /* @__PURE__ */ _jsxQ("div", null, null, [
            /* @__PURE__ */ _jsxQ("h3", null, {
              class: "mb-3 text-lg font-semibold"
            }, "订阅信息", 3, null),
            redeemResult.value.subscription ? /* @__PURE__ */ _jsxQ("div", null, {
              class: "space-y-3 text-sm"
            }, [
              /* @__PURE__ */ _jsxQ("div", null, {
                class: "flex items-center justify-between"
              }, [
                /* @__PURE__ */ _jsxQ("span", null, {
                  class: "font-medium"
                }, _fnSignal((p0) => p0.value.subscription.subscribe.name, [
                  redeemResult
                ], "p0.value.subscription.subscribe.name"), 3, null),
                /* @__PURE__ */ _jsxQ("span", null, {
                  class: _fnSignal((p0) => `rounded-full px-2 py-1 text-xs font-medium ${p0.value.subscription.status === 1 ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`, [
                    redeemResult
                  ], '`rounded-full px-2 py-1 text-xs font-medium ${p0.value.subscription.status===1?"bg-primary/10 text-primary":"bg-muted text-muted-foreground"}`')
                }, _fnSignal((p0) => p0.value.subscription.status === 1 ? "激活" : "未激活", [
                  redeemResult
                ], 'p0.value.subscription.status===1?"激活":"未激活"'), 3, null)
              ], 3, null),
              /* @__PURE__ */ _jsxQ("div", null, {
                class: "grid grid-cols-1 gap-2 text-sm"
              }, [
                /* @__PURE__ */ _jsxQ("div", null, {
                  class: "flex justify-between"
                }, [
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "text-muted-foreground"
                  }, "到期时间:", 3, null),
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "font-medium"
                  }, formatDate(redeemResult.value.subscription.expire_time).split(" ")[0], 1, null)
                ], 1, null),
                /* @__PURE__ */ _jsxQ("div", null, {
                  class: "flex justify-between"
                }, [
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "text-muted-foreground"
                  }, "设备限制:", 3, null),
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "font-medium"
                  }, _fnSignal((p0) => p0.value.subscription.subscribe.device_limit === 0 ? "无限制" : `${p0.value.subscription.subscribe.device_limit}个`, [
                    redeemResult
                  ], 'p0.value.subscription.subscribe.device_limit===0?"无限制":`${p0.value.subscription.subscribe.device_limit}个`'), 3, null)
                ], 3, null),
                /* @__PURE__ */ _jsxQ("div", null, {
                  class: "flex justify-between"
                }, [
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "text-muted-foreground"
                  }, "总流量:", 3, null),
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "font-medium"
                  }, formatBytesWithUnlimited2(redeemResult.value.subscription.traffic), 1, null)
                ], 1, null),
                /* @__PURE__ */ _jsxQ("div", null, {
                  class: "flex justify-between"
                }, [
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "text-muted-foreground"
                  }, "订单号:", 3, null),
                  /* @__PURE__ */ _jsxQ("span", null, {
                    class: "font-mono text-xs"
                  }, _fnSignal((p0) => p0.value.orderNo, [
                    redeemResult
                  ], "p0.value.orderNo"), 3, null)
                ], 3, null)
              ], 1, null)
            ], 1, "vb_7") : /* @__PURE__ */ _jsxQ("div", null, {
              class: "text-muted-foreground text-sm"
            }, "未找到订阅信息", 3, null),
            ((_a = redeemResult.value.subscribeLinks) == null ? void 0 : _a.default) && /* @__PURE__ */ _jsxQ("div", null, {
              class: "mt-6"
            }, [
              /* @__PURE__ */ _jsxQ("h4", null, {
                class: "mb-3 text-lg font-medium"
              }, "扫码订阅", 3, null),
              /* @__PURE__ */ _jsxQ("div", null, {
                class: "flex items-center space-x-4"
              }, [
                /* @__PURE__ */ _jsxQ("div", null, {
                  class: "bg-background flex-shrink-0 rounded-lg border p-2"
                }, qrCodeDataUrl.value ? /* @__PURE__ */ _jsxQ("img", null, {
                  src: _fnSignal((p0) => p0.value, [
                    qrCodeDataUrl
                  ], "p0.value"),
                  alt: "订阅配置二维码",
                  class: "h-24 w-24",
                  width: 96,
                  height: 96
                }, null, 3, "vb_8") : /* @__PURE__ */ _jsxQ("div", null, {
                  class: "bg-muted flex h-24 w-24 items-center justify-center rounded"
                }, /* @__PURE__ */ _jsxQ("span", null, {
                  class: "text-muted-foreground text-xs"
                }, "生成中...", 3, null), 3, null), 1, null),
                /* @__PURE__ */ _jsxQ("div", null, {
                  class: "min-w-0 flex-1"
                }, [
                  /* @__PURE__ */ _jsxQ("div", null, {
                    class: "space-y-2"
                  }, [
                    /* @__PURE__ */ _jsxQ("div", null, {
                      class: "border-input bg-muted rounded-md border p-3 font-mono text-xs break-all"
                    }, _fnSignal((p0) => p0.value.subscribeLinks.default, [
                      redeemResult
                    ], "p0.value.subscribeLinks.default"), 3, null),
                    /* @__PURE__ */ _jsxQ("button", {
                      class: `ring-offset-background focus-visible:ring-ring inline-flex w-full items-center justify-center rounded-xl px-4 py-2 text-sm font-medium transition-all duration-300 hover:shadow-lg focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50 ${copySuccess.value ? "bg-primary text-primary-foreground hover:bg-primary" : "bg-primary text-primary-foreground hover:bg-primary/90"}`
                    }, {
                      disabled: _fnSignal((p0) => !!p0.value, [
                        copySuccess
                      ], "!!p0.value"),
                      onClick$: /* @__PURE__ */ _noopQrl("s_W7z7DpskUFM", [
                        copyToClipboard,
                        redeemResult
                      ])
                    }, copySuccess.value ? /* @__PURE__ */ _jsxQ("span", null, {
                      class: "flex items-center justify-center"
                    }, [
                      /* @__PURE__ */ _jsxC(LuCheck, {
                        class: "mr-2 h-4 w-4",
                        [_IMMUTABLE]: {
                          class: _IMMUTABLE
                        }
                      }, 3, "vb_9"),
                      "已复制"
                    ], 1, "vb_10") : /* @__PURE__ */ _jsxQ("span", null, {
                      class: "flex items-center justify-center"
                    }, [
                      /* @__PURE__ */ _jsxC(LuCopy, {
                        class: "mr-2 h-4 w-4",
                        [_IMMUTABLE]: {
                          class: _IMMUTABLE
                        }
                      }, 3, "vb_11"),
                      "复制订阅链接"
                    ], 1, null), 1, null)
                  ], 1, null),
                  copySuccess.value && !copySuccess.value.includes("已复制") && /* @__PURE__ */ _jsxQ("div", null, {
                    class: "text-primary mt-2 flex items-center text-sm font-medium"
                  }, [
                    /* @__PURE__ */ _jsxC(LuCheck, {
                      class: "mr-1 h-4 w-4",
                      [_IMMUTABLE]: {
                        class: _IMMUTABLE
                      }
                    }, 3, "vb_12"),
                    _fnSignal((p0) => p0.value, [
                      copySuccess
                    ], "p0.value")
                  ], 1, "vb_13")
                ], 1, null)
              ], 1, null)
            ], 1, "vb_14")
          ], 1, null),
          redeemResult.value.subscribeLinks && Object.keys(redeemResult.value.subscribeLinks).length > 1 && /* @__PURE__ */ _jsxQ("div", null, null, [
            /* @__PURE__ */ _jsxQ("h4", null, {
              class: "mb-3 text-lg font-medium"
            }, "快速导入", 3, null),
            /* @__PURE__ */ _jsxQ("div", null, {
              class: "grid grid-cols-3 gap-3"
            }, Object.entries(redeemResult.value.subscribeLinks).filter(([key]) => key !== "default").slice(0, 12).map(([appName, appLink]) => /* @__PURE__ */ _jsxQ("a", {
              href: appLink,
              title: `直接在 ${appName} 中打开`
            }, {
              class: "border-input bg-background ring-offset-background hover:bg-accent hover:text-accent-foreground focus-visible:ring-ring inline-flex h-14 items-center justify-center rounded-xl border p-2 text-center text-sm font-medium transition-all duration-300 hover:scale-105 focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50"
            }, /* @__PURE__ */ _jsxQ("div", null, {
              class: "text-center text-xs leading-tight font-medium"
            }, appName, 1, null), 1, appName)), 1, null),
            /* @__PURE__ */ _jsxQ("p", null, {
              class: "text-muted-foreground mt-4 text-sm"
            }, "点击对应应用可自动打开并导入订阅配置，无需手动复制链接", 3, null)
          ], 1, "vb_15")
        ], 1, null), 1, null), 1, null)
      ], 1, null)
    ),
    /* @__PURE__ */ _jsxQ("div", null, {
      class: "mt-6 text-center"
    }, /* @__PURE__ */ _jsxQ("button", null, {
      class: "border-input bg-background ring-offset-background hover:bg-accent hover:text-accent-foreground focus-visible:ring-ring inline-flex h-10 items-center justify-center rounded-lg border px-6 py-2 text-sm font-medium transition-all duration-300 hover:scale-105 focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50",
      onClick$: clearAndGoHome
    }, "返回首页", 3, null), 3, null)
  ], 1, "vb_16");
};
const index = /* @__PURE__ */ componentQrl(/* @__PURE__ */ inlinedQrl(s_WqP80aZTB6s, "s_WqP80aZTB6s"));
const RedeemRoute = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index
}, Symbol.toStringTag, { value: "Module" }));
const serverPlugins = [];
const ApiLayout = () => ApiLayout_;
const Layout = () => Layout_;
const routes = [
  ["/", [Layout, () => IndexRoute], "/", ["q-BGKKR_Zr.js", "q-Ie1TmZDn.js"]],
  ["api/orders/create/", [Layout, ApiLayout, () => ApiOrdersCreateRoute], "/api/orders/create/", ["q-BGKKR_Zr.js", "q-OJ-80A8o.js"]],
  ["api/orders/detail/", [Layout, ApiLayout, () => ApiOrdersDetailRoute], "/api/orders/detail/", ["q-BGKKR_Zr.js", "q-OJ-80A8o.js"]],
  ["api/config/", [Layout, ApiLayout, () => ApiConfigRoute], "/api/config/", ["q-BGKKR_Zr.js", "q-OJ-80A8o.js", "q-Jxi-xeSd.js"]],
  ["api/products/", [Layout, ApiLayout, () => ApiProductsRoute], "/api/products/", ["q-BGKKR_Zr.js", "q-OJ-80A8o.js"]],
  ["api/redeem/", [Layout, ApiLayout, () => ApiRedeemRoute], "/api/redeem/", ["q-BGKKR_Zr.js", "q-OJ-80A8o.js"]],
  ["redeem/", [Layout, () => RedeemRoute], "/redeem/", ["q-BGKKR_Zr.js", "q-D2bCjifB.js"]]
];
const menus = [];
const trailingSlash = true;
const basePathname = "/";
const cacheModules = true;
const qwikCityPlan = { routes, serverPlugins, menus, trailingSlash, basePathname, cacheModules };
export {
  basePathname,
  cacheModules,
  qwikCityPlan as default,
  menus,
  routes,
  serverPlugins,
  trailingSlash
};
